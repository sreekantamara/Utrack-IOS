//
//  TabSelection.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2023-12-09.
//

import Foundation

enum TabSelection: Int, CaseIterable {
    case Dashboard = 1
    case List = 2
    case Map = 3
}

enum ListSelection: Int {
    case all
    case moving
    case stopped
    case nodata

    case basic
    case magnetic
    case mobile
    case obd
    case idcard
    case carstereo
    case temperature
    case fuel

    case ajax
    case auto
    case bike
    case bus
    case car
    case cargo
    case compact
    case cycle
    case erickshaw
    case excavator
    case idcard_asset
    case mobile_mobile
    case scooty
    case towing
    case train
    case truck
}
