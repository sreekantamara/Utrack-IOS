//
//  DataModels.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-01-19.
//

import SwiftUI

/// To get whether a device is running, stopped or no data for more than 4 hours
/// - Parameters:
///   - deviceTime: v2 devicetime
///   - speed: speed of the vehicle
/// - Returns: DeviceStatus Enum
func getDeviceStatus(deviceTime: String, speed: String) -> DeviceStatus {

    let calendar = Calendar.current
    let serverDeviceTime = deviceTime.formatStringToDateUTC()

    let userDeviceTime = Date().formatDateToString().formatStringToDateUTC()


    print("serverDeviceTime: S: \(deviceTime) SDT: \(serverDeviceTime) User: \(userDeviceTime)")

    let components = calendar.dateComponents([.minute], from: serverDeviceTime, to: userDeviceTime)

    if let minDiff = components.minute, minDiff >= 240 {

        return .nodata
    } else {
        if let speed = Double(speed), speed >= 5 {
            return .moving
        } else {
            return .stopped
        }
    }

//    if let speed = Double(speed), speed >= 10 {
//        return .moving
//    } else {
//        if let minDiff = components.minute, minDiff >= 120 {
//            return .noData
//        } else {
//            return .stopped
//        }
//
//    }


}

func getDeviceColor(_ status: DeviceStatus) -> Color {
    switch status {
        case .stopped:
            return .red
        case .moving:
            return .green
        case .nodata:
            return .yellow
    }
}

func getListMovingIcon(_ status: DeviceStatus) -> String {
    switch status {
        case .stopped:
            return ListIcon.moving_red
        case .moving:
            return ListIcon.moving_green
        case .nodata:
            return ListIcon.moving_yellow
    }
}
