//
//  Assets.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2023-12-03.
//

import Foundation

enum Status {
    // Dashboard Vehicle Status
    static let dashboard_all = "dashboard_total"
    static let dashboard_moving = "dashboard_moving"
    static let dashboard_stopped = "dashboard_stopped"
    static let dashboard_no_data = "dashboard_no_data"

    static let items = ["All", "Moving", "Stopped", "No Data"]
}
enum Product {
    // Product Types
    static let dashboard_basic = "dashboard_basic"
    static let dashboard_car_stereo = "dashboard_car_stereo"
    static let dashboard_fuel = "dashboard_fuel"
    static let dashboard_id_card = "dashboard_id_card"
    static let dashboard_magnetic = "dashboard_magnetic"
    static let dashboard_mobile = "dashboard_mobile"
    static let dashboard_obd = "dashboard_obd"
    static let dashboard_temperature = "dashboard_temperature"

    static let items = [
        "Basic",
        "Magnetic",
        "Mobile",
        "OBD",
        "ID Card",
        "Car Stereo",
        "Temperature",
        "Fuel"
    ]
}

enum Asset: String, CaseIterable{
    //Asset Types
    case ajax = "ic_asset_type_ajax"
    case auto = "ic_asset_type_auto"
    case bike = "ic_asset_type_bike"
    case bus = "ic_asset_type_bus"
    case car = "ic_asset_type_car"
    case cargo = "ic_asset_type_cargo"
    case compact = "ic_asset_type_compact"
    case cycle = "ic_asset_type_cycle"
    case erickshaw = "ic_asset_type_erickshaw"
    case excavator = "ic_asset_type_excavator"
    case idcard = "ic_asset_type_idcard"
    case mobile = "ic_asset_type_mobile"
    case scooty = "ic_asset_type_scooty"
    case towing = "ic_asset_type_towing"
    case train = "ic_asset_type_train"
    case truck = "ic_asset_type_truck"

    var name: String {
        // Extract the name from the enum case for readability
        return rawValue.components(separatedBy: "_").last ?? "Unknown"
    }
}

enum ListIcon {
    static let moving_green = "ic_move_green"
    static let moving_yellow = "ic_move_yellow"
    static let moving_red = "ic_move_red"

    static let speed_0 = "ic_speed_0"
    static let speed_50 = "ic_speed_50"
    static let speed_80 = "ic_speed_80"
    static let speed_80p = "ic_speed_80above"

    static let ignition_on = "ic_ignition_on"
    static let ignition_off = "ic_ignition_off"

    static let  stopped_24_below = "ic_stopped_24hrs_below"
    static let  stopped_24_above = "ic_stopped_24hrs_above"

    static let signal_medium = "ic_signal_medium"

    static let battery_10_below = "ic_battery_10_below"
    static let battery_10_50 = "ic_battery_10_to_50"
    static let battery_60_above = "ic_battery_60_above"

    static let temperature = "ic_temperature"

    static let fuel_10_above = "ic_fuel_10_ltrs_above"
    static let fuel_10_below = "ic_fuel_10_ltrs_below"

    static let door = "ic_door"

}

enum ReportIcon {

    static let liveTracking = "menu_live_track"
    static let trackHistory = "menu_track_history"
    static let summary = "menu_summary_report"
    static let trackNearest = "menu_track_nearest"

    static let stoppage = "menu_stoppage_report"
    static let track = "menu_track_history"
    static let distance = "menu_distance_report"

    static let dailyKm = "reports_5_daily_km"
    static let hour_24_analysis = "menu_24_hours_analysis"
    static let geofence = "reports_9_geofence"

    static let geo_to_geo = "reports_9_geofence"
    static let over_speed = "menu_ic_over_speed"
    static let km_monthly = "reports_24_way_points"
}

enum ReportType: CaseIterable {
    case none
    case dashboard
    case liveTracking
    case trackNearest
    case trackHistory
    case summary
    case stoppage
    case track
    case distance
    case dailyKm
    case hour24Analysis
    case geofence
    case geoToGeo
    case overspeed
    case kmMonthly
}

enum LiveTrackingIcon {
    static let avg_speed = "ic_min_speed"
    static let max_speed = "ic_max_speed"
    static let travel_time = "ic_ignetion_on"
    static let total_distance = "ic_total_distance"
}

enum THMarkerIcon {
    static let marker_red = "marker_type_red"
    static let marker_green = "marker_type_green"
    static let marker_blue = "marker_type_blue"
    static let marker_purple = "marker_type_purple"
}

enum DeviceStatus: String {
    case stopped = "stopped"
    case moving = "moving"
    case nodata = "nodata"
}
