//
//  AppDelegate.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2023-12-17.
//

import UIKit
import IQKeyboardManagerSwift
import GoogleMaps
import RealmSwift

class AppDelegate: NSObject, UIApplicationDelegate {
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
        IQKeyboardManager.shared.enable = true
        IQKeyboardManager.shared.toolbarDoneBarButtonItemText = "Terminar"
        IQKeyboardManager.shared.shouldResignOnTouchOutside = true
        IQKeyboardManager.shared.previousNextDisplayMode = .alwaysShow

        GMSServices.provideAPIKey("AIzaSyBi7NlsGuh02iZAdGdgcWdDU3DR4ylmsRI")

        // to prevent Realm Crash
        let config = Realm.Configuration(
            schemaVersion: 9,
            // Set the block which will be called automatically when opening a Realm with
            // a schema version lower than the one set above
            migrationBlock: { migration, oldSchemaVersion in
                if oldSchemaVersion < 1 {

                }
            }
        )
        Realm.Configuration.defaultConfiguration = config


        return true
    }
}
