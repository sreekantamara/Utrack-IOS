//
//  GMCoordinator.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2023-12-15.
//

import Foundation
import GoogleMaps

class GMCoordinator: NSObject, GMSMapViewDelegate {
    var parent: GoogleMapView

    init(parent: GoogleMapView) {
        self.parent = parent
    }

    func mapView(_ mapView: GMSMapView, didTap marker: GMSMarker) -> Bool {
        // Handle marker tap
        if let tappedMarker = parent.markers.first(where: { $0.vehicleNumber == marker.title }) {
            print("Tapped marker: \(tappedMarker.vehicleNumber)")
            // You can perform actions based on the tapped marker
        }
        return true
    }
    
}


class LiveMapCoordinator: NSObject, GMSMapViewDelegate {
    var parent: LiveMapView
    var debounceTimer: Timer?

    init(parent: LiveMapView) {
        self.parent = parent
    }

    func mapView(_ mapView: GMSMapView, didChange position: GMSCameraPosition) {
        debounceTimer?.invalidate()
        debounceTimer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: false) { [weak self] _ in
            self?.parent.zoomLevel = mapView.camera.zoom
            self?.parent.rotationLevel = mapView.camera.bearing
            print("Setting zoom \(mapView.camera.zoom)")
        }
    }

}

class THCoordinator: NSObject, GMSMapViewDelegate {
    var parent: THMapView
    var debounceTimer: Timer?

    init(parent: THMapView) {
        self.parent = parent
    }

    func mapView(_ mapView: GMSMapView, didChange position: GMSCameraPosition) {
        debounceTimer?.invalidate()
        debounceTimer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: false) { [weak self] _ in
            self?.parent.zoomLevel = mapView.camera.zoom
        }
    }
    

}

class TNCoordinator: NSObject, GMSMapViewDelegate {
    var parent: TNMapView
    
    init(parent: TNMapView) {
        self.parent = parent
    }
}



class OSCoordinator: NSObject, GMSMapViewDelegate {
    var parent: OSMapView

    init(parent: OSMapView) {
        self.parent = parent
    }
}
