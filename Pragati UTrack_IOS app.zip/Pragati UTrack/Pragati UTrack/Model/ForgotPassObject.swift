//
//  ForgotPassObject.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-01-19.
//

import Foundation
import RealmSwift

// MARK: - ForgotPassObject
class ForgotPassObject: Object, Codable, ObjectKeyIdentifiable {
    @Persisted var status: Bool
    @Persisted var message: String
    @Persisted var data: DataClass?
}

// MARK: - DataClass
class DataClass: Object, Codable, ObjectKeyIdentifiable {
    @Persisted var verifyCode: Int
    @Persisted var userId: String
    @Persisted var firstName: String
    @Persisted var lastName: String
    @Persisted var email: String
    @Persisted var mobile: String
    @Persisted var smsResponse: String
}

class ResetObject: Object, Codable, ObjectKeyIdentifiable {
    @Persisted var status: Bool
    @Persisted var message: String
}
