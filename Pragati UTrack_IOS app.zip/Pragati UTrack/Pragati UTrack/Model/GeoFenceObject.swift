//
//  GeoFenceObject.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-01-21.
//

import Foundation
import RealmSwift

// MARK: - GeofenceModel
class GeoFenceObject: Object, ObjectKeyIdentifiable, Codable {
    @Persisted var status: Bool
    @Persisted var message: String
    @Persisted var data: List<GeofenceData>
}

// MARK: - GeofenceData
class GeofenceData: Object, ObjectKeyIdentifiable, Codable {
    @Persisted var deviceGeofenceTransId: String
    @Persisted var userId: String
    @Persisted var geofenceId: String
    @Persisted var geofenceName: String
    @Persisted var latitude: String
    @Persisted var longitude: String
    @Persisted var locationName: String
    @Persisted var radius: String
    @Persisted var geofenceDataType: String
    @Persisted var polygonData: String?
    @Persisted var addedDate: String?
    @Persisted var modifiedDate: String?
    @Persisted var status: String
}
