//
//  DashboardListMap.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2023-12-15.
//

//   @Persisted var dashboardListMap = try? JSONDecoder().decode(DashboardListMap.self, from: jsonData)

import Foundation
import Combine
import RealmSwift

class DashboardListMap: Object,Codable, ObjectKeyIdentifiable {
    @Persisted var status: Bool
    @Persisted var message: String
    @Persisted var data: List<Device>
}

class Device: Object, Codable, Identifiable {
    @Persisted var deviceId: String
    @Persisted var deviceLinkId: String
    @Persisted var deviceImei: String
    @Persisted var gpsLockStatus: String
    @Persisted var vehicleNumber: String
    @Persisted var vehicleName: String
    @Persisted var withRealm: String
    @Persisted var fuelPoint: String
    //@Persisted var expiryDate: String
    @Persisted var vehicleType: String
    //@Persisted var fuelTankSize: String
    @Persisted var customerId: String
    @Persisted var customerName: String
    @Persisted var customerImage: String
    @Persisted var customerMobile: String
    @Persisted var productType: String
    @Persisted var vehicleImage: String
    @Persisted var driverId: String
    @Persisted var nickName: String
    //@Persisted var driverName: String
    //@Persisted var driverMobile: String
    @Persisted var latitude: String
    @Persisted var longitude: String
    @Persisted var course: String
    @Persisted var speed: String
    @Persisted var servertime: String
    @Persisted var devicetime: String
    //@Persisted var fixTime: String
    @Persisted var dayDistance: String
    @Persisted var lastRunningTime: String
    //@Persisted var powerStatus: String
    @Persisted var lastArea: String
    @Persisted var lastDistrict: String
    @Persisted var lastCity: String
    @Persisted var lastState: String
    @Persisted var lastStateId: String
    @Persisted var isDoorSensor: String
    @Persisted var bajajCityId: String
    @Persisted var landmark: String
    //@Persisted var dateTime: String
    @Persisted var ignition: Bool
    @Persisted var motionStatus: Bool
    @Persisted var temp1: String
    @Persisted var temp2: String
    @Persisted var batteryLevel: String
    @Persisted var deviceUserListCount: Int
    //var inProgressTrip: [InProgressTrip]
}
