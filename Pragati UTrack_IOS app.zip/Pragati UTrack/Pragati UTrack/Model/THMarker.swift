//
//  THMarker.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-02-13.
//

import Foundation
import UIKit
import GoogleMaps
import GoogleMapsUtils

class THMarker: NSObject {
    var speed: Double
    var course: Double
    var time: Int
    var distance: Double
    var lat: CLLocationDegrees
    var lon: CLLocationDegrees
    var position: CLLocationCoordinate2D

    init(speed: Double, course: Double, time: Int, distance: Double, lat: Double, lon: Double) {
        self.speed = speed
        self.course = course
        self.time = time
        self.distance = distance
        self.lat = CLLocationDegrees(lat)
        self.lon = CLLocationDegrees(lon)

        self.position = CLLocationCoordinate2D(latitude: lat, longitude: lon)
    }

}

class MarkerImageGenerator {
    private static var imageCache: [String: UIImage] = [:]

    static func imageWithText(text: String, unitText: String, markerColor: MarkerColor = .blue) -> UIImage {

        // Check if the image is already in the cache
        if let cachedImage = imageCache[text] {
            return cachedImage
        }

        let size = CGSize(width: 45, height: 70)
        UIGraphicsBeginImageContextWithOptions(size, false, 0.0)

        // Draw the marker background based on the provided markerColor
        markerColor.image.draw(in: CGRect(origin: .zero, size: size))

        // Draw the first text
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.alignment = .center
        let attributes = [
            NSAttributedString.Key.font: UIFont.systemFont(ofSize: 12),
            NSAttributedString.Key.paragraphStyle: paragraphStyle,
            NSAttributedString.Key.foregroundColor: UIColor.white
        ]
        let textRect = CGRect(x: 0, y: 10, width: size.width, height: 30)
        text.draw(with: textRect, options: .usesLineFragmentOrigin, attributes: attributes, context: nil)

        // Draw the second text (you can adjust the font size here)
        let smallTextRect = CGRect(x: 0, y: 22, width: size.width, height: 20)
        let smallAttributes = [
            NSAttributedString.Key.font: UIFont.systemFont(ofSize: 8), // Adjust the font size here
            NSAttributedString.Key.paragraphStyle: paragraphStyle,
            NSAttributedString.Key.foregroundColor: UIColor.white
        ]
        unitText.draw(with: smallTextRect, options: .usesLineFragmentOrigin, attributes: smallAttributes, context: nil)

        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()

        // Cache the generated image for future use
        imageCache[text] = image

        return image ?? UIImage()
    }
}

enum MarkerColor {
    case green
    case red
    case blue
    case purple

    var image: UIImage {
        switch self {
            case .green:
                return UIImage(named: THMarkerIcon.marker_green) ?? UIImage()
            case .red:
                return UIImage(named: THMarkerIcon.marker_red) ?? UIImage()
            case .blue:
                return UIImage(named: THMarkerIcon.marker_blue) ?? UIImage()
            case .purple:
                return UIImage(named: THMarkerIcon.marker_purple) ?? UIImage()
        }
    }
}
