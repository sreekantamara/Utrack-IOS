//
//  DeviceData.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-01-03.
//

import Foundation
import RealmSwift

// MARK: - DeviceData
class DeviceData: Object,Codable, ObjectKeyIdentifiable {
    @Persisted var status: Bool
    @Persisted var message: String
    @Persisted var data: List<Datum>
}

// MARK: - Datum
class Datum: Object, Codable, Identifiable {
    @Persisted var deviceLinkID: String
    @Persisted var deviceID: String
    @Persisted var deviceImei: String
    @Persisted var vehicleNumber: String
    @Persisted var vehicleName: String
    @Persisted var  devicetime: String
    @Persisted var  isDoorSensor: String
    @Persisted var  isGensetSensor: String
    @Persisted var bajajCountryID: String
    @Persisted var  vehicleType: String
    @Persisted var  productType: String
    @Persisted var  bajajCityID: String
}
