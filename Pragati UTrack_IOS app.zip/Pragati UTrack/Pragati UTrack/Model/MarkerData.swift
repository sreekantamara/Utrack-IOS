//
//  MarkerData.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2023-12-15.
//

import GoogleMaps
import RealmSwift

class MarkerData: Object, ObjectKeyIdentifiable, Codable {
    @Persisted var vehicleNumber: String
    @Persisted var latitude: Double
    @Persisted var longitude: Double
    @Persisted var deviceTime: String
    @Persisted var speed: String
    @Persisted var lastReceivedTime: String
    @Persisted var location: String
    @Persisted var vehicleType: String?
    @Persisted var course: String?
}




