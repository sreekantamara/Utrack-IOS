//
//  DistanceReportObject.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-01-20.
//

import Foundation
import RealmSwift

// MARK: - DistanceReportObject
class DistanceReportObject: Object, ObjectKeyIdentifiable, Codable {
    @Persisted var status: Bool
    @Persisted var message: String
    @Persisted var exeTime: String
    @Persisted var count: Int
    @Persisted var data: List<DistanceData>
}

// MARK: - Datum
class DistanceData: Object, ObjectKeyIdentifiable, Codable {
    @Persisted var fdt: String
    @Persisted var tdt: String
    @Persisted var d: String
    @Persisted var cd: String
}
