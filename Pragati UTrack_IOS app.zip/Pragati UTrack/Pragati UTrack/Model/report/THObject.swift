//
//  THObject.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-02-11.
//

import Foundation
import RealmSwift

// MARK: - LiveTrackStatObject
class THObject: Object, ObjectKeyIdentifiable, Codable {
    @Persisted var status: Bool
    @Persisted var message: String
    @Persisted var data: THDataClass?
}

// MARK: - DataClass
class THDataClass: Object, ObjectKeyIdentifiable, Codable {
    @Persisted var deviceReportStatsCustom: DeviceReportStatsCustom?
    @Persisted var trackReport: List<TrackReportObject>
}

// MARK: - DeviceReportStatsCustom
class DeviceReportStatsCustom: Object, ObjectKeyIdentifiable, Codable {
    @Persisted var maxSpeed: String
    @Persisted var avgSpeed: String
    @Persisted var totalDistance: String
    @Persisted var totalTravelledTime: String
    @Persisted var ttts: Int
}

// MARK: - TrackReport
class TrackReportObject: Object, ObjectKeyIdentifiable, Codable {
    @Persisted var s: Int
    @Persisted var cd: String
    @Persisted var la: Double
    @Persisted var lo: Double
    @Persisted var nt: String
    @Persisted var t: Int
    @Persisted var c: Int
}
