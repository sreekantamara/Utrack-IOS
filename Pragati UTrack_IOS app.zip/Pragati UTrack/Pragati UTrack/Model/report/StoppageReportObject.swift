//
//  StoppageReportObject.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-01-19.
//

import Foundation
import RealmSwift

// MARK: - StoppageReportObject
class StoppageReportObject: Object, Codable, ObjectKeyIdentifiable {
    @Persisted var status: Bool
    @Persisted var message: String
    @Persisted var exeTime: String
    @Persisted var data: List<StoppageData>
}

// MARK: - Datum
class StoppageData: Object, Codable, ObjectKeyIdentifiable {
    @Persisted var ttd: String
    @Persisted var type: String
    @Persisted var mcc: String
    @Persisted var fdt: String
    @Persisted var tdt: String
    @Persisted var ttts: Int
    @Persisted var ttt: String
    @Persisted var l: String
    @Persisted var la: String
    @Persisted var lo: String
}
