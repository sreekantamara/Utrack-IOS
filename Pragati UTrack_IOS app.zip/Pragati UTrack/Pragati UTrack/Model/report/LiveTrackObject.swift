//
//  LiveTrackObject.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-02-10.
//

// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let liveTrackObject = try? JSONDecoder().decode(LiveTrackObject.self, from: jsonData)

import Foundation
import RealmSwift
import Combine

// MARK: - LiveTrackObject
class LiveTrackObject: Object, ObjectKeyIdentifiable, Codable {
    @Persisted var status: Bool
    @Persisted var message: String
    @Persisted var data: LiveTrackData?
}

// MARK: - DataClass
class LiveTrackData: Object, ObjectKeyIdentifiable, Codable {
    @Persisted var deviceLinkId: String
    @Persisted var positionId: String
    @Persisted var latitude: String
    @Persisted var longitude: String
    @Persisted var course: String
    @Persisted var speed: String
    @Persisted var devicetime: String
    @Persisted var servertime: String
    @Persisted var lastLocation: String
    @Persisted var lastLocDistance: String
    @Persisted var lastState: String
    @Persisted var lastDistrict: String
    @Persisted var fuelPoint: String
    @Persisted var valid: String
    @Persisted var fixtime: String
    @Persisted var temp1: String
    @Persisted var batteryLevel: String
}

// Stat
// MARK: - LiveTrackStatObject
class LiveTrackStatObject: Object, ObjectKeyIdentifiable, Codable {
    @Persisted var status: Bool
    @Persisted var message: String
    @Persisted var data: LiveTrackStatData?
}

// MARK: - DataClass
class LiveTrackStatData: Object, ObjectKeyIdentifiable, Codable {
   @Persisted var maxSpeed: String
   @Persisted var avgSpeed: String
   @Persisted var totalDistance: String
   @Persisted var totalTravelledTime: String
   @Persisted var totalStoppedTime: String
   @Persisted var freeWheelingDistance: String
   @Persisted var freeWheelingTime: String
}

