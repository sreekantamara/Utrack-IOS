//
//  Hour24Object.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-01-20.
//

import Foundation
import RealmSwift

// MARK: - Hour24Object
class Hour24Object: Object, ObjectKeyIdentifiable, Codable  {
    @Persisted var status: Bool
    @Persisted var message: String
    @Persisted var data: List<HourData>
}

// MARK: - Datum
class HourData: Object, ObjectKeyIdentifiable, Codable {
    @Persisted var vehicleAnalysisId: String
    @Persisted var deviceLinkId: String
    @Persisted var deviceId: String
    @Persisted var vehicleNumber: String
    @Persisted var vehicleType: String
    @Persisted var reportDate: String
    @Persisted var driverId: String
    @Persisted var driverName: String
    @Persisted var driverNumber: String
    @Persisted var customerId: String
    @Persisted var customerName: String
    @Persisted var customerNumber: String
    @Persisted var totalDistance: String
    @Persisted var totalNightDistance: String
    @Persisted var totalDayDistance: String
    @Persisted var maxSpeed: String
    @Persisted var avgSpeed: String
    @Persisted var suddenAccerlation: String
    @Persisted var suddenDeceleration: String
    @Persisted var totalStoppedTime: String
    @Persisted var totalTravelledTime: String
    @Persisted var totalNightTravelledTime: String
    @Persisted var totalDayTravelledTime: String
    @Persisted var freeWheelingDistance: String
    @Persisted var freeWheelingTime: String
    @Persisted var ignitionTime: String
    @Persisted var ignitionTimeWhenVehicleMoving: String
    @Persisted var igintionTimeWhenVehicleStopped: String
    @Persisted var wayPointsCount: String
    @Persisted var addDistancePercent: String
    @Persisted var speedRatio: String
//    @Persisted var bajajCityId: String
//    @Persisted var bajajCountryId: String
//    @Persisted var bajajCityName: String = ""
    @Persisted var bajajCountryName: String
    @Persisted var totalNightStoppedTime: String
    @Persisted var totalDayStoppedTime: String
    @Persisted var reportDay: String
    @Persisted var utilization: String
}
