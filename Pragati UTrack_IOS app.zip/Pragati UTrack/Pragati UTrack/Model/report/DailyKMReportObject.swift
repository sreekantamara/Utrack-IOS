//
//  DailyKMReportObject.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-01-20.
//

import Foundation
import RealmSwift

// MARK: - DailyKMReportObject
class DailyKMReportObject: Object, ObjectKeyIdentifiable, Codable {
    @Persisted var status: Bool
    @Persisted var message: String
    @Persisted var data: DataElementRoot?
}

// MARK: - DataElement
class DataElementRoot: Object, ObjectKeyIdentifiable, Codable {
    @Persisted var detail: List<DataElement>
    @Persisted var maxSpeed: String
    @Persisted var avgSpeed: String
    @Persisted var totalDistance: String
    @Persisted var totalTravelledTime: String
    @Persisted var totalStoppedTime: String
    @Persisted var freeWheelingDistance: String
    @Persisted var freeWheelingTime: String
}

class DataElement: Object, ObjectKeyIdentifiable, Codable {
    @Persisted var maxSpeed: String
    @Persisted var avgSpeed: String
    @Persisted var totalDistance: String
    @Persisted var totalTravelledTime: String
    @Persisted var totalStoppedTime: String
    @Persisted var freeWheelingDistance: String
    @Persisted var freeWheelingTime: String
    @Persisted var reportDate: String
    @Persisted var reportDay: String?
}



