//
//  MonthlyWaypointReportObject.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-01-22.
//

import Foundation
import RealmSwift

// MARK: - MonthlyWaypointReportObject
class MonthlyWaypointReportObject: Object, ObjectKeyIdentifiable, Codable  {
    @Persisted var status: Bool
    @Persisted var message: String
    @Persisted var data: List<MonthlyData>
}

// MARK: - Datum
class MonthlyData: Object, ObjectKeyIdentifiable, Codable  {
    @Persisted var deviceLinkId: String
    @Persisted var deviceId: String
    @Persisted var vehicleNumber: String
    @Persisted var vehicleType: String
    @Persisted var mileagePerLitre: String
    @Persisted var addDistancePercent: String
    @Persisted var pos: Int
    @Persisted var thisMonth: ThisMonth?
}

// MARK: - ThisMonth
class ThisMonth: Object, ObjectKeyIdentifiable, Codable  {
    @Persisted var totalDistance: String
    @Persisted var wayPointsCount: String
    @Persisted var noOfRefills: String
    @Persisted var totalLiters: String
    @Persisted var totalRefilingAmount: String
    @Persisted var mileagePerLitre: String
    @Persisted var approxAvgMileage: Int
    @Persisted var detail: List<Detail>
}

// MARK: - Detail
class Detail: Object, ObjectKeyIdentifiable, Codable {
    @Persisted var totalDistance: String
    @Persisted var reportDate: String
    @Persisted var reportDay: String
    @Persisted var day: String
    @Persisted var wayPointsCount: String
}
