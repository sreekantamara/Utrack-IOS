//
//  GeofenceReportObject.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-01-22.
//

import Foundation
import RealmSwift

// MARK: - GeofenceReportObject
class GeofenceReportObject: Object, ObjectKeyIdentifiable, Codable {
    @Persisted var status: Bool
    @Persisted var message: String
    @Persisted var data: List<GeofenceReportData>
}

// MARK: - Datum
class GeofenceReportData: Object, ObjectKeyIdentifiable, Codable  {
    @Persisted var geofenceId: String
    @Persisted var deviceId: String
    @Persisted var enterTime: String
    @Persisted var exitTime: String
    @Persisted var duration: String
    @Persisted var status: String
    @Persisted var geofenceName: String
    @Persisted var vehicleNumber: String
    @Persisted var deviceLinkId : String
    @Persisted var vehicleType: String
}
