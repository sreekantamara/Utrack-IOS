//
//  GeoToGeoReportObject.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-01-22.
//
import Foundation
import RealmSwift

// MARK: - GeoToGeoReportObject
class GeoToGeoReportObject: Object, ObjectKeyIdentifiable, Codable   {
    @Persisted var status: Bool
    @Persisted var data: List<GeoGeoReportData>
    @Persisted var message: String
}

// MARK: - Datum
class GeoGeoReportData: Object, ObjectKeyIdentifiable, Codable {
    @Persisted var geofToGeofReportId: String
    @Persisted var deviceLinkId: String
    @Persisted var deviceId: String
    @Persisted var vehicleNumber: String
    @Persisted var vehicleType: String
    @Persisted var fromGeofenceId: String
    @Persisted var fromGeofenceDateTime: String
    @Persisted var toGeofenceId: String
    @Persisted var toGeofenceDateTime: String
    @Persisted var enterDeviceGeofenceHistoryId: String
    @Persisted var exitDeviceGeofenceHistoryId: String
    @Persisted var durationMins: String
    @Persisted var totalDistance: String
    @Persisted var totalTravelledTime: String
    @Persisted var totalStoppedTime: String
    @Persisted var ignitionTime: String
    @Persisted var freeWheelingTime: String
    @Persisted var maxSpeed: String
    @Persisted var avgSpeed: String
    @Persisted var startFuelLevel: String
    @Persisted var endFuelLevel: String
    @Persisted var addedDate: String
    @Persisted var updatedDate: String
    @Persisted var status: String
    @Persisted var fromGeofence: String
    @Persisted var toGeofence: String
    @Persisted var durationFormat: String
    @Persisted var refillsCount: Int
    @Persisted var refillsLiters: Int
    //@Persisted var refillsRes: List<Any>
    @Persisted var removalsCount: Int
    @Persisted var removalsLiters: Int
    //@Persisted var removalsRes: [Any?]
    @Persisted var totalFuelConsumed: Int
    @Persisted var averageMileage: Int
}
