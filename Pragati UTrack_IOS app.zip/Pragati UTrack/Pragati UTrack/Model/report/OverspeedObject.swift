//
//  OverspeedObject.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-01-21.
//

import Foundation
import RealmSwift

// MARK: - OverSpeedObject
class OverSpeedObject: Object, ObjectKeyIdentifiable, Codable {
    @Persisted var status: Bool
    @Persisted var message: String
    
    @Persisted var data: List<OverSpeedRoot>
}
    // MARK: - OverSpeedObjectDatum
    class OverSpeedRoot: Object, ObjectKeyIdentifiable, Codable {
        @Persisted var deviceLinkId: String
        @Persisted var deviceId: String
        @Persisted var vehicleNumber: String
        @Persisted var vehicleType: String
        @Persisted var speedRatio: String
        @Persisted var today: Today?
        @Persisted var thisWeek: Last7?
        @Persisted var last7: Last7?
        @Persisted var thisMonth: Last7?
    }

// MARK: - Last7
class Last7: Object, ObjectKeyIdentifiable, Codable {
    @Persisted var detail: List<Today>
    @Persisted var ms: String
    @Persisted var last7_As: String
    @Persisted var td: String
    @Persisted var ttt: String
    private enum CodingKeys: String, CodingKey {
        case detail
        case ms
        case last7_As = "as"
        case ttt
        case td
    }

    func transformToArray() -> [[String]] {
        return detail.enumerated().map { (index, today) in
            let id = "\(index + 1)"
            let rd = today.rd
            let day = today.day
            let td = today.td
            let ttt = today.ttt

            return [id, rd, day, td, ttt]
        }
    }
}

// MARK: - Today
class Today: Object, ObjectKeyIdentifiable, Codable {
    @Persisted var ms: String
    @Persisted var todayAs: String
    @Persisted var ttt: String
    @Persisted var td: String
    @Persisted var rd: String
    @Persisted var day: String

    private enum CodingKeys: String, CodingKey {
        case ms
        case todayAs = "as"
        case ttt
        case td
        case rd
        case day
    }
}
