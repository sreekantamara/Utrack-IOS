//
//  OSObject.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-02-24.
//

import Foundation
import RealmSwift

// MARK: - OSObject
class OSObject: Object, ObjectKeyIdentifiable, Codable {
    @Persisted var status: Bool
    @Persisted var message: String
    @Persisted var exeTime: String
    @Persisted var data: List<OSData>
}

// MARK: - OSObjectDatum
class OSData: Object, ObjectKeyIdentifiable, Codable {
    @Persisted var fdt: String
    @Persisted var tdt: String
    @Persisted var d: String
    @Persisted var ms: String
    @Persisted var datumAs: String
    @Persisted var td: String
    @Persisted var l: String
    @Persisted var data: List<OSSingleData>

    private enum CodingKeys: String, CodingKey {
        case fdt, tdt, d, ms, td, l, data
        case datumAs = "as"
    }

}

// MARK: - DatumDatum
class OSSingleData: Object, ObjectKeyIdentifiable, Codable {
    @Persisted var la: String
    @Persisted var lo: String
    @Persisted var s: String
    @Persisted var c: String
    @Persisted var dt: String
}

