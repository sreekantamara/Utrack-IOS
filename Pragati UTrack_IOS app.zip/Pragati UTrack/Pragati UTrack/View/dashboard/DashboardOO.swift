//
//  DashboardOO.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2023-12-03.
//

// Observable Object
import Combine
import SwiftUI
import RealmSwift
import CoreLocation

class DashboardOO: ObservableObject {

    // id
    var id: String = ""

    // Status
    @Published var movingCount = 0
    @Published var allCount = 0
    @Published var stoppedCount = 0
    @Published var noDataCount = 0

    // Product
    @Published var basicCount = 0
    @Published var magneticCount = 0
    @Published var mobileCount = 0
    @Published var obdCount = 0
    @Published var idCount = 0
    @Published var carCount = 0
    @Published var tempCount = 0
    @Published var fuelCount = 0

    @Published var vehicleCounts: [String: Int] = [:]

    @Published var markerData: [MarkerData] = [MarkerData]()

    func reload(){
        getDashboardData(for: id)
    }

    func getDashboardData(for id: String){
        self.id = id
        var request = URLRequest(url: URL(string: "https://pragatiutrack.com/api/user/home_v2?user_id=\(id)&user_type=Customer")!,timeoutInterval: 60)
        request.addValue("FEA3E5D0QFCEBFD54F0A6A674ECAE3F8", forHTTPHeaderField: "X-Api-Key")

        request.httpMethod = "GET"

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                guard let data = data else {
                    print(String(describing: error))
                    return
                }


                do {

                    let decoder = JSONDecoder()
                    decoder.keyDecodingStrategy = .convertFromSnakeCase
                    let dashObject = try decoder.decode(DashboardListMap.self, from: data)
                    
                    
                    if dashObject.status == true {

                        self.resetAll()

                        //write to realm
                        let realm = try Realm()

                        for item in dashObject.data {
                            let status = getDeviceStatus(deviceTime: item.devicetime, speed: item.speed)

                            if status == .moving {
                                self.movingCount += 1
                            } else if status == .stopped {
                                self.stoppedCount += 1
                            } else {
                                self.noDataCount += 1
                            }

                            self.allCount += 1


                            let type = item.productType
                            if type == "Basic" {
                                self.basicCount += 1
                            }
                            if type == "Magnetic" {
                                self.magneticCount += 1
                            }
                            if type == "Mobile"{
                                self.mobileCount += 1
                            }
                            if type == "OBD"{
                                self.obdCount += 1
                            }
                            if type == "ID Card"{
                                self.idCount += 1
                            }
                            if type == "Car Stereo"{
                                self.carCount += 1
                            }
                            if type == "Temperature"{
                                self.tempCount += 1
                            }
                            if type == "Fuel"{
                                self.fuelCount += 1
                            }

                            self.vehicleCounts[item.vehicleType, default: 0] += 1


                            let marker = MarkerData()

                            marker.vehicleNumber = item.vehicleNumber
                            marker.vehicleType = item.vehicleType
                            marker.latitude = item.latitude.toDouble()
                            marker.longitude = item.longitude.toDouble()
                            marker.speed = item.speed
                            marker.lastReceivedTime = item.lastRunningTime
                            marker.location = item.landmark
                            marker.course = item.course

                            //write to realm
                            try! realm.write{

                                realm.add(marker)
                            }

                        }


                        try! realm.write{
                            realm.delete(realm.objects(DashboardListMap.self))
                            realm.add(dashObject)
                        }

                        // set the data
                        try! realm.write{
                            realm.delete(realm.objects(MarkerData.self))
                        }
                        

                    }

                } catch {
                    print("DashObject Throw \(error)")
                }
            }
        }

        task.resume()

    }

    func getLinkedData(for id: String){
        var request = URLRequest(url: URL(string: "https://pragatiutrack.com/api/user/home_lite_v1?user_id=\(id)&user_type=Customer")!,timeoutInterval: Double.infinity)
        request.addValue("FEA3E5D0QFCEBFD54F0A6A674ECAE3F8", forHTTPHeaderField: "X-Api-Key")

        request.httpMethod = "GET"

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data else {
                print(String(describing: error))
                return
            }

            do {

                let decoder = JSONDecoder()
                decoder.keyDecodingStrategy = .convertFromSnakeCase
                let deviceData = try decoder.decode(DeviceData.self, from: data)
                if deviceData.status == true {
                    //write to realm
                    let realm = try Realm()

                    try! realm.write{
                        realm.delete(realm.objects(DeviceData.self))
                        realm.add(deviceData)
                    }
                }

                print("Device data saved")

            } catch {
                print("DeviceData Throw \(error)")
            }
        }

        task.resume()

    }

    func resetAll(){
        movingCount = 0
        allCount = 0
        stoppedCount = 0
        noDataCount = 0
        basicCount = 0
        magneticCount = 0
        mobileCount = 0
        obdCount = 0
        idCount = 0
        carCount = 0
        tempCount = 0
        fuelCount = 0

        vehicleCounts.removeAll()
    }
}
