//
//  DashboardView.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2023-12-03.
//

// View
import SwiftUI
import RealmSwift

struct DashboardView: View {

    @StateObject var dashboardOO = DashboardOO()
    @StateObject var geoListOO = GeofenceOO()
    
    var id: String

    var body: some View {
        NavigationStack {
            ScrollView {

                NavigationLink(destination: MyProfile()) {
                    DashboardHeader()
                        .padding()
                }.buttonStyle(.plain)



                // Vehicle Status
                Section(header:
                            HStack {
                    Text("Vehicle Status")
                        .foregroundStyle(.appPrimaryDark)
                    Spacer()
                }.padding()

                ){
                    HStack {
                        UTrackStatusCard(image: Status.dashboard_all, title: "All", subtitle: "\(dashboardOO.allCount)")
                        UTrackStatusCard(image: Status.dashboard_moving, title: "Moving", subtitle: "\(dashboardOO.movingCount)")
                        UTrackStatusCard(image: Status.dashboard_stopped, title: "Stopped", subtitle: "\(dashboardOO.stoppedCount)")
                        UTrackStatusCard(image: Status.dashboard_no_data, title: "No Data", subtitle: "\(dashboardOO.noDataCount)")
                    }
                } // Vehicle

                // Groups
                Section(header:
                            HStack {
                    Text("My Groups")
                        .foregroundStyle(.appPrimaryDark)
                    Spacer()
                }.padding()

                ){
                    Text("No Groups Found.")
                } // Group


                // Product Types
                Section(header:
                            HStack {
                    Text("Product Types")
                        .foregroundStyle(.appPrimaryDark)
                    Spacer()
                }.padding()

                ){
                    LazyHGrid(rows: [GridItem(), GridItem()]) {
                        ImageTitleView(image: Product.dashboard_basic, title: "Basic(\(dashboardOO.basicCount))")
                        ImageTitleView(image: Product.dashboard_id_card, title: "ID Card(\(dashboardOO.idCount))")
                        ImageTitleView(image: Product.dashboard_magnetic, title: "Magnetic(\(dashboardOO.magneticCount))")
                        ImageTitleView(image: Product.dashboard_car_stereo, title: "Car Stereo(\(dashboardOO.carCount))")

                        ImageTitleView(image: Product.dashboard_mobile, title: "Mobile(\(dashboardOO.mobileCount))")
                        ImageTitleView(image: Product.dashboard_temperature, title: "Temperature(\(dashboardOO.tempCount))")
                        ImageTitleView(image: Product.dashboard_obd, title: "OBD(\(dashboardOO.obdCount))")
                        ImageTitleView(image: Product.dashboard_fuel, title: "Fuel(\(dashboardOO.fuelCount))")
                    }
                } // Product

                // Asset Types
                Section(header:
                            HStack {
                    Text("Asset Types")
                        .foregroundStyle(.appPrimaryDark)
                    Spacer()
                }.padding()
                ){
                    LazyVGrid(columns: [GridItem(), GridItem(), GridItem(), GridItem()]) {
                        ForEach(dashboardOO.vehicleCounts.sorted(by: >), id: \.key){ assetName, count in
                            ImageTitleView(image: "ic_asset_type_\(assetName.lowercased())", title: "\(assetName)(\(count))")
                        }
                    }.padding(.horizontal, 25)

                } // Product



            }.listStyle(.plain)
                .onAppear {
                    print("Dashboard ID: \(id)")
                    dashboardOO.getDashboardData(for: id)
                    geoListOO.getGeofenceList(userId: id)
                }
                .refreshable {
                    print("Refreshing")
                    dashboardOO.getDashboardData(for: id)

                }
        }// Nav
    }
}

