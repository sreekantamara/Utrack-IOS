//
//  DashboardObject.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2023-12-03.
//

// Data Object
import Foundation

struct DashboardObject {

}
