//
//  MainView.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2023-12-09.
//

import SwiftUI
import RealmSwift

struct MainView: View {

    @ObservedResults(LoginObject.self) var loginItems
    
    @State var selectedTab: TabSelection = .Dashboard
    @State var selectedList: ListSelection = .all

    @State var isLoggedIn = false
    @State var dataSaved = false

    @State var reportPage: ReportType = .none

    @State var userId: String = ""
    @State var deviceId: String = ""
    @State var deviceLinkId: String = ""
    @State var deviceName: String = "Car"
    @State var deviceColor: Color = .red


    var body: some View {

        if let li = loginItems.last, let item = li.data.first, let id = item.userId {

            switch reportPage {
                case .none:
                    TabView(selection: $selectedTab,
                            content:  {
                        // Dashboard View
                        DashboardView(id: id)
                            .tabItem {
                                Text("Dashboard")
                            }.tag(TabSelection.Dashboard)

                        // List View
                        VehicleListView(selection: selectedList, reportPage: $reportPage, userId: $userId, deviceId: $deviceId, deviceLinkId: $deviceLinkId, deviceName: $deviceName, deviceColor: $deviceColor)
                            .tabItem {
                                Text("List")
                            }.tag(TabSelection.List)

                        // Map View
                        VehicleMapView()
                            .tabItem {
                                Text("Map")
                            }.tag(TabSelection.Map)
                    })
                case .dashboard:
                    DashboardReportView(reportPage: $reportPage)
                    //DataTable()
                case .liveTracking:
                    LiveTracking(reportPage: $reportPage, userId: userId, deviceId: deviceId, deviceLinkId: deviceLinkId, deviceName: deviceName, deviceColor: deviceColor)
                case .trackNearest:
                    TrackNearest(reportPage: $reportPage, selectedFence: GeofenceData())
                case .trackHistory:
                    TrackHistory(reportPage: $reportPage, deviceId: deviceId, deviceName: deviceName, deviceColor: deviceColor)
                case .summary:
                    SummaryReport(reportPage: $reportPage, deviceLinkId: $deviceLinkId)
                case .stoppage:
                    StoppageReport(reportPage: $reportPage)
                case .track:
                    TrackReport(reportPage: $reportPage)
                case .distance:
                    DistanceReport(reportPage: $reportPage)
                case .dailyKm:
                    DailyKMReport(reportPage: $reportPage)
                case .hour24Analysis:
                    Hour24AnalysisReport(reportPage: $reportPage)
                case .geofence:
                    GeofenceReport(reportPage: $reportPage)
                case .geoToGeo:
                    GeoToGeoReport(reportPage: $reportPage)
                case .overspeed:
                    OverspeedReport(reportPage: $reportPage, deviceLinkId: $deviceLinkId, userId: $userId)
                case .kmMonthly:
                    KMMonthlyViewReport(reportPage: $reportPage, selectedFromDate: Date())
            }



        } else {
            LoginView(isLoggedIn: $isLoggedIn)
        }
    }
}
