//
//  VehicleListObject.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2023-12-09.
//

// Data Object
import Foundation

struct VehicleListObject: Identifiable {
    let id = UUID()
}
