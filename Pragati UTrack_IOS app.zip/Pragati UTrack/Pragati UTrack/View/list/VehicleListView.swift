//
//  VehicleListView.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2023-12-09.
//

// View
import SwiftUI
import RealmSwift
import AlertKit

struct VehicleListView: View {

    @State private var index: Int? = nil

    var options = ["All", "Moving", "Stopped", "Data Not Found", "Basic", "Magnetic", "Mobile", "OBD", "ID Card",
    "Car Stereo", "Temperature", "Fuel"]
    @State private var filterSelection = "All"

    var selection: ListSelection

    @ObservedResults(DashboardListMap.self) var listItems

    @State var searchedText: String = ""

    @StateObject var customAlertManager = CustomAlertManager()

    @Binding var reportPage: ReportType
    @Binding var userId: String
    @Binding var deviceId: String
    @Binding var deviceLinkId: String
    @Binding var deviceName: String
    @Binding var deviceColor: Color

    @State var isSheetOpen = false

    @State var isLessView = false


    var body: some View {
        NavigationStack {
            VStack {
                HStack {
                    UTrackGradientButton(buttonTitle: "Help", width: 80, smallerFont: true){
                        customAlertManager.show()
                    }

                    UTrackGradientButton(buttonTitle: "Dashboard Report", width: 100, smallerFont: true){
                        reportPage = .dashboard
                    }

                    UTrackGradientButton(buttonTitle: isLessView ? "Show More" : "Show Less", width: 80, smallerFont: true){
                        withAnimation {
                            isLessView.toggle()
                        }

                    }
                }

                HStack {

                    TextField("Search...", text: $searchedText)
                        .textFieldStyle(.roundedBorder)
                    Button(action: {
                        // Perform search based on searchText
                        print("Seaching for \(searchedText)")
                    }) {
                        Image(systemName: "magnifyingglass")
                            .foregroundColor(.gray)
                    }

                    Button(action: {
                        // Perform search based on searchText
                        print("Filtering for \(searchedText)")
                    }) {
                        Picker("", selection: $filterSelection) {
                            ForEach(options, id: \.self){
                                Text($0)
                            }
                        }
                    }

                }.padding(.horizontal, 20)

                ScrollView {
                    Spacer(minLength: 5)
                    if let listData = listItems.last?.data {
                        ForEach(listData.filter({ device in
                            // all and no search
                            if searchedText.isEmpty && filterSelection.elementsEqual(options[0]) {return true}


                            // no search and prodType/moving status
                                if searchedText.isEmpty && (device.productType.lowercased().elementsEqual(filterSelection.lowercased())) {return true}


                            // no search and movement status
                            if searchedText.isEmpty && (getDeviceStatus(deviceTime: device.devicetime, speed: device.speed).rawValue.elementsEqual(filterSelection.lowercased())) {return true}

                            // search and filter type
                            return (device.vehicleName.lowercased().contains(searchedText.lowercased())) && ((device.vehicleType.lowercased().elementsEqual(filterSelection.lowercased())) || getDeviceStatus(deviceTime: device.devicetime, speed: device.speed).rawValue.elementsEqual(filterSelection.lowercased()))

                        })){ item in

                            if isLessView {

                                VehicleListCardLess(item: item)
                                    .onTapGesture {
                                        deviceId = item.deviceId
                                        deviceLinkId = item.deviceLinkId
                                        userId = item.customerId
                                        deviceName = item.vehicleType
                                        deviceColor = getDeviceColor(getDeviceStatus(deviceTime: item.devicetime, speed: item.speed))
                                        isSheetOpen.toggle()
                                    }

                            } else {

                                VehicleListCard(item: item)
                                    .onTapGesture {
                                        deviceId = item.deviceId
                                        deviceLinkId = item.deviceLinkId
                                        userId = item.customerId
                                        deviceName = item.vehicleType
                                        deviceColor = getDeviceColor(getDeviceStatus(deviceTime: item.devicetime, speed: item.speed))
                                        isSheetOpen.toggle()
                                    }
                            }



                        }
                    } else {
                        Text("No Data Found")
                    }
                }.listStyle(.plain)
                    .padding(.top, 10)
            }
            .customAlert(manager: customAlertManager, content: {
                ListHelpView()
            }, buttons: [
                .cancel(content: {
                    Text("Dismiss")
                })
            ])


        }.sheet(isPresented: $isSheetOpen, content: {
            ListReportSheet() { index in
                self.index = index
                isSheetOpen.toggle()
                moveToReportPage(forIndex: index)
            }
            .presentationDetents([.fraction(0.5)])

        })

    }

    private func moveToReportPage(forIndex index: Int?){
        switch index {
            case 0:
                reportPage = .liveTracking
            case 1:
                reportPage = .trackNearest
            case 2:
                reportPage = .trackHistory
            case 3:
                reportPage = .summary
            case 4:
                reportPage = .stoppage
            case 5:
                reportPage = .track
            case 6:
                reportPage = .distance
            case 7:
                reportPage = .dailyKm
            case 8:
                reportPage = .hour24Analysis
            case 9:
                reportPage = .geofence
            case 10:
                reportPage = .geoToGeo
            case 11:
                reportPage = .overspeed
            case 12:
                reportPage = .kmMonthly
            default:
                reportPage = .none
        }
    }

}

