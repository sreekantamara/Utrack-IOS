//
//  KMMonthlyViewReport.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-01-17.
//

import SwiftUI
import PagerTabStripView
import RealmSwift

struct KMMonthlyViewReport: View {
    @Binding var reportPage: ReportType

    @ObservedResults(DashboardListMap.self) var listItems
    @StateObject var monthlyOO = MonthlyOO()

    @State var vehicleList = [Device]()
    @State var vehicleListNames = [String]()
    @State var deviceLinkId = "" // vehicle number actually


    @State var selection = 0
    @State var selectedFromDate: Date
    @State var userId = ""

    @State var deviceLinkIds = Set<String>()


    var body: some View {

        VStack {
            ZStack {
                HStack(alignment: .center) {
                    Text("Monthly Way Points Report")
                        .bold()
                        .font(.headline)
                }

                Button(action: {
                    reportPage = .none
                }, label: {
                    Image(systemName: "arrow.left")
                        .resizable()
                        .frame(width: 20, height: 18)
                }).position(x: 20,  y: 15)
            }.frame(height: 30)

            HStack {
                VStack {
                    Text("Select Month")
                    DatePicker("", selection: $selectedFromDate, displayedComponents: .date)
                        .labelsHidden()
                        .transformEffect(.init(scaleX: 0.7, y: 0.7))
                        .offset(x: 30)
                }
                Spacer()
                VStack {
                    Text("Select Vehicle")
                        .font(.caption)
                        .bold()
                    Picker("", selection: $deviceLinkId) {
                        ForEach(vehicleList, id: \.self){
                            let str = "\($0.vehicleNumber) \($0.vehicleType.isEmpty ? "" : "("+$0.vehicleType+")")"
                            Text(str)
                                .tag($0.vehicleNumber)
                        }
                    }.tint(.black)
                }

            } // HStack for vehicle and date
            .padding(.horizontal, 10)


            PagerTabStripView(selection: $selection) {
                WPMonthly(data: $monthlyOO.wayPoints, headers: $monthlyOO.wayPointHeaders)
                    .pagerTabItem(tag: 0) {
                        Text("Way Points\nMonthly View")
                            .multilineTextAlignment(.center)
                            .onTapGesture {
                                selection = 0
                            }
                    }

                KMMonthly(data: $monthlyOO.kilometer, headers: $monthlyOO.kilometerHeaders)
                    .pagerTabItem(tag: 1) {
                        Text("Kilometer\nMonthly View")
                            .multilineTextAlignment(.center)
                            .onTapGesture {
                                selection = 1
                            }
                    }

                MonthlySummary(data: $monthlyOO.monthSummary)
                    .pagerTabItem(tag: 2) {
                        Text("Monthly\nSummary")
                            .multilineTextAlignment(.center)
                            .onTapGesture {
                                selection = 2
                            }
                    }

                DetailedView(data: $monthlyOO.detail)
                    .pagerTabItem(tag: 3) {
                        Text("Detailed\nView")
                            .multilineTextAlignment(.center)
                            .onTapGesture {
                                selection = 3
                            }
                    }
            }


        }
        .onAppear {
            selectedFromDate = Date(timeIntervalSinceNow: -24 * 60 * 60 )
            if monthlyOO.wayPoints.isEmpty {
                getItemNames()
            }

        }.modifier(ActivityIndicatorModifier(isLoading: monthlyOO.isLoading))
            .onChange(of: deviceLinkId) { newValue in
                if newValue == "All" || deviceLinkId == "All" {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.0){
                        switch selection {
                            case 0:
                                monthlyOO.setWaypoints(for: "All")
                            case 1:
                                monthlyOO.setKm(for: "All")
                            case 2:
                                monthlyOO.setSummary(for: "All")
                            case 3:
                                monthlyOO.setDetails(for: "All")
                            default:
                                print("Invalid KMM")
                        }
                    }
                } else {
                    monthlyOO.setWaypoints(for: newValue)
                    monthlyOO.setKm(for: newValue)
                    monthlyOO.setDetails(for: newValue)
                    monthlyOO.setSummary(for: newValue)
                }
            }
    }

    func getItemNames(){
        vehicleList.removeAll()
        if let listData = listItems.last?.data {
            let device = Device()
            device.vehicleType = ""
            device.vehicleNumber = "All"
            device.deviceLinkId = "x"
            vehicleList.append(device)

            for item in listData {
                let str = "\(item.vehicleName) (\(item.vehicleType))"
                vehicleListNames.append(str)
                self.userId = item.customerId
                self.vehicleList.append(item)
                self.deviceLinkIds.insert(item.deviceLinkId)
            }



            monthlyOO.getMonthlyWaypoints(
                userId: userId,
                reportDate: selectedFromDate
            )


        }


    }



}
