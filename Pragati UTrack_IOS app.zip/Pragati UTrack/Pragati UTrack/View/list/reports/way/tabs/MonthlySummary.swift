//
//  MonthlySummary.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-02-07.
//

import SwiftUI

struct MonthlySummary: View {
    @Binding var data: [[String]]
    var headers = ["Id", "Vehicle Number", "Total Month Distance (KM)", "Total Waypoints Count"]
    var body: some View {
        VStack{
            Spacer(minLength: 20)
            DataTable(headers: headers, data: data, extended: false)
        }
    }
}
