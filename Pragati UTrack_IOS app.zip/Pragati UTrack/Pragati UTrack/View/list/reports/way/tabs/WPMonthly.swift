//
//  WPMonthly.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-02-07.
//

import SwiftUI

struct WPMonthly: View {
    @Binding var data: [[String]]
    @Binding var headers: [String]

    var body: some View {
        VStack{
            Spacer(minLength: 20)
            DataTable(headers: headers, data: data, extended: false)
        }

    }
}
