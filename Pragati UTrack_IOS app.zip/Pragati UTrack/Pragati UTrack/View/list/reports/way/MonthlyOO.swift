//
//  MonthlyOO.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-01-22.
//

import Foundation
import RealmSwift

class MonthlyOO: ObservableObject {
    @Published var isLoading = false
    
    @Published var wayPointHeaders = [String]()
    @Published var wayPoints: [[String]] = [[String]]()
    
    @Published var kilometerHeaders = [String]()
    @Published var kilometer: [[String]] = [[String]]()


    @Published var monthSummary: [[String]] = [[String]]()

    @Published var detail: [[String]] = [[String]]()

    @Published var monthItem: MonthlyWaypointReportObject = MonthlyWaypointReportObject()

    func getMonthlyWaypoints(userId: String, reportDate: Date){
        isLoading = true

        var request = URLRequest(url: URL(string: "https://www.pragatiutrack.com/api/user/monthly_waypoints_count_report?user_id=\(userId)&user_type=Customer&device_token=Web&report_date=\(reportDate.formatDateToStringShort())&is_slotted_vehicle_analysis=No")!,timeoutInterval: Double.infinity)
        request.addValue("FEA3E5D0QFCEBFD54F0A6A674ECAE3F8", forHTTPHeaderField: "X-Api-Key")
        
        request.httpMethod = "GET"


        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {

                self.isLoading = false
                guard let data = data else {
                    print(String(describing: error))
                    return
                }

                do {
                    let decoder = JSONDecoder()
                    decoder.keyDecodingStrategy = .convertFromSnakeCase
                    let obj = try decoder.decode(MonthlyWaypointReportObject.self, from: data)
                    if obj.status == true {
                        self.monthItem = obj
                        self.setWaypoints(for: "All")
                        self.setKm(for: "All")
                        self.setSummary(for: "All")
                        self.setDetails(for: "All")
                    }

                } catch {
                    print("Month Throw \(error)")
                }
            }
        }

        task.resume()

    }



    func setWaypoints(for vehicleNumber: String) {
        wayPoints.removeAll()
        wayPointHeaders.removeAll()

        wayPointHeaders.append("Id")
        wayPointHeaders.append("Vehicle Name")

        if let firstItem = monthItem.data.first {
            if let monthData = firstItem.thisMonth {
                let detailCount = monthData.detail.count

                for day in 1...detailCount {
                    wayPointHeaders.append("\(day)")
                }
            }
        }

        var serial = 1

        for item in monthItem.data {

            if vehicleNumber == item.vehicleNumber || vehicleNumber == "All" {
                if let monthData = item.thisMonth {
                    var temp = [String]()
                    temp.append("\(serial)")
                    temp.append(item.vehicleNumber)

                    for xyz in monthData.detail {
                        temp.append(xyz.wayPointsCount)
                    }
                    wayPoints.append(temp)
                } // iflet
            }
            serial += 1
        }
    }

    func setKm(for vehicleNumber: String){
        kilometer.removeAll()
        kilometerHeaders.removeAll()


        kilometerHeaders.append("Id")
        kilometerHeaders.append("Vehicle Name")

        if let firstItem = monthItem.data.first {
            if let monthData = firstItem.thisMonth {
                let detailCount = monthData.detail.count

                for day in 1...detailCount {
                    kilometerHeaders.append("\(day)")
                }
            }
        }

        var serial = 1

        for item in monthItem.data {

            if vehicleNumber == item.vehicleNumber || vehicleNumber == "All" {
                if let monthData = item.thisMonth {
                    var temp = [String]()
                    temp.append("\(serial)")
                    temp.append(item.vehicleNumber)

                    for xyz in monthData.detail {
                        temp.append(xyz.totalDistance)
                    }
                    kilometer.append(temp)
                } // iflet
            }
            serial += 1
        }
    } // func

    func setSummary(for vehicleNumber: String){
        monthSummary.removeAll()
        var serial = 1

        for item in monthItem.data {

            if vehicleNumber == item.vehicleNumber || vehicleNumber == "All" {
                if let monthData = item.thisMonth {
                    var temp = [String]()
                    temp.append("\(serial)")
                    temp.append(item.vehicleNumber)
                    temp.append(monthData.totalDistance)
                    temp.append(monthData.wayPointsCount)
                    monthSummary.append(temp)
                } // iflet
            }
            serial += 1
        }

    } // func

    func setDetails(for vehicleNumber: String){
        detail.removeAll()


        var serial = 1
        for item in monthItem.data {

            if vehicleNumber == item.vehicleNumber || vehicleNumber == "All" {
                if let monthData = item.thisMonth {
                    var temp = [String]()

                    for xyz in monthData.detail {
                        temp.append("\(serial)")
                        temp.append(item.vehicleNumber)
                        temp.append(xyz.reportDate)
                        temp.append(xyz.totalDistance)
                        temp.append(xyz.wayPointsCount)
                        serial += 1
                    }

                    detail.append(temp)
                } // iflet
            }

        }


    } // func

}
