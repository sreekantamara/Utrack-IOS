//
//  SummaryReport.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-01-17.
//

import SwiftUI
import PagerTabStripView
import RealmSwift

struct SummaryReport: View {
    @Binding var reportPage: ReportType
    @ObservedResults(DashboardListMap.self) var listItems
    @StateObject var overspeedOO = SummaryOO()

    @State var vehicleList = [Device]()
    @State var vehicleListNames = [String]()

    @Binding var deviceLinkId: String

    // for call
    @State var userId = ""
    @State var selection = 0

    var body: some View {

        VStack {
            ZStack {
                HStack(alignment: .center) {
                    Text("Summary Report")
                        .bold()
                        .font(.headline)
                }

                Button(action: {
                    reportPage = .none
                }, label: {
                    Image(systemName: "arrow.left")
                        .resizable()
                        .frame(width: 20, height: 18)
                }).position(x: 20,  y: 15)
            }.frame(height: 30)

            HStack {
                Text("Select Vehicle")
                    .font(.caption)
                    .bold()
                Picker("", selection: $deviceLinkId) {
                    ForEach(vehicleList, id: \.self){
                            var str = "\($0.vehicleNumber) (\($0.vehicleType))"
                            Text(str)
                                .tag($0.deviceLinkId)
                    }
                }.tint(.black)
            }
            PagerTabStripView(selection: $selection) {
                SummaryReport1(overspeedOO: overspeedOO)
                    .pagerTabItem(tag: 0) {
                        Text("Summary Report")
                            .onTapGesture {
                                selection = 0
                            }
                    }

                SummaryReport2(overspeedOO: overspeedOO)
                    .pagerTabItem(tag: 1) {
                        Text("Kilometer Report")
                            .onTapGesture {
                                selection = 1
                            }
                    }

                SummaryReport3(overspeedOO: overspeedOO)
                    .pagerTabItem(tag: 2) {
                        Text("Charts")
                            .onTapGesture {
                                selection = 2
                            }
                    }
            }
        }

        .onAppear {
            if overspeedOO.overSpeedItem.data.isEmpty {
                getItemNames()
            }
        }.modifier(ActivityIndicatorModifier(isLoading: overspeedOO.isLoading))
            .onChange(of: deviceLinkId) { newValue in
                overspeedOO.getOverSpeedReport(userId: userId, singleDeviceLinkId: deviceLinkId)
            }
    }

    func getItemNames(){
        vehicleList.removeAll()
        if let listData = listItems.last?.data {
            for item in listData {
                let str = "\(item.vehicleName) (\(item.vehicleType))"
                vehicleListNames.append(str)
                self.userId = item.customerId
                self.vehicleList.append(item)
            }
        }

        overspeedOO.getOverSpeedReport(userId: userId, singleDeviceLinkId: deviceLinkId)

    }
}
