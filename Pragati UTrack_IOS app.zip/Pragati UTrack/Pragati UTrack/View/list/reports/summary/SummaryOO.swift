//
//  SummaryOO.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-01-21.
//

import Foundation
import RealmSwift

class SummaryOO: ObservableObject {
    @Published var isLoading = false

    @Published var monthyRoot = Last7()
    @Published var weeklyRoot = Last7()
    @Published var sevenRoot = Last7()
    @Published var todayRoot = Today()


    @Published var cellItems: [[String]] = [[String]]()

    @Published var overSpeedItem = OverSpeedObject()


    func getOverSpeedReport(userId: String, singleDeviceLinkId: String){
        print("Getting OS/Summary for  DL: \(singleDeviceLinkId) and U: \(userId)")
        isLoading = true


        let url = URL(string: "https://pragatiutrack.com/api/user/single_device_report_stats_v1?user_id=\(userId)&user_type=Customer&device_link_id=\(singleDeviceLinkId)&report_date=\(Date().formatDateToStringShort())")!

        var request = URLRequest(url: url,timeoutInterval: Double.infinity)
        request.addValue("FEA3E5D0QFCEBFD54F0A6A674ECAE3F8", forHTTPHeaderField: "X-Api-Key")


        request.httpMethod = "GET"


        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                self.isLoading = false

                guard let data = data else {
                    print(String(describing: error))
                    return
                }

                do {
                    let decoder = JSONDecoder()
                    decoder.keyDecodingStrategy = .convertFromSnakeCase
                    let obj = try decoder.decode(OverSpeedObject.self, from: data)
                    if obj.status == true {
                        self.overSpeedItem = obj
                        self.summarizeOverSpeedObject()
                    }
                } catch {
                    print("DailyKMReportObject Throw \(error)")
                }

            }
        }

        task.resume()

    }

    func summarizeOverSpeedObject() {
        print("OS: \(self.overSpeedItem)")
        if let data = overSpeedItem.data.first,
           let today = data.today,
           let last7 = data.last7,
           let thisWeek = data.thisWeek,
           let thisMonth = data.thisMonth {
            todayRoot = today
            weeklyRoot = thisWeek
            sevenRoot = last7
            monthyRoot = thisMonth
        }
    }

    func getMonthly(){
        cellItems = monthyRoot.transformToArray()
    }

    func getThisWeek(){
        cellItems = weeklyRoot.transformToArray()
    }

    func get7Days(){
        cellItems = sevenRoot.transformToArray()
    }


}
