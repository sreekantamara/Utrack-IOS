//
//  SummaryReport3.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-01-21.
//

import SwiftUI
import Charts

struct SummaryReport3: View {
    @ObservedObject var overspeedOO: SummaryOO
    var options = ["This Month", "This Week", "Last 7 Days"]
    @State var selection = "This Month"

    var body: some View {
        VStack {
            Picker("Chart View Type", selection: $selection) {
                ForEach(options, id: \.self) {
                    Text($0)
                        .tag($0)
                }
            }.tint(.black)

            Chart {
                ForEach(overspeedOO.cellItems, id: \.self) { item in
                    if getValue(item) > 0 {
                        BarMark(
                            x: .value("Day", item[1]),
                            y: .value("Kilometer", getValue(item))
                        )
                    }

                }
            }
            .chartYAxisLabel(position: .leading, content: {
                Text("Kilometer")
            })
            .chartXAxisLabel(position: .top, content: {
                Text("Date")
            })
            .aspectRatio(1, contentMode: .fit)
            .padding()

        }.onAppear {
            overspeedOO.getMonthly()
        }
        .onChange(of: selection) { newValue in
            if newValue == options[0] {
                overspeedOO.getMonthly()
            } else if newValue == options[1] {
                overspeedOO.getThisWeek()
            } else {
                overspeedOO.get7Days()
            }

        }

    }

    func getValue(_ items: [String])->Double{
        if let km = Double(items[3]) {
            return km
        } else {
            return 0
        }
    }
}
