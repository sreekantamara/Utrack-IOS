//
//  SummaryReport1.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-01-21.
//

import SwiftUI

struct SummaryReport1: View {
    @ObservedObject var overspeedOO: SummaryOO

    var body: some View {
        VStack(spacing: 5) {
            OverspeedCard(
                cardTitle: "Today",
                totaldistance: $overspeedOO.todayRoot.td,
                travelTime: $overspeedOO.todayRoot.ttt,
                maxSpeed: $overspeedOO.todayRoot.ms,
                avgSpeed: $overspeedOO.todayRoot.todayAs
            )

            OverspeedCard(
                cardTitle: "Last 7 Days",
                totaldistance: $overspeedOO.sevenRoot.td,
                travelTime: $overspeedOO.sevenRoot.ttt,
                maxSpeed: $overspeedOO.sevenRoot.ms,
                avgSpeed: $overspeedOO.sevenRoot.last7_As
            )

            OverspeedCard(
                cardTitle: "This Week",
                totaldistance: $overspeedOO.weeklyRoot.td,
                travelTime: $overspeedOO.weeklyRoot.ttt,
                maxSpeed: $overspeedOO.weeklyRoot.ms,
                avgSpeed: $overspeedOO.weeklyRoot.last7_As
            )

            OverspeedCard(
                cardTitle: "This Month",
                totaldistance: $overspeedOO.monthyRoot.td,
                travelTime: $overspeedOO.monthyRoot.ttt,
                maxSpeed: $overspeedOO.monthyRoot.ms,
                avgSpeed: $overspeedOO.monthyRoot.last7_As
            )

            Spacer()

        }
    }
}
