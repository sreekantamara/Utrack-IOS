//
//  SummaryReport2.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-01-21.
//

import SwiftUI

struct SummaryReport2: View {
    @ObservedObject var overspeedOO: SummaryOO

    var headers = ["ID", "Date", "Day", "Total Distance (KM)", "Travel Time (HH:MM:SS"]
    var options = ["This Month", "This Week", "Last 7 Days"]

    @State var selection = "This Month"

    var body: some View {
        VStack {
            Picker("Chart View Type", selection: $selection) {
                ForEach(options, id: \.self) {
                    Text($0)
                        .tag($0)
                }
            }.tint(.black)

            if overspeedOO.cellItems.isEmpty {
                Text("No Data")
                Spacer()
            } else {
                DataTable(headers: headers, data: overspeedOO.cellItems, extended: false)
            }


        }.onAppear {
            overspeedOO.getMonthly()
        }
        .onChange(of: selection) { newValue in
            if newValue == options[0] {
                overspeedOO.getMonthly()
            } else if newValue == options[1] {
                overspeedOO.getThisWeek()
            } else {
                overspeedOO.get7Days()
            }

        }

    }
}
