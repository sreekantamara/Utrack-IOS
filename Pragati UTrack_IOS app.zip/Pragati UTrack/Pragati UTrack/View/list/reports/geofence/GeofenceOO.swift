//
//  GeofenceOO.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-01-21.
//

import Foundation
import RealmSwift

class GeofenceOO: ObservableObject {
    @Published var isLoading = false
    @Published var cellItems: [[String]] = [[String]]()

    @Published var geofenceItem: GeofenceReportObject = GeofenceReportObject()
    @Published var geogeoItem: GeoToGeoReportObject = GeoToGeoReportObject()

    func getGeofenceReport(userId: String, toDate: String, fromDate: String, geoIds: String, deviceIds: String){
        isLoading = true
        var request = URLRequest(url: URL(string: "https://www.pragatiutrack.com/api/user/geofence_report_v1?user_id=\(userId)&user_type=Customer&device_token=Web&to_date_time=\(toDate)&from_date_time=\(fromDate)&geofence_id=\(geoIds)&device_id=\(deviceIds)")!,timeoutInterval: 60)
        request.addValue("FEA3E5D0QFCEBFD54F0A6A674ECAE3F8", forHTTPHeaderField: "X-Api-Key")

        request.httpMethod = "GET"
        print("Geo: \(request.url!)")

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {

                self.isLoading = false
                guard let data = data else {
                    print(String(describing: error))
                    return
                }
                do {
                    let decoder = JSONDecoder()
                    decoder.keyDecodingStrategy = .convertFromSnakeCase
                    let obj = try decoder.decode(GeofenceReportObject.self, from: data)
                    if obj.status == true {
                        self.geofenceItem = obj
                        self.setCellItems()
                    }

                } catch {
                    print("DailyKMReportObject Throw \(error)")
                }
            }
        }
        task.resume()

    }

    func getGeoGeoReport(userId: String, toDate: String, fromDate: String, deviceLinkIds: String, fromGeoIds: String, toGeoIds: String){
        isLoading = true

        let parameters = [
            [
                "key": "user_id",
                "value": "\(userId)",
                "type": "text"
            ],
            [
                "key": "device_link_ids",
                "value": "\(deviceLinkIds)",
                "type": "text"
            ],
            [
                "key": "from_date",
                "value": "\(fromDate)",
                "type": "text"
            ],
            [
                "key": "to_date",
                "value": "\(toDate)",
                "type": "text"
            ],
            [
                "key": "from_geofence_ids",
                "value": "\(fromGeoIds)",
                "type": "text"
            ],
            [
                "key": "to_geofence_ids",
                "value": "\(toGeoIds)",
                "type": "text"
            ]] as [[String : Any]]

        let boundary = "Boundary-\(UUID().uuidString)"
        var body = ""

        for param in parameters {
            if param["disabled"] == nil {
                let paramName = param["key"]!
                body += "--\(boundary)\r\n"
                body += "Content-Disposition:form-data; name=\"\(paramName)\""
                if param["contentType"] != nil {
                    body += "\r\nContent-Type: \(param["contentType"] as! String)"
                }
                let paramType = param["type"] as! String
                if paramType == "text" {
                    let paramValue = param["value"] as! String
                    body += "\r\n\r\n\(paramValue)\r\n"
                } else {
                    do {
                    let paramSrc = param["src"] as! String
                    let fileData = try NSData(contentsOfFile:paramSrc, options:[]) as Data
                    let fileContent = String(data: fileData, encoding: .utf8)!
                    body += "; filename=\"\(paramSrc)\"\r\n"
                    + "Content-Type: \"content-type header\"\r\n\r\n\(fileContent)\r\n"
                } catch {
                    print("GG: \(error)")
                }
            }
        }
    }
    body += "--\(boundary)--\r\n";
    let postData = body.data(using: .utf8)
    var request = URLRequest(url: URL(string: "https://www.pragatiutrack.com/api/user/geofence_to_geofence_report")!,timeoutInterval: Double.infinity)
    request.addValue("FEA3E5D0QFCEBFD54F0A6A674ECAE3F8", forHTTPHeaderField: "X-Api-Key")
    request.addValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")

    request.httpMethod = "POST"
    request.httpBody = postData
        

    let task = URLSession.shared.dataTask(with: request) { data, response, error in
        DispatchQueue.main.async {

            self.isLoading = false
            guard let data = data else {
                print(String(describing: error))
                return
            }
            do {
                let decoder = JSONDecoder()
                decoder.keyDecodingStrategy = .convertFromSnakeCase

                let obj = try decoder.decode(GeoToGeoReportObject.self, from: data)
                if obj.status == true {
                    self.geogeoItem = obj
                    self.setGGCellItems()
                }

            } catch {
                print("GG Throw \(error)")
            }
        }
    }
    task.resume()

}

func setCellItems(){
    cellItems.removeAll()
    for item in geofenceItem.data {
        var temp = [String]()
        temp.append(item.vehicleNumber)
        temp.append(item.geofenceName)
        temp.append(item.enterTime)
        temp.append(item.exitTime)
        temp.append(item.duration)
        cellItems.append(temp)
    }
}

    func setGGCellItems(){
        cellItems.removeAll()
        var lastIndex = 0
        for item in geogeoItem.data {
            var temp = [String]()

            temp.append("\(lastIndex+1)")
            temp.append(item.vehicleNumber)
            temp.append(item.fromGeofence)

            temp.append(item.toGeofence)
            temp.append(item.fromGeofenceDateTime)
            temp.append(item.toGeofenceDateTime)

            temp.append(item.durationFormat)
            temp.append(item.totalDistance)
            temp.append(item.maxSpeed)

            temp.append(item.avgSpeed)
            temp.append("\(item.averageMileage)")
            temp.append("\(item.totalFuelConsumed)")

            temp.append(item.startFuelLevel)
            temp.append(item.endFuelLevel)
            temp.append("\(item.refillsLiters)")

            temp.append("\(item.removalsLiters)")

            cellItems.append(temp)
            lastIndex += 1
        }
    }
















func getGeofenceList(userId: String){
    var request = URLRequest(url: URL(string: "https://www.pragatiutrack.com/api/user/geofence_list?user_type=Customer&device_token=Web&user_id=\(userId)")!,timeoutInterval: 60)
    request.addValue("FEA3E5D0QFCEBFD54F0A6A674ECAE3F8", forHTTPHeaderField: "X-Api-Key")

    request.httpMethod = "GET"

    let task = URLSession.shared.dataTask(with: request) { data, response, error in
        guard let data = data else {
            print(String(describing: error))
            return
        }
        do {
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            let obj = try decoder.decode(GeoFenceObject.self, from: data)
            if obj.status == true {
                //write to realm
                let loginRealm = try Realm()
                try! loginRealm.write{
                    loginRealm.delete(loginRealm.objects(GeoFenceObject.self))
                    loginRealm.add(obj)
                }
                print("Geofence List Added")

            }

        } catch {
            print("Geofence List Throw \(error)")
        }
    }

    task.resume()

}
}
