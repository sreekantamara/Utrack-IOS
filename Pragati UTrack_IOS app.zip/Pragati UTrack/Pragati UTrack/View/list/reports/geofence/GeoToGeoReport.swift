//
//  GeoToGeoReport.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-01-22.
//

import SwiftUI
import RealmSwift

struct GeoToGeoReport: View {
    @Binding var reportPage: ReportType
    var headers = ["ID","Vehicle Number", "From Geofence",
                   "To Geofence", "From Geofence Exit Time",

                   "To Geofence Exit Time", "Duration (HH:MM:SS)",
                   "Total Distance (KM)", "Max Speed (KMPH)",
                   "Avg Speed (KMPH)", "Mileage (KM/L)",

                   "Fuel Consumed  (Liters)", "Start Fuel Level (Liters)",
                   "End Fuel Levels (Liters)", "Refill Fuel (Liters)",
                   "Removed Fuel (Liters)" //16

    ]

    @State var selectedSegment = 0
    @StateObject var geofenceOO = GeofenceOO()

    @ObservedResults(DashboardListMap.self) var listItems
    @ObservedResults(GeoFenceObject.self) var geoItems

    @State var vehicleList = [Device]()

    @State var geofenceList = [GeofenceData]()
    @State var geofenceListNames = [String]()

    @State var selectedFromDate = Date(timeIntervalSinceNow: -24 * 60 * 60 )
    @State var selectedToDate = Date()

    // for call
    @State var userId = ""
    @State var deviceLinkIds = Set<String>()
    @State var geofenceIds = Set<String>()

    @State var vehicleNumbers = Set<String>()
    @State var geofenceNames = Set<String>()

    var body: some View {

        NavigationStack {
            VStack {
                ZStack {
                    HStack(alignment: .center) {
                        Text("Geofence to Geofence Report")
                            .bold()
                            .font(.headline)
                    }
                    
                    Button(action: {
                        reportPage = .none
                    }, label: {
                        Image(systemName: "arrow.left")
                            .resizable()
                            .frame(width: 20, height: 18)
                    }).position(x: 20,  y: 15)
                }.frame(height: 30)
                ReportDateSelectionCard3(
                    selectedFromDate: $selectedFromDate,
                    selectedToDate: $selectedToDate,
                    selection1Title: "Select Geofences",
                    selectionItems1: $geofenceList,
                    selectedOptions1: $geofenceNames,
                    selection2Title: "Select Vehicle",
                    selectionItems2: $vehicleList,
                    selectedOptions2: $vehicleNumbers,
                    segmentSelection: $selectedSegment) {

                        deviceLinkIds.removeAll()
                        for item in vehicleList {
                            if vehicleNumbers.contains(item.vehicleNumber) {
                                deviceLinkIds.insert(item.deviceLinkId)
                            }
                        }

                        geofenceIds.removeAll()
                        for item in geofenceList {
                            if geofenceNames.contains(item.geofenceName) {
                                geofenceIds.insert(item.geofenceId)
                            }
                        }

                        geofenceOO.getGeoGeoReport(userId: userId, toDate: selectedToDate.formatDateToString(), fromDate: selectedFromDate.formatDateToString(), deviceLinkIds: deviceLinkIds.joined(separator: ","), fromGeoIds: geofenceIds.joined(separator: ","), toGeoIds: geofenceIds.joined(separator: ","))
                    }.frame(maxHeight: 200)
                
                if geofenceOO.cellItems.isEmpty {
                    Text("No Data")
                    Spacer()
                } else {
                    DataTable(headers: headers, data: geofenceOO.cellItems, extended: selectedSegment == 1)
                }
                
                
                
            }.onAppear {
                getItemNames()
                
            }.modifier(ActivityIndicatorModifier(isLoading: geofenceOO.isLoading))
                .onChange(of: geofenceNames) { newValue in
                    print("Get Item called GeoGeo")
                    geofenceOO.getGeoGeoReport(userId: userId, toDate: selectedToDate.formatDateToStringShort(), fromDate: selectedFromDate.formatDateToStringShort(), deviceLinkIds: deviceLinkIds.joined(separator: ","), fromGeoIds: geofenceIds.joined(separator: ","), toGeoIds: geofenceIds.joined(separator: ","))
                }
        }
    }

    func getItemNames(){

        vehicleList.removeAll()
        if let listData = listItems.last?.data {
            for item in listData {
                self.userId = item.customerId
                self.vehicleNumbers.insert(item.vehicleNumber)
                self.vehicleList.append(item)
                self.deviceLinkIds.insert(item.deviceLinkId)
            }
        }

        geofenceList.removeAll()
        if let listData = geoItems.last?.data {
            for item in listData {
                geofenceListNames.append(item.geofenceName)
                self.userId = item.userId
                self.geofenceList.append(item)
                self.geofenceIds.insert(item.geofenceId)
                self.geofenceNames.insert(item.geofenceName)
            }
        }

    }
}

