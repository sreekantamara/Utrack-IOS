//
//  TrackNearest.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-01-19.
//

import RealmSwift
import SwiftUI

struct TrackNearest: View {
    @Binding var reportPage: ReportType
    @ObservedResults(GeoFenceObject.self) var geoItems
    @ObservedResults(MarkerData.self) var markerItems
    @State var items: [MarkerData] = [MarkerData]()

    @State var geofenceList = [GeofenceData]()
    @State var selectedFence: GeofenceData


    
    var body: some View {
        VStack {
            ZStack {
                HStack(alignment: .center) {
                    Text("Track Nearest")
                        .bold()
                        .font(.headline)
                }

                Button(action: {
                    reportPage = .none
                }, label: {
                    Image(systemName: "arrow.left")
                        .resizable()
                        .frame(width: 20, height: 18)
                }).position(x: 20,  y: 15)
            }.frame(height: 30)

                Picker("", selection: $selectedFence) {
                    ForEach(geofenceList, id: \.self) { option in
                        Text("\(option.geofenceName)")
                            .tag(option.geofenceId)

                    }
                }.tint(.black)


            TNMapView(geofence: $selectedFence, markers: items)



            Group {
                HStack {
                    LiveTrackText(boxname: "Location", text: selectedFence.geofenceName)
                    Spacer()
                }
                // Lat lon speed
                HStack {

                    LiveTrackText(boxname: "Radius(Meters)", text: selectedFence.radius)
                    Spacer()
                    LiveTrackText(boxname: "Latitude", text: selectedFence.latitude)
                    Spacer()
                    LiveTrackText(boxname: "Longitude", text: selectedFence.longitude)

                }
            }.padding(.horizontal, 10)


        }.onAppear {
            getItemNames()
            for item in markerItems {
                items.append(item)
            }
        }

    }

    func getItemNames(){
        geofenceList.removeAll()
        if let listData = geoItems.last?.data {
            let geofenceObject = GeofenceData()
            geofenceObject.geofenceName = "Select Geofence"
            geofenceObject.geofenceId = "999999"
            geofenceList.append(geofenceObject)

            for item in listData {
                self.geofenceList.append(item)
            }
        }

    }
}
