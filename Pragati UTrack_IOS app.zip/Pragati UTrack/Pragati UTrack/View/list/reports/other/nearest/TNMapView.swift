//
//  TNMapView.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-02-19.
//

import SwiftUI
import GoogleMapsUtils
import GoogleMaps

struct TNMapView: UIViewRepresentable {

    @Binding var geofence: GeofenceData
    var markers: [MarkerData]


    func makeCoordinator() -> TNCoordinator {
        TNCoordinator(parent: self)
    }

    func makeUIView(context: Context) -> GMSMapView {

        let camera = GMSCameraPosition.camera(withLatitude: 0, longitude: 0, zoom: 15.0)
        let mapView = GMSMapView.map(withFrame: CGRect.zero, camera: camera)
        mapView.isMyLocationEnabled = true

        mapView.delegate = context.coordinator


        drawGeofenceArea(on: mapView)
        return mapView
    }

    func updateUIView(_ uiView: GMSMapView, context: Context) {
        if let lat = Double(geofence.latitude),
           let lon = Double(geofence.longitude) {
            let camera = GMSCameraPosition.camera(withLatitude: lat, longitude: lon, zoom: 15.0)
            uiView.animate(to: camera)
        }

        drawGeofenceArea(on: uiView)
        
    }


    private func drawGeofenceArea(on mapView: GMSMapView) {
        mapView.clear()
        // Draw a circular geofence if radius is greater than 0
        if let radius = Double(geofence.radius),
           let lat = Double(geofence.latitude),
           let lon = Double(geofence.longitude){

                // Draw a polygon geofence
                print("Drawing Circle")
                let marker = GMSMarker()
            marker.position = CLLocationCoordinate2D(latitude: lat, longitude: lon)
            marker.map = mapView

                let circle = GMSCircle(position: CLLocationCoordinate2D(latitude: lat, longitude: lon), radius: radius)
                circle.strokeColor = .blue
                circle.fillColor = UIColor.blue.withAlphaComponent(0.2)
                circle.map = mapView


            for markerData in markers {

                let mPos = CLLocationCoordinate2D(latitude: markerData.latitude, longitude: markerData.longitude)
                let geofenceLocation = CLLocationCoordinate2D(latitude: lat, longitude: lon)
                let distance = mPos.distance(to: geofenceLocation)

                if distance <= radius {
                    let marker = GMSMarker()
                    marker.position = mPos
                    marker.title = markerData.vehicleNumber
                    if let type = markerData.vehicleType{
                        marker.icon = UIImage(named: type.getMarker(getDeviceColor(getDeviceStatus(deviceTime: markerData.deviceTime, speed: markerData.speed))))?.resized(to: CGSize(width: 25, height: 50))

                        if let course = markerData.course {
                            marker.rotation = CLLocationDegrees(course.toDouble())
                        }

                    }
                    marker.map = mapView
                }

            }

        }

    }

}
