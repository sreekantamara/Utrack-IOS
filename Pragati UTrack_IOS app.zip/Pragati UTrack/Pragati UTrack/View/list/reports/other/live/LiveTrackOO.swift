//
//  LiveTrackOO.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-02-10.
//

import Foundation
import Combine

class LiveTrackOO: ObservableObject {
    @Published var liveTrackObject: LiveTrackObject = LiveTrackObject()
    @Published var liveTrackStats: LiveTrackStatObject = LiveTrackStatObject()

    func fetchLiveData(userId: String, deviceId: String){
        var request = URLRequest(url: URL(string: "https://pragatiutrack.com/api/user/current_device_position?user_id=\(userId)&user_type=Customer&device_id=\(deviceId)")!,timeoutInterval: Double.infinity)
        request.addValue("FEA3E5D0QFCEBFD54F0A6A674ECAE3F8", forHTTPHeaderField: "X-Api-Key")

        request.httpMethod = "GET"

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data else {
                print(String(describing: error))
                return
            }
            
            DispatchQueue.main.async {
                do {
                    let decoder = JSONDecoder()
                    decoder.keyDecodingStrategy = .convertFromSnakeCase
                    let obj = try decoder.decode(LiveTrackObject.self, from: data)
                    if obj.status == true {
                            self.liveTrackObject = obj
                    }

                } catch {
                    print("LTO Throw \(error)")
                }
            }

        }

        task.resume()

    }


    func fetchLiveStatData(userId: String, deviceId: String, deviceLink: String, fromDate: String){
        var request = URLRequest(url: URL(string: "https://pragatiutrack.com/api/user/single_custom_device_report_stats_v1?user_id=\(userId)&user_type=Customer&device_id=\(deviceId)&device_link_id=\(deviceLink)&from_date=\(fromDate)&to_date=\(Date().formatDateToStringShort())")!,timeoutInterval: Double.infinity)
        
        request.addValue("FEA3E5D0QFCEBFD54F0A6A674ECAE3F8", forHTTPHeaderField: "X-Api-Key")

        request.httpMethod = "GET"

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data else {
                print(String(describing: error))
                return
            }

            DispatchQueue.main.async {
                do {
                    let decoder = JSONDecoder()
                    decoder.keyDecodingStrategy = .convertFromSnakeCase
                    let obj = try decoder.decode(LiveTrackStatObject.self, from: data)
                    if obj.status == true {
                        self.liveTrackStats = obj
                    }

                } catch {
                    print("LTSO Throw \(error)")
                }
            }

        }

        task.resume()

    }
}
