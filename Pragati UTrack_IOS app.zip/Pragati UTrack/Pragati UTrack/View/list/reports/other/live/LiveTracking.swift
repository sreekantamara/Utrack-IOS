//
//  LiveTracking.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-01-19.
//

import SwiftUI

struct LiveTracking: View {
    @Binding var reportPage: ReportType
    
    @ObservedObject var liveTrackOO = LiveTrackOO()

    var userId: String
    var deviceId: String
    var deviceLinkId: String
    var deviceName: String
    var deviceColor: Color

    @State var selectedButton = 0
    @State var isDataVisible = true

    @State var isAutoZoom = true
    @State var isZoom = true
    @State var isRotate = true

    @State var timer: Timer?

    @State var serverTime = Date()

    @State var fromDate = Date()


    var body: some View {

        VStack(spacing: 0){
            ZStack {
                HStack(alignment: .center) {
                    Text("Live Tracking")
                        .bold()
                        .font(.headline)
                }

                Button(action: {
                    reportPage = .none
                }, label: {
                    Image(systemName: "arrow.left")
                        .resizable()
                        .frame(width: 20, height: 18)
                }).position(x: 20,  y: 15)
            }
            .frame(height: 30)



                if let item = liveTrackOO.liveTrackObject.data {
                    LiveMapView(
                        latitude: item.latitude.toDouble(),
                        longitude: item.longitude.toDouble(),
                        course: item.course.toDouble(),
                        markerName: deviceName,
                        color: deviceColor,
                        rotationLocked: $isRotate,
                        zoomLocked: $isZoom,
                        autoZoom: $isAutoZoom
                    )
                                    .overlay(LegendView(), alignment: .bottomTrailing)
                                    .overlay(MapZoomSettingsView(autoZoomSelected: $isAutoZoom, zoomSelected: $isZoom, rotateSelected: $isRotate).offset(CGSize(width: 10.0, height: 10.0)), alignment: .topLeading)



            HStack {
                Spacer()
                Text("Vehicle Current Details")
                    .bold()

                Spacer()
                Image(systemName: isDataVisible ? "chevron.down" : "chevron.up")
                    .padding()
            }.background(.appPrimaryDark)
            .foregroundStyle(.white)
            .onTapGesture {
                isDataVisible.toggle()
            }


                if isDataVisible {
                    Group {
                        // Data time
                        HStack {
                            LiveTrackText(boxname: "Last Received Received", text: item.devicetime)
                            Spacer()
                            LiveTrackText(boxname: "Last Data Received", text: serverTime.timeAgoDisplay())
                        }

                        // Lat lon speed
                        HStack {
                            LiveTrackText(boxname: "Latitude",text: item.latitude.latitudeWith4Decimal())
                            Spacer()
                            LiveTrackText(boxname: "Longitude",text: item.longitude.latitudeWith4Decimal())
                            Spacer()
                            LiveTrackText(boxname: "Speed",text: "\(item.speed) KMPH")
                        }

                        // Location
                        HStack {
                            LiveTrackText(boxname: "Location",text: item.lastLocation)
                            Spacer()
                        }

                    }.padding()
                        .frame(height: 50)
                }
            }



            // The text
            HStack {
                Rectangle()
                    .frame(width: 50, height: 1)
                    .foregroundColor(.appPrimaryDark)
                Text("Statistics")
                    .bold()
                    .foregroundStyle(.appPrimaryDark)
                Rectangle()
                    .frame(width: 50, height: 1)
                    .foregroundColor(.appPrimaryDark)
            }

            // the buttons
            HStack {
                UTrackBorderGradientButton(buttonTitle: "Today", width: 100, smallerFont: true, selected: selectedButton == 0){
                    selectedButton = 0
                    fromDate = Date()
                    liveTrackOO.fetchLiveStatData(userId: userId, deviceId: deviceId, deviceLink: deviceLinkId, fromDate: fromDate.formatDateToStringShort())
                }

                UTrackBorderGradientButton(buttonTitle: "Yesterday", width: 100, smallerFont: true, selected: selectedButton == 1){
                    selectedButton = 1
                    let currentDate = Date()
                    fromDate = Calendar.current.date(byAdding: .day, value: -1, to: currentDate)!
                    liveTrackOO.fetchLiveStatData(userId: userId, deviceId: deviceId, deviceLink: deviceLinkId, fromDate: fromDate.formatDateToStringShort())
                }

                UTrackBorderGradientButton(buttonTitle: "Last 7 Days", width: 100, smallerFont: true, selected: selectedButton == 2){
                    selectedButton = 2
                    let currentDate = Date()
                    fromDate = Calendar.current.date(byAdding: .day, value: -7, to: currentDate)!
                    liveTrackOO.fetchLiveStatData(userId: userId, deviceId: deviceId, deviceLink: deviceLinkId, fromDate: fromDate.formatDateToStringShort())

                }
            } // end buttons

            // the views
            if let data = liveTrackOO.liveTrackStats.data {
                HStack {
                    UTrackStatusCard(image: LiveTrackingIcon.avg_speed, title: "Avg Speed", subtitle: "\(data.avgSpeed) KMPH", isLiveTrack: true)
                    UTrackStatusCard(image: LiveTrackingIcon.max_speed, title: "Max Speed", subtitle: "\(data.maxSpeed) KMPH", isLiveTrack: true)
                    UTrackStatusCard(image: LiveTrackingIcon.travel_time, title: "Travel Time", subtitle: data.totalTravelledTime, isLiveTrack: true)
                    UTrackStatusCard(image: LiveTrackingIcon.total_distance, title: "Total Distance", subtitle: "\(data.totalDistance) KM", isLiveTrack: true)
                }
            }

        }
        .onAppear {
            liveTrackOO.fetchLiveData(userId: userId, deviceId: deviceId)
            liveTrackOO.fetchLiveStatData(userId: userId, deviceId: deviceId, deviceLink: deviceLinkId, fromDate: fromDate.formatDateToStringShort())
            startTimer()
        }
        .onDisappear {
            stopTimer()
        }.onChange(of: liveTrackOO.liveTrackObject) { newValue in
            print("Update Time")
            if let data = liveTrackOO.liveTrackObject.data {
                print("Server Time: \(data.latitude) \(data.longitude)")
                serverTime = data.devicetime.formatStringToDate()
            }
        }
    }

    private func startTimer() {
        timer = Timer.scheduledTimer(withTimeInterval: 5, repeats: true) { _ in

            liveTrackOO.fetchLiveData(userId: userId, deviceId: deviceId)

        }
        RunLoop.current.add(timer!, forMode: .common)
    }

    private func stopTimer() {
        timer?.invalidate()
        timer = nil
    }


}
