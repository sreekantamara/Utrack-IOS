//
//  LiveMapView.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-02-10.
//

import UIKit
import SwiftUI
import GoogleMaps

struct LiveMapView: UIViewRepresentable {

    var latitude: Double
    var longitude: Double
    var course: Double

    @State var zoomLevel: Float = 15.0
    @State var rotationLevel: Double = 0

    var markerTitle: String = "Marker"
    var markerName: String
    var color: Color

    @Binding var rotationLocked: Bool
    @Binding var zoomLocked: Bool
    @Binding var autoZoom: Bool

    func makeCoordinator() -> LiveMapCoordinator {
        LiveMapCoordinator(parent: self)
    }

    func makeUIView(context: Context) -> GMSMapView {

        let camera = GMSCameraPosition.camera(withLatitude: latitude, longitude: longitude, zoom: autoZoom ? 15.0 : zoomLevel, bearing: CLLocationDirection(rotationLevel), viewingAngle: 0)
        let mapView = GMSMapView.map(withFrame: CGRect.zero, camera: camera)
        mapView.isMyLocationEnabled = true
        
        mapView.delegate = context.coordinator

        mapView.settings.rotateGestures = rotationLocked
        mapView.settings.zoomGestures = zoomLocked

        // Add markers and path
        addMarker(to: mapView)

        return mapView
    }

    func updateUIView(_ uiView: GMSMapView, context: Context) {

        let camera = GMSCameraPosition.camera(withLatitude: latitude, longitude: longitude, zoom: autoZoom ? 15.0 : zoomLevel, bearing: CLLocationDirection(rotationLevel), viewingAngle: 0)

        uiView.animate(to: camera)
        addMarker(to: uiView)

        uiView.settings.rotateGestures = rotationLocked
        uiView.settings.zoomGestures = zoomLocked
    }

    private func addMarker(to mapView: GMSMapView) {
        mapView.clear()

        let marker = GMSMarker()
        marker.position = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
        marker.title = markerTitle
        marker.icon = UIImage(named: markerName.getMarker(color))?.resized(to: CGSize(width: 25, height: 50))
        marker.rotation = CLLocationDegrees(course)
        marker.map = mapView

    }
}
