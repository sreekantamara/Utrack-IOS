//
//  THMapView.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-02-10.
//

import UIKit
import SwiftUI
import GoogleMaps
import GoogleMapsUtils

struct THMapView: UIViewRepresentable {

    var markers: [THMarker]

    @State var zoomLevel: Float = 14.0

    // Add animated marker
    @State private var animatedMarker = GMSMarker()

    // play pause
    @Binding var isPlaying: Bool // playing or stopped

    @Binding var currentIndex: Int

    @Binding var crossedMarker: THMarker

    @State var timer: Timer?

    var markerName: String
    var color: Color

    @Binding var animationSpeed: Double


    func makeCoordinator() -> THCoordinator {
        THCoordinator(parent: self)
    }

    func makeUIView(context: Context) -> GMSMapView {
        var camera = GMSCameraPosition.camera(withLatitude: 0, longitude: 0, zoom: 12.0)
        let mapView = GMSMapView.map(withFrame: CGRect.zero, camera: camera)

        mapView.isMyLocationEnabled = true

        mapView.delegate = context.coordinator

        // Add markers and path
        addMarkers(to: mapView)

        guard let marker = markers.first else {return mapView}
        camera = GMSCameraPosition.camera(withLatitude: marker.lat, longitude: marker.lon, zoom: zoomLevel > 10 ? zoomLevel : 10)

        mapView.animate(to: camera)

        animatedMarker = GMSMarker()
        animatedMarker.title = "Vehicle"
        animatedMarker.icon = UIImage(named: markerName.getMarker(color))?
            .resized(to: CGSize(width: 25, height: 50))

        //drawPathBetweenMarkers(on: mapView)

        return mapView
    }

    func updateUIView(_ uiView: GMSMapView, context: Context) {

        if isPlaying {

                print("Starting")
                // first time
                if animatedMarker.map == nil {
                    animatedMarker.map = uiView
                    animateMarker(mapView: uiView)
                }


        } else {
            // Stop the animation
            if !markers.isEmpty {
                print("Stopping")
                stopAnimation()
            }

        }


    }

    private func addMarkers(to mapView: GMSMapView) {
        guard !markers.isEmpty else {return}
        mapView.clear()
        print("Markers: \(markers.count)")

        for (index, markerData) in markers.enumerated() {

            if index == 0 {
                let marker = GMSMarker()
                marker.position = CLLocationCoordinate2D(latitude: markerData.lat, longitude: markerData.lon)

                marker.title = "\(markerData.course)"

                marker.icon =  MarkerImageGenerator.imageWithText(text: "Start", unitText: "", markerColor: .green)

                marker.groundAnchor = CGPoint(x: 0.5, y: 1)
                marker.map = mapView

            } else if index == markers.count - 1 {
                let marker = GMSMarker()
                marker.position = CLLocationCoordinate2D(latitude: markerData.lat, longitude: markerData.lon)
                marker.title = "\(markerData.course)"

                marker.icon =  MarkerImageGenerator.imageWithText(text: "End", unitText: "", markerColor: .red)

                marker.groundAnchor = CGPoint(x: 0.5, y: 1)

                marker.map = mapView
            } else {
                let marker = GMSMarker()
                marker.position = CLLocationCoordinate2D(latitude: markerData.lat, longitude: markerData.lon)
                marker.title = "\(markerData.course)"

                if markerData.speed == 0 {
                    marker.icon =  MarkerImageGenerator.imageWithText(text: "\(calculateElapsedTime(from: index, to: index+1))", unitText: "mins", markerColor: .purple)
                } else {
                    marker.icon =  MarkerImageGenerator.imageWithText(text: "\(markerData.speed)", unitText: "kmph")
                }


                marker.groundAnchor = CGPoint(x: 0.5, y: 1)

                marker.map = mapView
            }

        }

    }

    func animateMarker(mapView: GMSMapView) {

        guard currentIndex + 1 < markers.count else {
            print("Animation paused or completed")

            return
        }

        let startLocation = markers[currentIndex].position
        let endLocation = markers[currentIndex + 1].position

        crossedMarker = markers[currentIndex]

        // Animate the marker between start and end locations
        let duration = 2.0 / animationSpeed // Set the duration based on your preferences
        let steps = 10 // Number of animation steps
        let stepDuration = duration / Double(steps)

        animatedMarker.rotation = getBearingBetweenPoints(point1: startLocation, point2: endLocation)

        startTimer(stepDuration, steps, mapView, startLocation, endLocation)
    }

    func startTimer(_ stepDuration: Double, _ steps: Int, _ mapView: GMSMapView, _ startLocation: CLLocationCoordinate2D, _ endLocation: CLLocationCoordinate2D){
        var stepCount = 0

        timer = Timer.scheduledTimer(withTimeInterval: stepDuration, repeats: true) { timer in
            guard stepCount < steps else {
                timer.invalidate()
                self.currentIndex += 1
                self.animateMarker(mapView: mapView) // Continue with the next position
                return
            }

            let interpolation = Double(stepCount) / Double(steps)
            let interpolatedLatitude = startLocation.latitude + interpolation * (endLocation.latitude - startLocation.latitude)
            let interpolatedLongitude = startLocation.longitude + interpolation * (endLocation.longitude - startLocation.longitude)
            let interpolatedPosition = CLLocationCoordinate2D(latitude: interpolatedLatitude, longitude: interpolatedLongitude)

            self.animatedMarker.position = interpolatedPosition

            mapView.animate(toLocation: interpolatedPosition)

            stepCount += 1
        }
    }


    func calculateElapsedTime(from startIndex: Int, to endIndex: Int) -> Int {
        guard markers.indices.contains(startIndex), markers.indices.contains(endIndex) else {
            return 0 // Invalid indices
        }

        let startTime = markers[startIndex].time
        let endTime = markers[endIndex].time

        let difference = endTime - startTime


        return difference > 60 ? difference / 60 : 1
    }


    // Function to stop the animation
    func stopAnimation() {
        timer?.invalidate()
        timer = nil
        animatedMarker.map = nil
        animatedMarker.position = markers.first!.position
    }

    func getBearingBetweenPoints(point1: CLLocationCoordinate2D, point2: CLLocationCoordinate2D) -> CLLocationDegrees {
        let lat1 = degreesToRadians(degrees: point1.latitude)
        let lon1 = degreesToRadians(degrees: point1.longitude)

        let lat2 = degreesToRadians(degrees: point2.latitude)
        let lon2 = degreesToRadians(degrees: point2.longitude)

        let dLon = lon2 - lon1

        let y = sin(dLon) * cos(lat2)
        let x = cos(lat1) * sin(lat2) - sin(lat1) * cos(lat2) * cos(dLon)

        let radiansBearing = atan2(y, x)

        return radiansToDegrees(radians: radiansBearing)
    }

    func degreesToRadians(degrees: CLLocationDegrees) -> Double {
        return degrees * .pi / 180.0
    }

    func radiansToDegrees(radians: Double) -> CLLocationDegrees {
        return radians * 180.0 / .pi
    }


    private func drawPathBetweenMarkers(on mapView: GMSMapView) {
        guard markers.count > 1 else { return }

        var path = GMSMutablePath()

        for i in 0..<markers.count - 1 {
            let currentMarker = markers[i]
            let nextMarker = markers[i + 1]

            let currentCoordinate = currentMarker.position
            let nextCoordinate = nextMarker.position

            // Add the line segment to the path
            path.add(currentCoordinate)
            path.add(nextCoordinate)

            // Create a polyline for the line segment
            let polyline = GMSPolyline(path: path)
            polyline.strokeColor = .blue
            polyline.strokeWidth = 4.0
            polyline.map = mapView

            // Move to the next segment by clearing the path
            path = GMSMutablePath()
        }
    }

}

