//
//  TrackHistory.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-01-19.
//

import SwiftUI
import RealmSwift

struct TrackHistory: View {

    @Binding var reportPage: ReportType
    var deviceId: String
    var deviceName: String
    var deviceColor: Color

    @ObservedResults(DashboardListMap.self) var listItems
    @StateObject var trackHistoryOO = THOO()

    @State var vehicleList = [Device]()
    @State var deviceLinkId = ""

    @State var selectedFromDate = Date(timeIntervalSinceNow: -2 * 24 * 60 * 60 )
    @State var selectedToDate = Date()

    @State var userId = ""

    @State var isPlaying = false

    @State var currentIndex = 0

    @State var crossedMarker = THMarker(speed: 0, course: 0, time: 0, distance: 0, lat: 0, lon: 0)
    @State var animationSpeed = 1.0
    @State var distanceTravelled = 0.0

    @State var value: Double = 0
    var maxValue: Int = 150


    var body: some View {
        VStack {
            ZStack {
                HStack(alignment: .center) {
                    Text("Track History")
                        .bold()
                        .font(.headline)

                    Picker("", selection: $deviceLinkId) {
                        ForEach(vehicleList, id: \.self){
                            let str = "\($0.vehicleNumber) (\($0.vehicleType))"
                            Text(str)
                                .tag($0.deviceLinkId)
                        }
                    }.tint(.black)
                }

                Button(action: {
                    reportPage = .none
                }, label: {
                    Image(systemName: "arrow.left")
                        .resizable()
                        .frame(width: 20, height: 18)
                }).position(x: 20,  y: 15)
            }.frame(height: 30)


            // Date selection
            HStack(alignment: .center) {
                VStack(alignment: .leading) {
                    Text("From")
                        .font(.caption)

                    DatePicker("", selection: $selectedFromDate, displayedComponents: .date)
                        .labelsHidden()
                        .transformEffect(.init(scaleX: 0.7, y: 0.7))
                        .offset(y: 5)
                }

                VStack(alignment: .leading) {
                    Text("To")
                        .font(.caption)

                    DatePicker("", selection: $selectedToDate, displayedComponents: .date)
                        .labelsHidden()
                        .transformEffect(.init(scaleX: 0.7, y: 0.7))
                        .offset(y: 5)
                }.offset(x: 20)

                UTrackGradientButton(
                    buttonTitle: "Search",
                    width: 60,
                    smallerFont: true
                ){
                    trackHistoryOO.getTrackHistory(userId: userId, deviceId: deviceId, deviceLink: deviceLinkId, fromDate: selectedFromDate.formatDateToStringShort()+" 00:00:00", toDate: selectedToDate.formatDateToString())
                }


            }.padding() // end date selection

            ZStack(alignment: .trailing) {
                THMapView(
                    markers: trackHistoryOO.thMarkers,
                    isPlaying: $isPlaying,
                    currentIndex: $currentIndex,
                    crossedMarker: $crossedMarker,
                    markerName: deviceName,
                    color: deviceColor,
                    animationSpeed: $animationSpeed
                )
                    .overlay(THLegendView(), alignment: .bottomTrailing)
                    .overlay(THLegendData(distance: trackHistoryOO.thObject.data?.deviceReportStatsCustom?.totalDistance ?? "0", mSpeed: trackHistoryOO.thObject.data?.deviceReportStatsCustom?.maxSpeed ?? "0", avSpeed: trackHistoryOO.thObject.data?.deviceReportStatsCustom?.avgSpeed ?? "0")
                        .offset(/*@START_MENU_TOKEN@*/CGSize(width: 10.0, height: 10.0)/*@END_MENU_TOKEN@*/)
                             , alignment: .topLeading)

                VStack(alignment: .trailing){

                    UTrackGradientButton(buttonTitle: isPlaying ? "Stop" : "Play", width: 50, smallerFont: true)
                        {
                            isPlaying.toggle()

                            if !isPlaying {
                                currentIndex = 0
                                crossedMarker = THMarker(speed: 0, course: 0, time: 0, distance: 0, lat: 0, lon: 0)
                            }

                        }
                            .offset(CGSize(width: -10.0, height: 10.0))

                    Spacer()
                    
                    if isPlaying {
                        GaugeView(coveredRadius: 225, maxValue: maxValue, steperSplit: 20, value: $crossedMarker.speed)
                            .offset(CGSize(width: -10.0, height: -50.0))
                    }


                }
            }

            if isPlaying {
                Group {
                    // Data time
                    HStack {
                        LiveTrackText(boxname: "Time", text: "\(Date(timeIntervalSince1970: TimeInterval(crossedMarker.time)).formatDateToString())")
                        Spacer()
                        LiveTrackText(boxname: "Speed", text: "\(crossedMarker.speed) KMPH")
                    }

                    // Lat lon speed
                    HStack {
                        LiveTrackText(boxname: "Latitude",text: "\(String(format: "%.4f", crossedMarker.lat))")
                        Spacer()
                        LiveTrackText(boxname: "Longitude",text: "\(String(format: "%.4f", crossedMarker.lon))")
                        Spacer()
                        LiveTrackText(boxname: "Distance",text: "\(String(format: "%.2f", distanceTravelled)) KM")
                    }

                    // Location
                    HStack {
                        LiveTrackText(boxname: "Speed",text: "\(animationSpeed) (Tap to change)").onTapGesture {
                            if animationSpeed == 1.0 {
                                animationSpeed = 1.5
                            } else if animationSpeed == 1.5 {
                                animationSpeed = 1.75
                            } else if animationSpeed == 1.75 {
                                animationSpeed = 2.0
                            } else {
                                animationSpeed = 1.0
                            }
                        }
                        Spacer()
                    }

                }.padding()
                    .frame(height: 40)
            }

        }.onAppear {
            getItemNames()
        }.modifier(ActivityIndicatorModifier(isLoading: trackHistoryOO.isLoading))
            .onChange(of: userId) { newValue in
                print("\(deviceId) \(deviceLinkId)")
                trackHistoryOO.getTrackHistory(userId: userId, deviceId: deviceId, deviceLink: deviceLinkId, fromDate: selectedFromDate.formatDateToStringShort()+" 00:00:00", toDate: selectedToDate.formatDateToString())
            }.onChange(of: crossedMarker) { newValue in
                distanceTravelled += crossedMarker.distance
            }
    }



    func getItemNames(){
        vehicleList.removeAll()
        if let listData = listItems.last?.data {
            deviceLinkId = listData.first?.deviceLinkId ?? ""
            for item in listData {
                if self.userId.isEmpty {
                    self.userId = item.customerId
                }
                self.vehicleList.append(item)
                if self.deviceLinkId.isEmpty {
                    self.deviceLinkId = item.deviceLinkId
                }

            }
        }
    }
}
