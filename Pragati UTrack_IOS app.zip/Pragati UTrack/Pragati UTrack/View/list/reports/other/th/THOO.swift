//
//  THOO.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-02-11.
//

import Foundation
import GoogleMapsUtils

class THOO: ObservableObject {
    @Published var isLoading = false
    @Published var thObject: THObject = THObject()
    @Published var thMarkers: [THMarker] = [THMarker]()

    func getTrackHistory(userId: String, deviceId: String, deviceLink: String, fromDate: String, toDate: String){

        isLoading = true
        var request = URLRequest(url: URL(string: "https://pragatiutrack.com/api/user/final_summary_report_mongo_v2?user_id=\(userId)&user_type=Customer&device_id=\(deviceId)&device_link_id=\(deviceLink)&from_date=\(fromDate)&to_date=\(toDate)&order_by=fixtime&time_diff=120&enable_locations=0&enable_consecutive=1")!,timeoutInterval: Double.infinity)
        request.addValue("FEA3E5D0QFCEBFD54F0A6A674ECAE3F8", forHTTPHeaderField: "X-Api-Key")

        request.httpMethod = "GET"
        print("Fetching TH: \(request.url)")
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            
            DispatchQueue.main.async {
            self.isLoading = false

            guard let data = data else {
                print(String(describing: error))
                return
            }



                do {
                    let decoder = JSONDecoder()
                    decoder.keyDecodingStrategy = .convertFromSnakeCase
                    let obj = try decoder.decode(THObject.self, from: data)
                    if obj.status == true {
                        self.thObject = obj

                        if let data = obj.data {
                            self.thMarkers.removeAll()
                            for item in data.trackReport {
                                let marker = THMarker(speed: Double(item.s), course: Double(item.c), time: item.t, distance: Double(item.cd) ?? 0, lat: item.la, lon: item.lo)
                                self.thMarkers.append(marker)
                            }
                        }

                    }

                } catch {
                    print("THO Throw \(error)")
                }
            }

        }

        task.resume()
    }
}
