//
//  StoppageOO.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-01-19.
//

import Combine
import SwiftUI
import RealmSwift
import CoreLocation

class StoppageOO: ObservableObject {
    @Published var isLoading = false

    @Published var fCellItems: [[String]] = [[String]]()
    @Published var cellItems: [[String]] = [[String]]()

    @Published var stoppageItem: StoppageReportObject = StoppageReportObject()

    //2023-11-28%2017%3A01%3A09
    func getStoppageReport(userId: String, fromDate: String, toDate: String, deviceLinkId: String){
        isLoading = true
        print("CELL: \(userId) \(fromDate) \(toDate) \(deviceLinkId)")
        var request = URLRequest(url: URL(string: "https://www.pragatiutrack.com/api/user/stoppage_track_report?user_id=\(userId)&user_type=Customer&device_token=Iphone%20Token&to_date=\(toDate)&from_date=\(fromDate)&device_link_id=\(deviceLinkId)&show_stopped=1")!,timeoutInterval: Double.infinity)
        request.addValue("FEA3E5D0QFCEBFD54F0A6A674ECAE3F8", forHTTPHeaderField: "X-Api-Key")

        request.httpMethod = "GET"

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {

                self.isLoading = false
                guard let data = data else {
                    print(String(describing: error))
                    return
                }

                do {
                    let decoder = JSONDecoder()
                    decoder.keyDecodingStrategy = .convertFromSnakeCase
                    let obj = try decoder.decode(StoppageReportObject.self, from: data)
                    if obj.status == true {
                        self.stoppageItem = obj
                        self.setCellItems()

                    }

                } catch {
                    print("Stoppage Throw \(error)")
                }



            }
        }
        task.resume()

    }

    func setCellItems(){
        cellItems.removeAll()

        for item in stoppageItem.data {

                var temp = [String]()
                temp.append(item.fdt)
                temp.append(item.tdt)
                temp.append(item.type)
                temp.append(item.ttt)
                temp.append(item.ttd)

                temp.append(item.l)
                cellItems.append(temp)

        }

        updateCellItems()
    }

    func updateCellItems(interval: Int = 0) {
        self.fCellItems.removeAll()
            for (index, item) in self.stoppageItem.data.enumerated() {
                if item.ttts >= interval {
                    DispatchQueue.main.async {
                    self.fCellItems.append(self.cellItems[index])
                }
            }
        }
    }


}

