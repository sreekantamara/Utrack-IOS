//
//  DistanceReport.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-01-17.
//

import SwiftUI
import RealmSwift

struct DistanceReport: View {
    @Binding var reportPage: ReportType
    var headers = ["ID", "From Date Time", "To Date Time",
                   "Distance (KM)", "Cummulative Distance (KM)"]

    @State var selectedSegment = 0
    @StateObject var distanceOO = DistanceOO()

    @ObservedResults(DashboardListMap.self) var listItems

    @State var vehicleList = [Device]()
    @State var vehicleListNames = [String]()

    @State var selectedFromDate = Date()
    @State var selectedToDate = Date()

    // for call
    @State var userId = ""
    @State var deviceLinkId = ""

    @State var selectedInterval = "10 mins"

    @State var locations = [String]()

    var intervals = [
        "10 mins",
        "15 mins",
        "30 mins",
        "1 Hour",

        "2 Hours",
        "3 Hours",
        "6 Hours",
        "12 Hours",
    ]

    var intervalsMins = [
        600,
        900,
        1800,
        3600,
        
        7200,
        10800,
        21600,
        43200
    ]

    @State var intValue = 0

    var body: some View {
        VStack(alignment: .center) {
            ZStack {
                HStack(alignment: .center) {
                    Text("Distance Report")
                        .bold()
                        .font(.headline)
                }

                Button(action: {
                    reportPage = .none
                }, label: {
                    Image(systemName: "arrow.left")
                        .resizable()
                        .frame(width: 20, height: 18)
                }).position(x: 20,  y: 15)
            }.frame(height: 30)
            // Top
            ReportDateSelectionCard(
                selectedFromDate: $selectedFromDate,
                selectedToDate: $selectedToDate,
                selection1Data: $deviceLinkId,
                selectedInterval: $selectedInterval,

                intervals: intervals,
                
                selection1Title: "Select Vehicle",
                selection1Items: vehicleList,
                buttonTitle: "View Report",
                segmentSelection: $selectedSegment
            ){
                distanceOO.getDistanceReport(userId: userId, fromDate: selectedFromDate.formatDateToString(), toDate: selectedToDate.formatDateToString(), deviceLinkId: deviceLinkId, intervals: "\(intervalsMins[intValue]/60)")
            }

            if distanceOO.cellItems.isEmpty {
                Text("No Data")
                Spacer()
            } else {
                // Bottom
                DataTable(
                    headers: headers,
                    data: distanceOO.cellItems,
                    extended: selectedSegment == 1
                )
            }
        }.onAppear {
            getItemNames()
        }.onChange(of: selectedInterval) { newValue in
            intValue = intervals.firstIndex(of: newValue)!
            print("Int: \(intValue) \(newValue)")
        }.modifier(ActivityIndicatorModifier(isLoading: distanceOO.isLoading))

    }

    func getItemNames(){
        vehicleList.removeAll()
        if let listData = listItems.last?.data {
            deviceLinkId = listData.first?.deviceLinkId ?? ""
            for item in listData {

                    let str = "\(item.vehicleName) (\(item.vehicleType))"
                    vehicleListNames.append(str)
                    self.userId = item.customerId
                    self.vehicleList.append(item)
                    if self.deviceLinkId.isEmpty {
                        self.deviceLinkId = item.deviceLinkId
                    }
                }

        }
    }
}
