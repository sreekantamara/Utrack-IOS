//
//  DistanceOO.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-01-20.
//

import Combine
import SwiftUI
import RealmSwift
import GoogleMaps

class DistanceOO: ObservableObject {
    @Published var isLoading = false
    @Published var cellItems: [[String]] = [[String]]()

    @Published var distanceItem: DistanceReportObject = DistanceReportObject()

    //2023-11-28%2017%3A01%3A09
    func getDistanceReport(userId: String, fromDate: String, toDate: String, deviceLinkId: String, intervals: String){
        print("Distance Int: \(intervals)")
        isLoading = true
        var request = URLRequest(url: URL(string: "https://www.pragatiutrack.com/api/user/distance_report?user_id=\(userId)&user_type=Customer&device_token=Iphone%20Token&to_date=\(toDate)&from_date=\(fromDate)&device_link_id=\(deviceLinkId)&interval_in_mins=\(intervals)")!,timeoutInterval: 60)
        request.addValue("FEA3E5D0QFCEBFD54F0A6A674ECAE3F8", forHTTPHeaderField: "X-Api-Key")

        request.httpMethod = "GET"

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {

                self.isLoading = false
                guard let data = data else {
                    print(String(describing: error))
                    return
                }

                do {
                    let decoder = JSONDecoder()
                    decoder.keyDecodingStrategy = .convertFromSnakeCase
                    let obj = try decoder.decode(DistanceReportObject.self, from: data)
                    if obj.status == true {
                        //                        //write to realm
                        //                        let loginRealm = try Realm()
                        //                        try! loginRealm.write{
                        //                            loginRealm.delete(loginRealm.objects(StoppageReportObject.self))
                        //                            loginRealm.add(obj)
                        //                        }
                        self.distanceItem = obj
                        self.setCellItems()

                    }

                } catch {
                    print("Distance Throw \(error)")
                }



            }
        }
        task.resume()

    }

    func setCellItems(){
        cellItems.removeAll()

        for (index, item) in distanceItem.data.enumerated() {
            var temp = [String]()
            temp.append("\(index+1)")
            temp.append(item.fdt)
            temp.append(item.tdt)
            temp.append(item.d)
            temp.append(item.cd)
            cellItems.append(temp)
        }
    }


}
