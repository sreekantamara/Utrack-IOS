//
//  DailyKMOO.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-01-20.
//

import Foundation

class DailyKMOO: ObservableObject {
    @Published var isLoading = false
    @Published var cellItems: [[String]] = [[String]]()

    @Published var dailyKMItem: DailyKMReportObject = DailyKMReportObject()

    //2023-11-28%2017%3A01%3A09
    func getDailyKMReport(userId: String, fromDate: String, toDate: String, deviceLinkId: String){

        isLoading = true
        var request = URLRequest(url: URL(string: "https://www.pragatiutrack.com/api/user/single_custom_device_report_stats_v1?user_id=\(userId)&user_type=Customer&device_token=Web&from_date=\(fromDate)&to_date=\(toDate)&device_link_id=\(deviceLinkId)&is_slotted_vehicle_analysis=No")!,timeoutInterval: 60)
        request.addValue("FEA3E5D0QFCEBFD54F0A6A674ECAE3F8", forHTTPHeaderField: "X-Api-Key")

        request.httpMethod = "GET"


        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {

                self.isLoading = false
                guard let data = data else {
                    print(String(describing: error))
                    return
                }

                do {
                    let decoder = JSONDecoder()
                    decoder.keyDecodingStrategy = .convertFromSnakeCase
                    let obj = try decoder.decode(DailyKMReportObject.self, from: data)
                    if obj.status == true {
                        //                        //write to realm
                        //                        let loginRealm = try Realm()
                        //                        try! loginRealm.write{
                        //                            loginRealm.delete(loginRealm.objects(StoppageReportObject.self))
                        //                            loginRealm.add(obj)
                        //                        }
                        self.dailyKMItem = obj
                        self.setCellItems()

                    }

                } catch {
                    print("DailyKMReportObject Throw \(error)")
                }



            }
        }
        task.resume()

    }

    func setCellItems(){
        cellItems.removeAll()
        var lastIndex = 0
        if let data = dailyKMItem.data {
            for (index, item) in data.detail.enumerated() {
                var temp = [String]()
                lastIndex = index + 1
                temp.append("\(lastIndex)")
                temp.append(item.reportDate)
                temp.append(item.reportDay!)
                temp.append(item.totalDistance)
                temp.append(item.totalTravelledTime)
                cellItems.append(temp)
            }

            cellItems.append(
                [
                    "\(lastIndex+1)",
                    "Sum",
                    "-",
                    dailyKMItem.data?.totalDistance ?? "",
                    dailyKMItem.data?.totalTravelledTime ?? ""]
            )
        }

    }


}
