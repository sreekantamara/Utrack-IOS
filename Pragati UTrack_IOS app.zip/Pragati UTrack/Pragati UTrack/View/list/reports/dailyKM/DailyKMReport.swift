//
//  DailyKMReport.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-01-17.
//

import SwiftUI
import RealmSwift

struct DailyKMReport: View {
    @Binding var reportPage: ReportType
    var headers = ["ID", "Date", "Day",
                   "Total Distance (KM)", "Travel Time (HH:MM:SS)"]

    @State var selectedSegment = 0
    @StateObject var dailyKMOO = DailyKMOO()

    @ObservedResults(DashboardListMap.self) var listItems

    @State var vehicleList = [Device]()
    @State var vehicleListNames = [String]()

    @State var selectedFromDate = Date()
    @State var selectedToDate = Date()
    @State var selectedInterval = ""

    // for call
    @State var userId = ""
    @State var deviceLinkId = ""
    

    var body: some View {
        VStack(alignment: .center) {
            ZStack {
                HStack(alignment: .center) {
                    Text("Daily KM Report")
                        .bold()
                        .font(.headline)
                }

                Button(action: {
                    reportPage = .none
                }, label: {
                    Image(systemName: "arrow.left")
                        .resizable()
                        .frame(width: 20, height: 18)
                }).position(x: 20,  y: 15)
            }.frame(height: 30)
            // Top
            ReportDateSelectionCard(
                selectedFromDate: $selectedFromDate,
                selectedToDate: $selectedToDate,
                selection1Data: $deviceLinkId,
                selectedInterval: $selectedInterval,

                selection1Title: "Select Vehicle",
                selection1Items: vehicleList,
                buttonTitle: "View Report",
                segmentSelection: $selectedSegment
            ){
                dailyKMOO.getDailyKMReport(userId: userId, fromDate: selectedFromDate.formatDateToString(), toDate: selectedToDate.formatDateToString(), deviceLinkId: deviceLinkId)
            }

            if dailyKMOO.cellItems.isEmpty {
                Text("No Data")
                Spacer()
            } else {
                // Bottom
                DataTable(
                    headers: headers,
                    data: dailyKMOO.cellItems,
                    extended: selectedSegment == 1
                )
            }
        }.onAppear {
            getItemNames()
        }.modifier(ActivityIndicatorModifier(isLoading: dailyKMOO.isLoading))

    }

    func getItemNames(){
        vehicleList.removeAll()
        if let listData = listItems.last?.data {
            deviceLinkId = listData.first?.deviceLinkId ?? ""
            for item in listData {
                let str = "\(item.vehicleName) (\(item.vehicleType))"
                vehicleListNames.append(str)
                self.userId = item.customerId
                self.vehicleList.append(item)
                if self.deviceLinkId.isEmpty {
                    self.deviceLinkId = item.deviceLinkId
                }
            }
        }
    }
}
