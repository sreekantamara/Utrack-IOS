//
//  OverspeedReport.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-02-24.
//

import SwiftUI
import RealmSwift

struct OverspeedReport: View {
    @Binding var reportPage: ReportType
    @Binding var deviceLinkId: String
    @Binding var userId: String

    var headers = ["ID", "From Date Time", "To Date Time", "Max Speed(KMPH)", "Avg. Speed(KMPH)", "Duration (HH:MM:SS)",
                   "Distance (Meters)"]

    @State var selectedSegment = 0
    @StateObject var osOO = OverspeedOO()

    @ObservedResults(DashboardListMap.self) var listItems

    @State var vehicleList = [Device]()

    @State var selectedFromDate = Date(timeIntervalSinceNow: -2 * 24 * 60 * 60)
    @State var selectedToDate = Date()


    @State var selectedSpeed = "40 KMPH"


    var speedLimits = [
        "40 KMPH",
        "50 KMPH",
        "60 KMPH",
        "70 KMPH",

        "80 KMPH",
        "90 KMPH",
        "100 KMPH",
        "110 KMPH",
        "120 KMPH",
    ]

    var speedNums = [
        20,
        25,
        30,
        35,

        40,
        45,
        50,
        55,
        60
    ]

    @State var markerName: String = ""
    @State var color: Color = .clear

    var body: some View {
        NavigationStack {

        VStack(alignment: .center) {
            ZStack {
                HStack(alignment: .center) {
                    Text("Overspeed Report")
                        .bold()
                        .font(.headline)
                }

                Button(action: {
                    reportPage = .none
                }, label: {
                    Image(systemName: "arrow.left")
                        .resizable()
                        .frame(width: 20, height: 18)
                }).position(x: 20,  y: 15)
            }.frame(height: 30)

            // Top
            ReportDateSelectionCard(
                selectedFromDate: $selectedFromDate,
                selectedToDate: $selectedToDate,
                selection1Data: $deviceLinkId,
                selectedInterval: $selectedSpeed,

                intervals: speedLimits,

                selection1Title: "Select Vehicle",
                selection1Items: vehicleList,
                buttonTitle: "View Report", segmentSelection: $selectedSegment
            ){

                // Server Call
                if let index = speedLimits.firstIndex(of: selectedSpeed) {
                    osOO.getOSReport(userId: userId, fromDate: selectedFromDate.formatDateToString(), toDate: selectedToDate.formatDateToString(), deviceLinkId: deviceLinkId, speed: "\(speedNums[index])")
                }

                if let name = vehicleList.first(where: { device in
                    device.deviceLinkId == deviceLinkId
                }) {
                    markerName = name.vehicleType
                }

            }

            if osOO.cellItems.isEmpty {
                Text("No Data")
                Spacer()
            } else {
                // Bottom
                if selectedSegment == 0 {

                    List {
                        ForEach($osOO.overSpeedItem.data, id: \.self){ item in
                            NavigationLink {

                                if let firstItem = item.wrappedValue.data.first, let secondItem = item.wrappedValue.data.last {

                                    let firstMarker = THMarker(speed: Double(firstItem.s) ?? 0, course: Double(firstItem.c) ?? 0, time: 0, distance: 0, lat: Double(firstItem.la) ?? 0, lon: Double(firstItem.lo) ?? 0)

                                    let endMarker = THMarker(speed: Double(secondItem.s) ?? 0, course: Double(secondItem.c) ?? 0, time: 0, distance: 0, lat: Double(secondItem.la) ?? 0, lon: Double(secondItem.lo) ?? 0)

                                    OSMap(
                                        reportPage: $reportPage, item: item.wrappedValue, startMarker: firstMarker,
                                        endMarker: endMarker, deviceName: markerName, deviceColor: .green)

                                }

                            } label: {
                                OSCard(item: item.wrappedValue) //OSData
                            }

                        }
                    }
                    .listStyle(.plain)

                } else {

                    DataTable(
                        headers: headers,
                        data: osOO.cellItems,
                        extended: false
                    )
                }

            }


        }.onAppear {
            if osOO.overSpeedItem.data.isEmpty {
                getItemNames()
            }
        }
        .background(.white)
        .modifier(ActivityIndicatorModifier(isLoading: osOO.isLoading))
        .onChange(of: selectedSpeed) { newValue in
            print("Speed New: \(newValue)")
        }
    }


    }

    func getItemNames(){
        vehicleList.removeAll()
        if let listData = listItems.last?.data {
            for item in listData {
                self.vehicleList.append(item)
            }
        }

        if let index = speedLimits.firstIndex(of: selectedSpeed) {
            osOO.getOSReport(userId: userId, fromDate: selectedFromDate.formatDateToString(), toDate: selectedToDate.formatDateToString(), deviceLinkId: deviceLinkId, speed: "\(speedNums[index])")
        }


        if let name = vehicleList.first(where: { device in
            device.deviceLinkId == deviceLinkId
        }) {
            markerName = name.vehicleType
        }



    }
}
