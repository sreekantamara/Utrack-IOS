//
//  OverspeedOO.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-02-24.
//

import Foundation

class OverspeedOO: ObservableObject {
    @Published var isLoading = false
    @Published var cellItems: [[String]] = [[String]]()

    @Published var overSpeedItem = OSObject()

    func getOSReport(userId: String, fromDate: String, toDate: String, deviceLinkId: String, speed: String){
        isLoading = true
        var request = URLRequest(url: URL(string: "https://www.pragatiutrack.com/api/user/final_summary_report_mongo_over_speed?user_id=\(userId)&user_type=Customer&device_token=Web&to_date=\(toDate)&from_date=\(fromDate)&device_link_id=\(deviceLinkId)&order_by=fixtime&speed_limit=\(speed)")!,timeoutInterval: Double.infinity)
        request.addValue("FEA3E5D0QFCEBFD54F0A6A674ECAE3F8", forHTTPHeaderField: "X-Api-Key")
        request.addValue("ci_session=5ta19gu80urc6nbledlqkbrff5", forHTTPHeaderField: "Cookie")

        request.httpMethod = "GET"

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                self.isLoading = false
                guard let data = data else {
                    print(String(describing: error))
                    return
                }

                do {
                    let decoder = JSONDecoder()
                    decoder.keyDecodingStrategy = .convertFromSnakeCase
                    let obj = try decoder.decode(OSObject.self, from: data)
                    if obj.status == true {
                        self.overSpeedItem = obj
                        print("OS Report received")
                        self.setCellItems()
                    }
                } catch {
                    print("DailyKMReportObject Throw \(error)")
                }

            }
        }

        task.resume()
    }

    func setCellItems(){
        cellItems.removeAll()

        for (index, item) in overSpeedItem.data.enumerated() {

            var temp = [String]()
            temp.append("\(index+1)")
            temp.append(item.fdt)
            temp.append(item.tdt)
            temp.append(item.ms)
            temp.append(item.datumAs)
            temp.append(item.d)
            temp.append(item.td)

            cellItems.append(temp)
        }

       // updateCellItems()
    }

//    func updateCellItems(speedLimit: Int = 0) {
//        self.fCellItems.removeAll()
//        for (index, item) in self.stoppageItem.data.enumerated() {
//            if item.ttts >= interval {
//                DispatchQueue.main.async {
//                    self.fCellItems.append(self.cellItems[index])
//                }
//            }
//        }
//    }

}
