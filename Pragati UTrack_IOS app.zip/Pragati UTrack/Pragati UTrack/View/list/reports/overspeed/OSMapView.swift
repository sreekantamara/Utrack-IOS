import SwiftUI

struct OSMap: View {
    @Binding var reportPage: ReportType
    var item: OSData

    @State var startMarker: THMarker
    @State var endMarker: THMarker

    var deviceName: String
    var deviceColor: Color

    var body: some View {

        VStack(alignment: .center) {
            OSMapView(startMarker: startMarker, endMarker: endMarker, markerName: deviceName, color: deviceColor)
        }

    }
}
