

//
//  OSMapView.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-03-01.
//

import UIKit
import SwiftUI
import GoogleMaps
import GoogleMapsUtils

struct OSMapView: UIViewRepresentable {

    var startMarker: THMarker
    var endMarker: THMarker

    // Add animated marker
    @State private var animatedMarker = GMSMarker()


    var markerName: String
    var color: Color

    var animationSpeed: Double = 1.0


    func makeCoordinator() -> OSCoordinator {
        OSCoordinator(parent: self)
    }

    func makeUIView(context: Context) -> GMSMapView {
        var camera = GMSCameraPosition.camera(withLatitude: 0, longitude: 0, zoom: 10.0)
        let mapView = GMSMapView.map(withFrame: CGRect.zero, camera: camera)

        mapView.isMyLocationEnabled = true

        mapView.delegate = context.coordinator

        // Add markers and path
        addMarkers(to: mapView)

        camera = GMSCameraPosition.camera(withLatitude: startMarker.lat, longitude: startMarker.lon, zoom: Float(13))

        mapView.animate(to: camera)

        animatedMarker = GMSMarker()
        animatedMarker.title = "Vehicle"
        animatedMarker.icon = UIImage(named: markerName.getMarker(color))?
            .resized(to: CGSize(width: 25, height: 50))

        // Set the initial position of the animated marker
        animatedMarker.position = startMarker.position
        animatedMarker.rotation = getBearingBetweenPoints(point1: startMarker.position, point2: endMarker.position)

        animatedMarker.map = mapView

        drawPathBetweenMarkers(on: mapView)

        return mapView
    }

    func updateUIView(_ mapView: GMSMapView, context: Context) {
        print("Animating")
        let duration: TimeInterval = 10.0 // Adjust animation speed as needed


        Timer.scheduledTimer(withTimeInterval: 2.0, repeats: false){ timer in
            // Animate the marker
            UIView.animate(withDuration: duration) {
                self.animatedMarker.position = endMarker.position
            }
        }


    }

    private func addMarkers(to mapView: GMSMapView) {

        mapView.clear()

                let marker = GMSMarker()
        marker.position = startMarker.position

                marker.title = "\(startMarker.course)"

                marker.icon =  MarkerImageGenerator.imageWithText(text: "Start", unitText: "", markerColor: .green)

                marker.groundAnchor = CGPoint(x: 0.5, y: 1)
                marker.map = mapView

        let marker2 = GMSMarker()


        marker2.position = endMarker.position
        marker2.title = "\(endMarker.course)"

        marker2.icon =  MarkerImageGenerator.imageWithText(text: "End", unitText: "", markerColor: .red)

        marker2.groundAnchor = CGPoint(x: 0.5, y: 1)

        marker2.map = mapView

    }


    func getBearingBetweenPoints(point1: CLLocationCoordinate2D, point2: CLLocationCoordinate2D) -> CLLocationDegrees {
        let lat1 = degreesToRadians(degrees: point1.latitude)
        let lon1 = degreesToRadians(degrees: point1.longitude)

        let lat2 = degreesToRadians(degrees: point2.latitude)
        let lon2 = degreesToRadians(degrees: point2.longitude)

        let dLon = lon2 - lon1

        let y = sin(dLon) * cos(lat2)
        let x = cos(lat1) * sin(lat2) - sin(lat1) * cos(lat2) * cos(dLon)

        let radiansBearing = atan2(y, x)

        return radiansToDegrees(radians: radiansBearing)
    }

    func degreesToRadians(degrees: CLLocationDegrees) -> Double {
        return degrees * .pi / 180.0
    }

    func radiansToDegrees(radians: Double) -> CLLocationDegrees {
        return radians * 180.0 / .pi
    }


    private func drawPathBetweenMarkers(on mapView: GMSMapView) {

        var path = GMSMutablePath()

            let currentMarker = startMarker
            let nextMarker = endMarker

            let currentCoordinate = currentMarker.position
            let nextCoordinate = nextMarker.position

            // Add the line segment to the path
            path.add(currentCoordinate)
            path.add(nextCoordinate)

            // Create a polyline for the line segment
            let polyline = GMSPolyline(path: path)
            polyline.strokeColor = .blue
            polyline.strokeWidth = 4.0
            polyline.map = mapView

            // Move to the next segment by clearing the path
            path = GMSMutablePath()
        }
}

