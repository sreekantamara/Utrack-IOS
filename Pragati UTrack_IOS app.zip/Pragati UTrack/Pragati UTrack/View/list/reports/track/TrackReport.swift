//
//  TrackReport.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-01-17.
//

import SwiftUI
import RealmSwift

struct TrackReport: View {
    @Binding var reportPage: ReportType
    var headers = ["From Date Time", "To Date Time", "Type", "Duration (HH:MM:SS)",
                   "Distance (KM)", "Nearest Location"]

    @State var selectedSegment = 0
    @StateObject var trackOO = TrackOO()

    @ObservedResults(DashboardListMap.self) var listItems

    @State var vehicleList = [Device]()
    @State var vehicleListNames = [String]()

    @State var selectedFromDate = Date()
    @State var selectedToDate = Date()

    // for call
    @State var userId = ""
    @State var deviceLinkId = ""

    @State var selectedInterval = "All"

    @State var locations = [String]()

    var intervals = [
        "All",
        "Above 30secs",
        "Above 1 mins",
        "Above 2 mins",
        "Above 5 mins",
        "Above 10 mins",
        "Above 15 mins",
        "Above 30 mins",
        "Above 1 Hour",
        "Above 2 Hours",
        "Above 3 Hours",
        "Above 6 Hours",
        "Above 12 Hours",
        "Above 1 Day"
    ]

    var intervalsMins = [
        0,
        30,
        60,
        120,
        300,
        600,
        900,
        1800,
        3600,
        7200,
        10800,
        21600,
        43200,
        86400
    ]

    @State var intValue = 0

    var body: some View {
        VStack(alignment: .center) {
            ZStack {
                HStack(alignment: .center) {
                    Text("Track Report")
                        .bold()
                        .font(.headline)
                }

                Button(action: {
                    reportPage = .none
                }, label: {
                    Image(systemName: "arrow.left")
                        .resizable()
                        .frame(width: 20, height: 18)
                }).position(x: 20,  y: 15)
            }.frame(height: 30)
            
            // Top
            ReportDateSelectionCard(
                selectedFromDate: $selectedFromDate,
                selectedToDate: $selectedToDate,
                selection1Data: $deviceLinkId,
                selectedInterval: $selectedInterval,
                
                intervals: intervals,

                selection1Title: "Select Vehicle",
                selection1Items: vehicleList,
                buttonTitle: "View Report", segmentSelection: $selectedSegment
            ){
                trackOO.getStoppageReport(userId: userId, fromDate: selectedFromDate.formatDateToString(), toDate: selectedToDate.formatDateToString(), deviceLinkId: deviceLinkId)
            }

            if trackOO.fCellItems.isEmpty {
                Text("No Data")
                Spacer()
            } else {
                // Bottom
                DataTable(
                    headers: headers,
                    data: trackOO.fCellItems,
                    extended: selectedSegment == 1
                )
            }


        }.onAppear {
            getItemNames()
        }.onChange(of: selectedInterval) { newValue in
            intValue = intervalsMins[intervals.firstIndex(of: newValue)!]
            trackOO.updateCellItems(interval: intValue)

        }.modifier(ActivityIndicatorModifier(isLoading: trackOO.isLoading))

    }

    func getItemNames(){
        vehicleList.removeAll()
        if let listData = listItems.last?.data {
            deviceLinkId = listData.first?.deviceLinkId ?? ""
            for item in listData {
                let str = "\(item.vehicleName) (\(item.vehicleType))"
                vehicleListNames.append(str)
                self.userId = item.customerId
                self.vehicleList.append(item)
                if self.deviceLinkId.isEmpty {
                    self.deviceLinkId = item.deviceLinkId
                }
            }
        }
    }
}
