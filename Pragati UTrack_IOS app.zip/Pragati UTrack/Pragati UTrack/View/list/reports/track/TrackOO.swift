//
//  TrackOO.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-01-20.
//

import Combine
import SwiftUI
import RealmSwift
import GoogleMaps

class TrackOO: ObservableObject {
    @Published var isLoading = false

    @Published var fCellItems: [[String]] = [[String]]()
    @Published var cellItems: [[String]] = [[String]]()

    @Published var stoppageItem: StoppageReportObject = StoppageReportObject()

    //2023-11-28%2017%3A01%3A09
    func getStoppageReport(userId: String, fromDate: String, toDate: String, deviceLinkId: String){
        isLoading = true
        print("CELL: \(userId) \(fromDate) \(toDate) \(deviceLinkId)")
        var request = URLRequest(url: URL(string: "https://www.pragatiutrack.com/api/user/stoppage_track_report?user_id=\(userId)&user_type=Customer&device_token=Iphone%20Token&to_date=\(toDate)&from_date=\(fromDate)&device_link_id=\(deviceLinkId)&show_stopped=0")!,timeoutInterval: Double.infinity)
        request.addValue("FEA3E5D0QFCEBFD54F0A6A674ECAE3F8", forHTTPHeaderField: "X-Api-Key")

        request.httpMethod = "GET"

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {

                self.isLoading = false
                guard let data = data else {
                    print(String(describing: error))
                    return
                }

                do {
                    let decoder = JSONDecoder()
                    decoder.keyDecodingStrategy = .convertFromSnakeCase
                    let obj = try decoder.decode(StoppageReportObject.self, from: data)
                    if obj.status == true {
//                        //write to realm
//                        let loginRealm = try Realm()
//                        try! loginRealm.write{
//                            loginRealm.delete(loginRealm.objects(StoppageReportObject.self))
//                            loginRealm.add(obj)
//                        }
                        self.stoppageItem = obj
                        self.setCellItems()

                    }

                } catch {
                    print("Stoppage Throw \(error)")
                }



            }
        }
        task.resume()

    }

    func setCellItems(){
        cellItems.removeAll()

        for (index, item) in stoppageItem.data.enumerated() {

            var temp = [String]()
            temp.append(item.fdt)
            temp.append(item.tdt)
            print("Type: \(item.type)")
            temp.append(item.type)
            temp.append(item.ttt)
            temp.append(item.ttd)

            temp.append(item.l)
            cellItems.append(temp)
            getAddress(lat: item.la, lon: item.lo, index: index)

        }

        updateCellItems()
    }

    func updateCellItems(interval: Int = 0) {
        fCellItems.removeAll()
        for (index, item) in stoppageItem.data.enumerated() {
            if item.ttts >= interval {
                fCellItems.append(cellItems[index])
            }
        }
    }



    func getAddress(lat: String, lon: String, index: Int){
        guard let latitude = lat.toCGFloat(), let longitude = lon.toCGFloat() else {return}
        let geoCoder = GMSGeocoder()
        geoCoder.reverseGeocodeCoordinate(CLLocationCoordinate2D(latitude: latitude, longitude: longitude)) { response, error in
            guard let response = response, let result = response.firstResult() else {return}

            self.cellItems[index][5] = result.lines?.joined(separator: ", ") ?? ""
        }
    }

}
