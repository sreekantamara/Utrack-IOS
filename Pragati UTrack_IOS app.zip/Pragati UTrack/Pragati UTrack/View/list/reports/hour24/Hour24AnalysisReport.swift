//
//  Hour24AnalysisReport.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-01-17.
//

import SwiftUI
import RealmSwift

struct Hour24AnalysisReport: View {
    @Binding var reportPage: ReportType
    var headers = ["Date", "Vehicle Number",
                   "Driver Name","Travel Distance (KM)", "Travel Time (HH:MM:SS)", "Utilization (%)"
    ]

    @State var selectedSegment = 0
    @StateObject var hour24OO = Hour24OO()

    @ObservedResults(DashboardListMap.self) var listItems

    @State var vehicleList = [Device]()
    @State var vehicleListNames = [String]()

    @State var selectedFromDate = Date(timeIntervalSinceNow: -24 * 60 * 60)
    @State var selectedToDate = Date()

    // for call
    @State var userId = ""

    @State var deviceLinkId = Set<String>()
    @State var vehicleNumbers = Set<String>()


    var body: some View {
        NavigationStack {

        VStack(alignment: .center) {
            ZStack {
                HStack(alignment: .center) {
                    Text("24 Hour Analysis Report")
                        .bold()
                        .font(.headline)
                }

                Button(action: {
                    reportPage = .none
                }, label: {
                    Image(systemName: "arrow.left")
                        .resizable()
                        .frame(width: 20, height: 18)
                }).position(x: 20,  y: 15)
            }.frame(height: 30)
            // Top
            ReportDateSelectionCard2(
                selectedFromDate: $selectedFromDate,
                selectedToDate: $selectedToDate,
                selectedOptions: $vehicleNumbers,
                selection1Title: "Select Vehicle",
                selection1Items: $vehicleList,
                buttonTitle: "View Report",
                segmentSelection: $selectedSegment
            ){
                deviceLinkId.removeAll()
                for item in vehicleList {
                    if vehicleNumbers.contains(item.vehicleNumber) {
                        deviceLinkId.insert(item.deviceLinkId)
                    }
                }
                
                hour24OO.get24HourAnalysis(userId: userId, fromDate: selectedFromDate.formatDateToStringShort(), toDate: selectedToDate.formatDateToStringShort(), deviceLinkId: deviceLinkId.joined(separator: ","))
            }

            if hour24OO.cellItems.isEmpty {
                Text("No Data")
                Spacer()
            } else {
                // Bottom
                DataTable(
                    headers: headers,
                    data: hour24OO.cellItems,
                    extended: selectedSegment == 1
                )
            }
        }.onAppear {
            getItemNames()
        }.modifier(ActivityIndicatorModifier(isLoading: hour24OO.isLoading))

        }
    }

    func getItemNames(){
        vehicleList.removeAll()
        if let listData = listItems.last?.data {
            for item in listData {
                let str = "\(item.vehicleName) (\(item.vehicleType))"
                vehicleListNames.append(str)
                self.userId = item.customerId
                self.vehicleList.append(item)
                self.deviceLinkId.insert(item.deviceLinkId)
                self.vehicleNumbers.insert(item.vehicleNumber)
            }
        }

        if hour24OO.cellItems.isEmpty {
            hour24OO.get24HourAnalysis(userId: userId, fromDate: selectedFromDate.formatDateToStringShort(), toDate: selectedToDate.formatDateToStringShort(), deviceLinkId: deviceLinkId.joined(separator: ","))
        }
    }
}
