//
//  Hour24OO.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-01-20.
//

import Foundation

class Hour24OO: ObservableObject {
    @Published var isLoading = false
    @Published var cellItems: [[String]] = [[String]]()

    @Published var hour24Item: Hour24Object = Hour24Object()

    //2023-11-28%2017%3A01%3A09
    func get24HourAnalysis(userId: String, fromDate: String, toDate: String, deviceLinkId: String){
        print("Device: \(deviceLinkId)")
        isLoading = true
        var request = URLRequest(url: URL(string: "https://www.pragatiutrack.com/api/user/analysis_report_v1?user_id=\(userId)&user_type=Customer&device_token=Web&device_link_id=\(deviceLinkId)&from_date=\(fromDate)&to_date=\(toDate)&is_slotted_vehicle_analysis=No")!,timeoutInterval: 60)
        request.addValue("FEA3E5D0QFCEBFD54F0A6A674ECAE3F8", forHTTPHeaderField: "X-Api-Key")

        request.httpMethod = "GET"


        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {

                self.isLoading = false
                guard let data = data else {
                    print(String(describing: error))
                    return
                }

                do {
                    let decoder = JSONDecoder()
                    decoder.keyDecodingStrategy = .convertFromSnakeCase
                    let obj = try decoder.decode(Hour24Object.self, from: data)
                    if obj.status == true {
                        self.hour24Item = obj
                        self.setCellItems()
                    }

                } catch {
                    print("DailyKMReportObject Throw \(error)")
                }



            }
        }
        task.resume()

    }

    func setCellItems(){
        cellItems.removeAll()
        for item in hour24Item.data {
            var temp = [String]()
            temp.append(item.reportDate)
            temp.append(item.vehicleNumber)
            temp.append(item.driverName)
            temp.append(item.totalDistance)
            temp.append(item.totalTravelledTime)
            temp.append(item.utilization)
            cellItems.append(temp)
        }
    }
}
