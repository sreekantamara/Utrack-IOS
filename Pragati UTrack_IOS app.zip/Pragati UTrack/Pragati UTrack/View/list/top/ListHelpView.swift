//
//  ListHelpView.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2023-12-31.
//

import SwiftUI

struct ListHelpView: View {
    var body: some View {
        HStack {
            // First
            VStack(alignment: .trailing){
                Text("Moving")
                    .underline()
                    .foregroundStyle(.appPrimaryDark)
                    .font(.system(size: 12, weight: .bold))

                Text("Stopped")
                    .foregroundStyle(.red)
                Text("Moving")
                    .foregroundStyle(.green)
                Text("Data Not Found")
                    .foregroundStyle(.yellow)

                Text("Ignition")
                    .underline()
                    .foregroundStyle(.appPrimaryDark)
                    .font(.system(size: 12, weight: .bold))

                Text("On")
                    .foregroundStyle(.ignitionOn)
                Text("Off")
                    .foregroundStyle(.ignitionOff)

                Text("Signal Strength")
                    .underline()
                    .foregroundStyle(.appPrimaryDark)
                    .font(.system(size: 12, weight: .bold))

                Text("No Signal")
                    .foregroundStyle(.gray)
                Text("Low")
                    .foregroundStyle(.red)
                Text("Medium")
                    .foregroundStyle(.yellow)
                Text("Full")
                    .foregroundStyle(.purple)

                Text("Fuel")
                    .underline()
                    .foregroundStyle(.appPrimaryDark)
                    .font(.system(size: 12, weight: .bold))
                Text("Below 10 ltrs")
                    .foregroundStyle(.fuelBelow10)
                Text("Above 10 ltrs")
                    .foregroundStyle(.fuelAbove10)
            }

            LazyVGrid(columns: [GridItem(), GridItem()], spacing: 0)  {
                ImageTitleView(image: "ic_move_green", title: "Yes",generic: true)
                    .foregroundStyle(.green)
                ImageTitleView(image: "ic_speed_50", title: "35 kmph",generic: true)
                    .foregroundStyle(.green)

                ImageTitleView(image: "ic_ignition_on", title: "ON",generic: true)
                    .foregroundStyle(.ignitionOn)
                ImageTitleView(image: "ic_stopped_24hrs_below", title: "00:03:24",generic: true)
                    .foregroundStyle(.stoppedBelow24)

                ImageTitleView(image: "ic_signal_medium", title: "Medium",generic: true)
                    .foregroundStyle(.purple)
                ImageTitleView(image: "ic_battery_60_above", title: "100%",generic: true)
                    .foregroundStyle(.batteryAbove60)

                ImageTitleView(image: "ic_fuel_10_ltrs_above", title: "130 Ltrs",generic: true)
                    .foregroundStyle(.green)
                ImageTitleView(image: "ic_temperature", title: "21°C",generic: true)
                    .foregroundStyle(.green)


            }
            .frame(width: 80)
            .padding()

            // Last
            VStack(alignment: .leading){
                Text("Speed")
                    .underline()
                    .foregroundStyle(.appPrimaryDark)
                    .font(.system(size: 12, weight: .bold))

                Text("Stopped - 0")
                    .foregroundStyle(.gray)
                Text("1-50 kmph")
                    .foregroundStyle(.green)
                Text("51-80 kmph")
                    .foregroundStyle(.yellow)
                Text("81 above kmph")
                    .foregroundStyle(.red)

                Text("Stopped Time")
                    .underline()
                    .foregroundStyle(.appPrimaryDark)
                    .font(.system(size: 12, weight: .bold))
                Text("Format: DD:HH:MM")
                    .foregroundStyle(.gray)
                Text("Below 24hrs")
                    .foregroundStyle(.stoppedBelow24)
                Text("Above 24hrs")
                    .foregroundStyle(.stoppedAbove24)

                Text("Battery")
                    .underline()
                    .foregroundStyle(.appPrimaryDark)
                    .font(.system(size: 12, weight: .bold))

                Text("0-10%")
                    .foregroundStyle(.batteryBelow10)
                Text("11%-59%")
                    .foregroundStyle(.batteryBelow60)
                Text("Above 60%")
                    .foregroundStyle(.batteryAbove60)

                Text("Temperature")
                    .underline()
                    .foregroundStyle(.appPrimaryDark)
                    .font(.system(size: 12, weight: .bold))
                Text("Single Color Only")
                    .foregroundStyle(.blue)
            }
        } //H
        .font(.system(size: 10))


    }
}

#Preview {
    ListHelpView()
}
