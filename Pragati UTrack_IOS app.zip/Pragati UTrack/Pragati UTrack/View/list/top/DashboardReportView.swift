//
//  DashboardReportView.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-01-05.
//

import SwiftUI
import RealmSwift

struct DashboardReportView: View {

    var headers = ["ID", "Vehicle Number", "Type",
                   "Speed (KMPH)", "Last Data Received", "Stopped Duration (HH:MM:SS", "Nearest Location"]

    @State var viewTypeExtended = 0
    @Binding var reportPage: ReportType

    @ObservedResults(DashboardListMap.self) var listItems

    @State var searchedText: String = ""

    @State var selectedSegment = 0

    @State var vehicleListNames = [[String]]()


    var body: some View {
        VStack {
            ZStack {
                HStack(alignment: .center) {
                    Text("Dashboard Report")
                        .bold()
                        .font(.headline)
                }

                Button(action: {
                    reportPage = .none
                }, label: {
                    Image(systemName: "arrow.left")
                        .resizable()
                        .frame(width: 20, height: 18)
                }).position(x: 20,  y: 15)
            }.frame(height: 30)

            
            HStack {
                TextField("Search...", text: $searchedText)
                    .textFieldStyle(.roundedBorder)

                Picker(selection: $selectedSegment, label: Text("Picker")) {
                    Image(systemName: "list.bullet.rectangle").tag(0)
                    Image(systemName: "list.dash.header.rectangle").tag(1)
                }
                .pickerStyle(SegmentedPickerStyle())
                .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/)



            }.padding(.horizontal, 20)

            if vehicleListNames.isEmpty {
                Text("No Data")
                Spacer()
            } else {
                // Bottom
                DataTable(
                    headers: headers,
                    data: vehicleListNames,
                    extended: selectedSegment == 1
                )
            }

        }
        .onAppear {
            getItemNames()
        }.onChange(of: searchedText) {newValue in
            getItemNames()
        }

    }

    func getItemNames(){
        print("DReport: \(listItems.count)")
        vehicleListNames.removeAll()
        if let listData = listItems.last?.data {
            var id = 0
            for item in listData {

                if searchedText.isEmpty {
                    id += 1
                    var temp = [String]()

                    temp.append("\(id)")
                    temp.append("\(item.vehicleNumber)")
                    temp.append(item.vehicleType)
                    temp.append(item.speed)

                    temp.append(item.devicetime)
                    temp.append(calculateDuration(item.lastRunningTime))
                    temp.append("\(item.lastArea), \(item.lastCity), \(item.lastState)")


                    self.vehicleListNames.append(temp)
                } else {
                    if item.vehicleNumber.lowercased().contains(searchedText.lowercased()){
                        id += 1
                        var temp = [String]()

                        temp.append("\(id)")
                        temp.append("\(item.vehicleNumber)")
                        temp.append(item.vehicleType)
                        temp.append(item.speed)

                        temp.append(item.devicetime)
                        temp.append(calculateDuration(item.lastRunningTime))
                        temp.append("\(item.lastArea), \(item.lastCity), \(item.lastState)")


                        self.vehicleListNames.append(temp)
                    }
                }



            }
        }
    }

    func calculateDuration(_ date: String) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd MMM yyyy hh:mm:ss a"

        if let startDate = dateFormatter.date(from: date) {
            let currentDate = Date()

            let calendar = Calendar.current
            let components = calendar.dateComponents([.hour, .minute, .second], from: startDate, to: currentDate)

            let hours = components.hour ?? 0
            let minutes = components.minute ?? 0
            let seconds = components.second ?? 0

            return String(format: "%02d:%02d:%02d", hours, minutes, seconds)
        } else {
            return "Invalid Date"
        }
    }
}

