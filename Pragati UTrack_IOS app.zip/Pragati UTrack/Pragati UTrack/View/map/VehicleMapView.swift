//
//  VehicleMapView.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2023-12-09.
//

// View
import SwiftUI
import GoogleMaps
import RealmSwift

struct VehicleMapView: View {
    @ObservedResults(MarkerData.self) var markerItems
    @State var items: [MarkerData] = [MarkerData]()

    var body: some View {
        ZStack {
            GoogleMapView(markers: items)
                .overlay(LegendView(), alignment: .bottomTrailing)

        }.onAppear {
            print("\(markerItems.count)")
            for item in markerItems {
                items.append(item)
            }
        }
    }

}
