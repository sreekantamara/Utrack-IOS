//
//  LoginOO.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2023-12-01.
//

// Observable Object
import Foundation
import RealmSwift

class LoginOO: ObservableObject {

    @Published var isLoggedIn = false
    @Published var isLoading = false

    @Published var forgotStatus = false
    @Published var forgotMessage = ""

    @Published var resetStatus = false
    @Published var resetMessage = ""

    let boundary = "Boundary-\(UUID().uuidString)"
    var body = ""
    var error: Error? = nil

    func loginWith(name username: String, password: String){

        isLoading = true

        let parameters = [
            [
                "key": "mobile_number",
                "value": username,
                "type": "text"
            ],
            [
                "key": "user_type",
                "value": "Customer",
                "type": "text"
            ],
            [
                "key": "password",
                "value": password,
                "type": "text"
            ],
            [
                "key": "device_token",
                "value": "123456xczx",
                "type": "text"
            ]] as [[String : Any]]


        for param in parameters {
            if param["disabled"] == nil {
                let paramName = param["key"]!
                body += "--\(boundary)\r\n"
                body += "Content-Disposition:form-data; name=\"\(paramName)\""
                if param["contentType"] != nil {
                    body += "\r\nContent-Type: \(param["contentType"] as! String)"
                }
                let paramType = param["type"] as! String
                if paramType == "text" {
                    let paramValue = param["value"] as! String
                    body += "\r\n\r\n\(paramValue)\r\n"
                } else {
                    do {
                        let paramSrc = param["src"] as! String
                        let fileData = try NSData(contentsOfFile:paramSrc, options:[]) as Data
                        let fileContent = String(data: fileData, encoding: .utf8)!
                        body += "; filename=\"\(paramSrc)\"\r\n"
                        + "Content-Type: \"content-type header\"\r\n\r\n\(fileContent)\r\n"
                    } catch {
                        print("LoginOO Throw \(error)")
                    }

                }
            }
        }
        body += "--\(boundary)--\r\n";
        let postData = body.data(using: .utf8)

        var request = URLRequest(url: URL(string: "https://pragatiutrack.com/api/user/user_login")!,timeoutInterval: Double.infinity)
        request.addValue("FEA3E5D0QFCEBFD54F0A6A674ECAE3F8", forHTTPHeaderField: "X-Api-Key")
        request.addValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")

        request.httpMethod = "POST"
        request.httpBody = postData

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {

            self.isLoading = false
            guard let data = data else {
                print(String(describing: error))
                return
            }



                do {
                    let decoder = JSONDecoder()
                    decoder.keyDecodingStrategy = .convertFromSnakeCase
                    let loginObject = try decoder.decode(LoginObject.self, from: data)
                    if loginObject.status == true {
                        self.isLoggedIn = true
                        print("We're logged in")
                        //write to realm
                        let loginRealm = try Realm()
                        try! loginRealm.write{
                            loginRealm.delete(loginRealm.objects(LoginObject.self))
                            loginRealm.add(loginObject)
                        }

                    }

                } catch {
                    print("LoginObject Throw \(error)")
                }
            }
        }

        task.resume()

    }

    func forgotPassword(number: String){
        isLoading = true
        let parameters = [
            [
                "key": "mobile",
                "value": "\(number)",
                "type": "text"
            ],
            [
                "key": "user_type",
                "value": "Customer",
                "type": "text"
            ],
            [
                "key": "device_token",
                "value": "123456xczx",
                "type": "text"
            ]] as [[String : Any]]

        let boundary = "Boundary-\(UUID().uuidString)"
        var body = ""
        var error: Error? = nil
        for param in parameters {
            if param["disabled"] == nil {
                let paramName = param["key"]!
                body += "--\(boundary)\r\n"
                body += "Content-Disposition:form-data; name=\"\(paramName)\""
                if param["contentType"] != nil {
                    body += "\r\nContent-Type: \(param["contentType"] as! String)"
                }
                let paramType = param["type"] as! String
                if paramType == "text" {
                    let paramValue = param["value"] as! String
                    body += "\r\n\r\n\(paramValue)\r\n"
                } else {
                    do{
                        let paramSrc = param["src"] as! String
                        let fileData = try NSData(contentsOfFile:paramSrc, options:[]) as Data
                        let fileContent = String(data: fileData, encoding: .utf8)!
                        body += "; filename=\"\(paramSrc)\"\r\n"
                        + "Content-Type: \"content-type header\"\r\n\r\n\(fileContent)\r\n"
                    } catch {
                        print("LoginOO Throw \(error)")
                    }
                }
            }
        }
        body += "--\(boundary)--\r\n";
        let postData = body.data(using: .utf8)

        var request = URLRequest(url: URL(string: "https://pragatiutrack.com/api/user/forgot_password")!,timeoutInterval: Double.infinity)
        request.addValue("FEA3E5D0QFCEBFD54F0A6A674ECAE3F8", forHTTPHeaderField: "X-Api-Key")
        request.addValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")

        request.httpMethod = "POST"
        request.httpBody = postData

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                self.isLoading = false
                guard let data = data else {
                    print(String(describing: error))
                    return
                }
                do {
                    let decoder = JSONDecoder()
                    decoder.keyDecodingStrategy = .convertFromSnakeCase
                    let fObj = try decoder.decode(ForgotPassObject.self, from: data)
                    if fObj.status == true {
                        print("We've a number")
                        self.forgotStatus = true
                        self.forgotMessage = fObj.message
                        //write to realm
                        let loginRealm = try Realm()
                        try! loginRealm.write{
                            loginRealm.delete(loginRealm.objects(ForgotPassObject.self))
                            loginRealm.add(fObj)
                        }
                        
                    } else {
                        self.forgotStatus = false
                        self.forgotMessage = fObj.message
                    }
                    
                } catch {
                    print("LoginObject Throw \(error)")
                }
            }
        }
        task.resume()

    }


    func resetPassword(password: String, userId: String, otp: String){
        isLoading = true
        let parameters = [
            [
                "key": "password",
                "value": "\(password)",
                "type": "text"
            ],
            [
                "key": "device_token",
                "value": "123456",
                "type": "text"
            ],
            [
                "key": "user_id",
                "value": "\(userId)",
                "type": "text"
            ],
            [
                "key": "verify_code",
                "value": "\(otp)",
                "type": "text"
            ]] as [[String : Any]]

        let boundary = "Boundary-\(UUID().uuidString)"
        var body = ""
        var error: Error? = nil
        for param in parameters {
            if param["disabled"] == nil {
                let paramName = param["key"]!
                body += "--\(boundary)\r\n"
                body += "Content-Disposition:form-data; name=\"\(paramName)\""
                if param["contentType"] != nil {
                    body += "\r\nContent-Type: \(param["contentType"] as! String)"
                }
                let paramType = param["type"] as! String
                if paramType == "text" {
                    let paramValue = param["value"] as! String
                    body += "\r\n\r\n\(paramValue)\r\n"
                } else {
                    do {
                        let paramSrc = param["src"] as! String
                        let fileData = try NSData(contentsOfFile:paramSrc, options:[]) as Data
                        let fileContent = String(data: fileData, encoding: .utf8)!
                        body += "; filename=\"\(paramSrc)\"\r\n"
                        + "Content-Type: \"content-type header\"\r\n\r\n\(fileContent)\r\n"
                    } catch {
                        print("LoginOO Throw \(error)")
                    }
                }
            }
        }
        body += "--\(boundary)--\r\n";
        let postData = body.data(using: .utf8)

        var request = URLRequest(url: URL(string: "https://pragatiutrack.com/api/user/reset_password")!,timeoutInterval: Double.infinity)
        request.addValue("FEA3E5D0QFCEBFD54F0A6A674ECAE3F8", forHTTPHeaderField: "X-Api-Key")
        request.addValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")

        request.httpMethod = "POST"
        request.httpBody = postData

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                self.isLoading = false
                guard let data = data else {
                    print(String(describing: error))
                    return
                }
                do {
                    let decoder = JSONDecoder()
                    decoder.keyDecodingStrategy = .convertFromSnakeCase
                    let fObj = try decoder.decode(ResetObject.self, from: data)
                    if fObj.status == true {
                        print("We've a number")
                        self.resetStatus = true
                        self.resetMessage = fObj.message
                        //write to realm
                        let loginRealm = try Realm()
                        try! loginRealm.write{
                            loginRealm.delete(loginRealm.objects(ResetObject.self))
                            loginRealm.add(fObj)
                        }

                    } else {
                        self.resetStatus = false
                        self.resetMessage = fObj.message
                    }

                } catch {
                    print("Reset Throw \(error)")
                }
            }
            
            
        }
        task.resume()

    }
}

