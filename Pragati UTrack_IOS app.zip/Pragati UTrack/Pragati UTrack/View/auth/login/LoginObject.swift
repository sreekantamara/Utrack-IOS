//
//  LoginObject.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2023-12-01.
//

// Data Object
import Foundation
import RealmSwift


class LoginObject: Object, Codable, ObjectKeyIdentifiable {
    @Persisted var status: Bool
    @Persisted var message: String
    @Persisted var data : List<UserData>
}

class UserData: Object, Codable {
    @Persisted var userId: String?
    @Persisted var userCode: String?
    @Persisted var userName: String?
    @Persisted var firstName: String?
    @Persisted var lastName: String?
    @Persisted var email: String?
    @Persisted var password: String?
    @Persisted var mobileCode: String?
    @Persisted var mobile: String?
    @Persisted var profileImage: String?
    @Persisted var stateId: String?
    @Persisted var districtId: String?
    @Persisted var cityId: String?
    @Persisted var address1: String?
    @Persisted var address2: String?
    @Persisted var areaName: String?
    @Persisted var zipcode: String?
    @Persisted var latitude: String?
    @Persisted var longitude: String?
    @Persisted var userType: String?
    @Persisted var registerDate: String?
    @Persisted var referralCode: String?
    @Persisted var walletBalance: String?
    @Persisted var notifyPref: String?
    @Persisted var deviceType: String?
    @Persisted var deviceName: String?
    @Persisted var appVersion: String?
    @Persisted var deviceOs: String?
    @Persisted var status: String?
    @Persisted var dlNumber: String?
    @Persisted var dlFront: String?
    @Persisted var dlBack: String?
    @Persisted var isCorporate: String?
    @Persisted var screenName: String?
    @Persisted var busOrganisationId: String?
    @Persisted var busOrganisationBranchId: String?
    @Persisted var busOrganisationRole: String?
    @Persisted var accessType: String?
    @Persisted var parentId: String?
    @Persisted var isSlottedVehicleAnalysis: String?
    @Persisted var slotTime: String?
    @Persisted var selectedColumns: String?
    @Persisted var tripSelectedColumns: String?
    @Persisted var mobileLaunchMode: String?
    @Persisted var homeTab: String?
    @Persisted var mobileListType: String?
    @Persisted var state: String?
    @Persisted var districtName: String?
    @Persisted var city: String?
    @Persisted var registeredByType: String?
    @Persisted var registeredById: String?
    @Persisted var companyId: String?
    @Persisted var companyName: String?
    @Persisted var companyLogo: String?
    @Persisted var companyStateId: String?
    @Persisted var companyDistrictId: String?
    @Persisted var companyCityId: String?
    @Persisted var companyAddress1: String?
    @Persisted var companyLandmark: String?
    @Persisted var companyAddress2: String?
    @Persisted var companyPincode: String?
    @Persisted var companyEmail: String?
    @Persisted var companyMobile: String?
    @Persisted var companyState: String?
    @Persisted var companyDistrictName: String?
    @Persisted var companyCity: String?
}



