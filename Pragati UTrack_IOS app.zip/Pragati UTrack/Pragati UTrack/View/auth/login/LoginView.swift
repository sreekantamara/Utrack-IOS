//
//  LoginView.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2023-12-01.
//

// View
import SwiftUI
import FloatingLabelTextFieldSwiftUI
import AlertKit

struct LoginView: View {
    @EnvironmentObject var loginOO: LoginOO

    @State var username: String = "" //"8238566278"// = ""//"UTRACK00365" //
    @State var password: String = "" //"!23456aA"//= ""//"123456"// 
    @State var passwordVisible = false

    @Binding var isLoggedIn: Bool

    @StateObject var customAlertManager = CustomAlertManager()
    @StateObject var alertManager = AlertManager()

    @State var phoneNumber = ""
    @State private var index: Int? = nil

    @State var resetDone = false

    var body: some View {

        NavigationStack {

            if loginOO.forgotStatus {
                NavigationLink(destination: ForgotView(resetDone: $resetDone),
                               tag: index ?? -1,
                               selection: $index) {
                    EmptyView()
                }
                               .hidden()
            }


            GeometryReader { proxy in
                ZStack(alignment: .top) {

                    Group {
                        Image("login_bg_new")
                            .resizable()

                        Image("app_logo_white")
                            .resizable()
                            .scaledToFit()
                            .frame(width: proxy.size.width * 0.5)
                            .padding(.top, proxy.size.height > 667 ? proxy.size.height * 0.1 : proxy.size.height * 0.08)
                    }
                    
                        VStack {
                            // Username
                            FloatingLabelTextField( $username, placeholder: "Mobile Number or Username")

                                .lineColor(.white)
                                .selectedLineColor(.accent)
                                .titleColor(.accent)
                                .selectedTitleColor(.accent)
                                .placeholderColor(.white)
                                .textColor(.white)
                                .selectedTextColor(.white)
                                .padding(proxy.size.height > 667 ? 20 : 10)


                            // Password
                            FloatingLabelTextField( $password, placeholder: "Password")
                                .lineColor(.white)
                                .selectedLineColor(.accent)
                                .titleColor(.accent)
                                .selectedTitleColor(.accent)
                                .placeholderColor(.white)
                                .textColor(.white)
                                .selectedTextColor(.white)
                                .isSecureTextEntry(!passwordVisible)
                                .rightView({ // Add right view.
                                    Button(action: {
                                        withAnimation {
                                            self.passwordVisible.toggle()
                                        }

                                    }) {
                                        Image(systemName: self.passwordVisible ? "eye" : "eye.slash")
                                            .foregroundStyle(.white)

                                    }
                                })
                                .padding(proxy.size.height > 667 ? 20 : 10)

                            // Login Button
                            Button{
                                guard !username.isEmpty && !password.isEmpty else {
                                    print("Empty username or password")
                                    return
                                }

                                loginOO.loginWith(name: username, password: password)
                            } label:{
                                Text("LOGIN")
                                    .frame(width: proxy.size.width * 0.9)
                            }
                            .foregroundStyle(.white)
                            .font(.system(size: 22, weight: .bold))
                            .frame(width: proxy.size.height > 667 ? proxy.size.width * 0.9 : proxy.size.width * 0.95, height: 50)
                            .background(
                                RoundedRectangle(cornerRadius: 5, style: .circular)
                                    .foregroundStyle(.green)
                            )
                            .overlay(RoundedRectangle(cornerRadius: 5)
                                .strokeBorder(.white, style: /*@START_MENU_TOKEN@*/StrokeStyle()/*@END_MENU_TOKEN@*/))

                            // Signup and Forgot
                            HStack {
//                                NavigationLink(destination: SignupView()) {
//                                    Text("Sign Up")
//                                        .underline()
//                                        .foregroundStyle(.white)
//                                }

                                Spacer()

                                Text("Forgot Password")
                                    .underline()
                                    .foregroundStyle(.white)
                                    .onTapGesture {
                                        customAlertManager.show()
                                    }
                            }
                            .padding(proxy.size.height > 667 ? 20 : 10)

                            // Demo Button
                            Button("DEMO"){
                                loginOO.loginWith(name: "UTRACK00365", password: "123456")
                            }.foregroundStyle(.white)
                                .font(.system(size: 22, weight: .bold))
                                .frame(width: proxy.size.width * 0.4, height: 50)
                                .background(
                                    LinearGradient(gradient: Gradient(colors: [Color.orange, Color.yellow]), startPoint: /*@START_MENU_TOKEN@*/.leading/*@END_MENU_TOKEN@*/, endPoint: /*@START_MENU_TOKEN@*/.trailing/*@END_MENU_TOKEN@*/)
                                )
                                .cornerRadius(10.0)
                                .padding(5)

                            // Credits
                            Text("Powered By")
                                .font(.caption)
                                .foregroundStyle(.white)
                                .padding(.bottom, -10)
                            Image("ramki_logo")
                            Text("Ramki Technologies Pvt Ltd.")
                                .font(.caption)
                                .foregroundStyle(.white)
                                .padding(.top, -10)
                            Spacer(minLength: 10)



                        }
                        .frame(height: proxy.size.height * 0.52)
                        .padding(.top, proxy.size.height * 0.48)
                        .foregroundColor(.red)


                } // ZStack
                .modifier(ActivityIndicatorModifier(isLoading: loginOO.isLoading))
            }
            .ignoresSafeArea()

        }
        .uses(alertManager)
        .customAlert(manager: customAlertManager, content: {
            VStack {
                Text("Enter Mobile Number").bold()
                TextField("", text: $phoneNumber).textFieldStyle(RoundedBorderTextFieldStyle())
            }
        }, buttons: [
            .cancel(content: {
                Text("Cancel").bold()
            }),
            .regular(content: {
                Text("Send")
            }, action: {
                loginOO.forgotPassword(number: phoneNumber)
            })
        ])
        .onChange(of: loginOO.isLoggedIn) { newValue in
            isLoggedIn = newValue
        }
        .onChange(of: loginOO.forgotMessage) { newValue in
           
            if !newValue.isEmpty {

                if !resetDone {
                    alertManager.show(dismiss: .info(message: newValue, dismissButton: .cancel({
                        index = 1
                        loginOO.forgotStatus = false
                    })))
                }
                
            }
        }
    }
}
