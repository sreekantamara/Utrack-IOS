//
//  SignupObject.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2023-12-02.
//

// Data Object
import Foundation

struct SignupObject: Identifiable {
    let id = UUID()
}
