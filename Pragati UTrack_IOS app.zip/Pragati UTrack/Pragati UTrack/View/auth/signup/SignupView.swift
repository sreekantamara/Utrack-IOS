//
//  SignupView.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2023-12-02.
//

// View
import SwiftUI

struct SignupView: View {

    @State var acceptedTos = false


//    @State var imageName: String
//    @State var firstName: String
//    @State var lastName: String
//
//    @State var emailId: String
//    @State var username: String
//    @State var password: String
//    @State var conPassword: String
//
//    @State var state: String
//    @State var district: String
//    @State var areaName: String
//    @State var pinCode: String
//
//    @State var address: String
//    @State var refCode: String

    var body: some View {

        GeometryReader {proxy in

            List {

                HStack(alignment: .center) {
                    AvatarView()
                }.frame(width: 1000)
                    .listRowSeparator(.hidden)

                HStack{
                    TopTitleTextField(boxname: "First Name")
                    TopTitleTextField(boxname: "Last Name")
                }
                .listRowSeparator(.hidden)

                TopTitleTextField(boxname: "Email")
                    .listRowSeparator(.hidden)
                TopTitleTextField(boxname: "Mobile Number or Username")
                    .listRowSeparator(.hidden)
                TopTitleTextField(boxname: "Password")
                    .listRowSeparator(.hidden)
                TopTitleTextField(boxname: "Confirm Password")
                    .listRowSeparator(.hidden)

                HStack {
                    TopTitleTextField(boxname: "State")
                    TopTitleTextField(boxname: "District")
                }
                .listRowSeparator(.hidden)

                HStack {
                    TopTitleTextField(boxname: "Area Name")
                    TopTitleTextField(boxname: "Pin Code")
                }.listRowSeparator(.hidden)

                TopTitleTextField(boxname: "Address")
                    .listRowSeparator(.hidden)
                

                ZStack(alignment: .bottomTrailing){
                    TopTitleTextField(boxname: "Referral Code")

                    UTrackGradientButton(buttonTitle: "VERIFY", height: 45, width: proxy.size.width * 0.4)
                        .offset(x: 5, y: proxy.size.height > 667 ? 8 : 11.5)
                }
                .listRowSeparator(.hidden)



                HStack {
                    Image(systemName: acceptedTos ? "checkmark.square.fill" : "square")
                        .onTapGesture {
                            acceptedTos.toggle()
                        }
                    Text("I accept Terms & Conditions and Privacy Policy")
                        .font(.caption)
                    
                }
                .listRowSeparator(.hidden)

                HStack {
                    Button("SIGN UP"){

                    }.foregroundStyle(.white)
                        .font(.system(size: 22, weight: .bold))
                        .frame(width: proxy.size.height > 667 ? proxy.size.width * 0.9 : proxy.size.width * 0.95, height: 50)
                        .background(
                            LinearGradient(gradient: Gradient(colors: [Color.red, Color.yellow]), startPoint: /*@START_MENU_TOKEN@*/.leading/*@END_MENU_TOKEN@*/, endPoint: /*@START_MENU_TOKEN@*/.trailing/*@END_MENU_TOKEN@*/)
                        )
                        .cornerRadius(10.0)
                        .padding(5)
                }
                .listRowSeparator(.hidden)

            }
            // list
            .listStyle(.plain)

        }

    }
}

struct SignupView_Previews: PreviewProvider {
    static var previews: some View {
        SignupView()
    }
}
