//
//  ForgotView.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-01-19.
//

import SwiftUI
import RealmSwift
import FloatingLabelTextFieldSwiftUI
import AlertKit

struct ForgotView: View {
    @EnvironmentObject var loginOO: LoginOO
    @ObservedResults(ForgotPassObject.self) var forgotPass

    @Binding var resetDone: Bool
    @State var resetCode: String = ""
    @State var newPass: String = ""
    @State var newPassConfirm: String = ""

    @State var passwordVisible = false
    @StateObject var alertManager = AlertManager()

    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>

    var body: some View {
        VStack(alignment: .leading) {
            HStack {
                Spacer()
                Image(.appLogo)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 200)
                Spacer()
            }
            if let obj = forgotPass.first, let data = obj.data {

                HStack {
                    Text("Hello")
                    Text("Vamsi")
                        .bold()
                }.padding()

                Text("\(obj.message)")
                    .multilineTextAlignment(.leading)
                    .padding()

                FloatingLabelTextField($resetCode, placeholder: "Reset Code")
                    .frame(height: 40)
                    .padding()

                FloatingLabelTextField($newPass, placeholder: "New Password")
                    .isSecureTextEntry(!passwordVisible)
                    .rightView({ // Add right view.
                        Button(action: {
                            withAnimation {
                                self.passwordVisible.toggle()
                                print(data.verifyCode)
                            }

                        }) {
                            Image(systemName: self.passwordVisible ? "eye" : "eye.slash")
                                .foregroundStyle(.blue)

                        }
                    })
                    .frame(height: 40)
                    .padding()

                FloatingLabelTextField($newPassConfirm, placeholder: "Confirm Password")
                    .isSecureTextEntry(!passwordVisible)
                    .rightView({ // Add right view.
                        Button(action: {
                            withAnimation {
                                self.passwordVisible.toggle()
                            }

                        }) {
                            Image(systemName: self.passwordVisible ? "eye" : "eye.slash")
                                .foregroundStyle(.blue)

                        }
                    })
                    .frame(height: 40)
                    .padding()

                GeometryReader { proxy in
                    Button("RESET PASSWORD"){
                        guard newPass == newPassConfirm, !resetCode.isEmpty else {return}
                        loginOO.resetPassword(password: newPass, userId: "\(data.userId)", otp: "\(resetCode)")
                    }
                    .frame(width: proxy.size.width * 0.95, height: 50)
                    .foregroundStyle(.white)
                    .font(.system(size: 22, weight: .bold))
                    .background(
                        LinearGradient(gradient: Gradient(colors: [Color.red, Color.yellow]), startPoint: /*@START_MENU_TOKEN@*/.leading/*@END_MENU_TOKEN@*/, endPoint: /*@START_MENU_TOKEN@*/.trailing/*@END_MENU_TOKEN@*/)
                    )
                    .cornerRadius(5)
                    .padding(5)

                }

            }


            Spacer()

        }
        .modifier(ActivityIndicatorModifier(isLoading: loginOO.isLoading))
            .uses(alertManager)
            .onChange(of: loginOO.resetMessage) { newValue in
                if !newValue.isEmpty {
                    alertManager.show(dismiss: .info(message: newValue, dismissButton: .cancel({
                        if loginOO.resetStatus {
                            self.presentationMode.wrappedValue.dismiss()
                            loginOO.resetMessage = ""
                            loginOO.resetStatus = false
                            resetDone = true
                        }
                    })))
                }
            }
    }
}
