//
//  MyProfile.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-01-03.
//

import SwiftUI
import RealmSwift

struct MyProfile: View {
    @ObservedResults(LoginObject.self) var loginItems
    var body: some View {
        VStack (alignment: .leading){
            Text("My Profile")
                .bold()
                .font(.title)
            
            if let li = loginItems.last,
               let item = li.data.first,
               let url = item.profileImage,
               let name = item.firstName{

                HStack {
                    Text("Name: ")
                        .font(.caption)
                        .foregroundStyle(.gray)

                    Text(item.companyName ?? name)
                        .multilineTextAlignment(.center)
                        .font(.caption2)
                }.padding()

                HStack {
                    Text("Email: ")
                        .font(.caption)
                        .foregroundStyle(.gray)

                    Text(item.email ?? "N/A")
                        .multilineTextAlignment(.center)
                        .font(.caption2)
                }.padding()

                HStack {
                    Text("Phone: ")
                        .font(.caption)
                        .foregroundStyle(.gray)

                    Text(item.mobile ?? "N/A")
                        .multilineTextAlignment(.center)
                        .font(.caption2)
                }.padding()

                HStack {
                    Text("Address: ")
                        .font(.caption)
                        .foregroundStyle(.gray)

                    Text(item.address1 ?? "N/A")
                        .multilineTextAlignment(.center)
                        .font(.caption2)
                }.padding()

                HStack {
                    Text("Registered at: ")
                        .font(.caption)
                        .foregroundStyle(.gray)

                    Text(item.registerDate ?? "N/A")
                        .multilineTextAlignment(.center)
                        .font(.caption2)
                }.padding()

            }

            Spacer()
            Button("Logout"){
                do {
                    let realm = try Realm()
                    try! realm.write{
                        realm.deleteAll()
                    }
                } catch {
                    print("Error \(error)")
                }
            }.padding(20)

        }


    }
}

#Preview {
    MyProfile()
}
