//
//  Ext.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2023-12-28.
//

import SwiftUI
import UIKit

extension Color {
    var name: String {
        switch self {
            case .red:
                return "red"
            case .green:
                return "green"
            default:
                return "yellow"
        }
    }

}


extension String {
    func toCGFloat() -> CGFloat? {
        let numberFormatter = NumberFormatter()
        numberFormatter.numberStyle = .decimal

        guard let number = numberFormatter.number(from: self) else {
            return nil // Handle invalid string input
        }

        return CGFloat(truncating: number)
    }

    func toDouble()-> Double{
        let numberFormatter = NumberFormatter()
        numberFormatter.numberStyle = .decimal

        guard let number = numberFormatter.number(from: self) else {
            return 0 // Handle invalid string input
        }

        return Double(truncating: number)
    }

    func toBoolean()-> Bool{
        switch self {
            case "On":
                return true
            case "Off":
                return false
            default:
                return false
        }
    }

    /// returns a 90 degree marker used in VLCards
    func getAssetImage(_ color: Color) -> String {
        return "marker_type_\(self.lowercased())_\(color.name)_90"
    }

    /// returns a normal marker to be used in maps
    func getMarker(_ color: Color) -> String {
        return "marker_type_\(self.lowercased())_\(color.name)"
    }

        func latitudeWith4Decimal() -> String {
            guard let latitude = Double(self) else {
                return "0" // Invalid string, unable to convert to Double
            }

            let formattedLatitude = String(format: "%.4f", latitude)
            return formattedLatitude
        }

    func formatStringToDate() -> Date {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        dateFormatter.timeZone = TimeZone.current // Adjust time zone as needed

        return dateFormatter.date(from: self) ?? Date()
    }

    func formatStringToDateUTC() -> Date {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        // incoming time is in UTC, do not change
        dateFormatter.timeZone = TimeZone(identifier: "UTC") // Adjust time zone as needed

        return dateFormatter.date(from: self) ?? Date()
    }

}

extension UIImage {
    func resized(to size: CGSize) -> UIImage {
        let renderer = UIGraphicsImageRenderer(size: size)
        let resizedImage = renderer.image { _ in
            self.draw(in: CGRect(origin: .zero, size: size))
        }
        return resizedImage
    }
}

extension Date {

    func formatDateToStringUTC() -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        dateFormatter.timeZone = TimeZone(identifier: "UTC") // Adjust time zone as needed

        return dateFormatter.string(from: self)
    }

    //
    func formatDateToString() -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        // incoming is utc, so change the date
        dateFormatter.timeZone = TimeZone.current // Adjust time zone as needed

        return dateFormatter.string(from: self)
    }

    func formatDateToStringShort() -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        dateFormatter.timeZone = TimeZone.current // Adjust time zone as needed

        return dateFormatter.string(from: self)
    }

    func timeAgoDisplay() -> String {
        let formatter = RelativeDateTimeFormatter()
        formatter.unitsStyle = .short
        return formatter.localizedString(for: self, relativeTo: Date())
    }
}

extension CAMediaTiming {
    func animate(withDuration duration: TimeInterval, animations: () -> Void, completion: (() -> Void)? = nil) {
        CATransaction.begin()
        CATransaction.setAnimationDuration(duration)
        CATransaction.setCompletionBlock(completion)
        animations()
        CATransaction.commit()
    }
}
