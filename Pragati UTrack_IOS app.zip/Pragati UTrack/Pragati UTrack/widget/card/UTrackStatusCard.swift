//
//  UTrackStatusCard.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2023-12-03.
//

import SwiftUI

struct UTrackStatusCard: View {
    var image: String
    var title: String
    var subtitle: String
    var isLiveTrack = false

    var body: some View {
        VStack {
            Image(image)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(height: 28)

            Text(title)
                .font(.caption)

            Text(subtitle)
                .font(.system(size: isLiveTrack ? 14 : 24, weight: .bold))
        }
        .frame(width: 80, height: 90)
        .background {
            RoundedRectangle(cornerRadius: 10, style: /*@START_MENU_TOKEN@*/.continuous/*@END_MENU_TOKEN@*/)
                .foregroundStyle(.white)

        }.overlay(
            RoundedRectangle(cornerRadius: 10, style: /*@START_MENU_TOKEN@*/.continuous/*@END_MENU_TOKEN@*/)
                .strokeBorder(Color.gray, style: /*@START_MENU_TOKEN@*/StrokeStyle()/*@END_MENU_TOKEN@*/)
        )

    }
}
