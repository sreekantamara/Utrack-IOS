//
//  ImageTitleView.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2023-12-03.
//

import SwiftUI

struct ImageTitleView: View {
    var image: String
    var title: String
    var generic = false

    var body: some View {
        VStack {
            Image(image)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(height: generic ? 16:28)

            Text(title)
                .font(.system(size: 10))
        }
        .frame(width: generic ? 45 : 80, height: generic ? 40 : 60)
        .background {

                RoundedRectangle(cornerRadius: 5, style: /*@START_MENU_TOKEN@*/.continuous/*@END_MENU_TOKEN@*/)
                    .foregroundStyle(.white)


        }.overlay(

            RoundedRectangle(cornerRadius: generic ? 0 : 5, style: /*@START_MENU_TOKEN@*/.continuous/*@END_MENU_TOKEN@*/)
                    .strokeBorder(Color.gray, style: /*@START_MENU_TOKEN@*/StrokeStyle()/*@END_MENU_TOKEN@*/)

        )

    }
}

#Preview {
    ImageTitleView(image: Status.dashboard_all, title: "Mobile(23)")
}
