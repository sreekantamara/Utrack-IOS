//
//  VehicleListCardLess.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-02-05.
//

import SwiftUI
import GoogleMaps
import CoreLocation

struct VehicleListCardLess: View {
    var item: Device
    @State var address = ""
    @State var itemLat = 0.0
    @State var itemLon = 0.0

    var body: some View {

        VStack {
            HStack {
                Text(item.vehicleName)
                    .font(.headline)
                    .foregroundStyle(.appPrimaryDark)

                Spacer(minLength: 10)

                Image(item.vehicleType.getAssetImage(getDeviceColor(getDeviceStatus(deviceTime: item.devicetime, speed: item.speed))))
                    .resizable()
                    .frame(width: 40, height: 20)
            }.padding() // First Line

            // Address
            HStack {
                Image(systemName: "mappin.and.ellipse")
                Text("\(item.latitude), \(item.longitude)")
                    .font(.caption)
                    .foregroundStyle(.blue)
                    .onTapGesture {
                        let url = "comgooglemaps://?q=\(item.latitude), \(item.longitude)"
                        UIApplication.shared.open(URL(string: url)!)
                    }
            } // second line
            Text(address)
                .underline()
                .multilineTextAlignment(.leading)
                .font(.caption)
                .foregroundStyle(.blue)
                .onAppear {
                    getAddress(lat: item.latitude, lon: item.longitude) { retrievedAddress in
                        DispatchQueue.main.async {
                            self.address = retrievedAddress
                        }
                    }
                }
                .onTapGesture {
                    let url = "comgooglemaps://?q=\(itemLat),\(itemLon)"
                    UIApplication.shared.open(URL(string: url)!)
                }

            // Date time
            HStack {
                Image(systemName: "calendar")
                Text(extractDate(from:item.servertime) ?? "-")
                    .font(.caption)
                Image(systemName: "clock")
                Text(extractTime(from: item.servertime) ?? "-")
                    .font(.caption)
            }
            .padding(.top, 2) // third line


            // Last
            LazyHGrid(rows: [GridItem()], spacing: 0){

                ImageTitleView(image: getListMovingIcon(getDeviceStatus(deviceTime: item.devicetime, speed: item.speed)), title: getDeviceStatus(deviceTime: item.devicetime, speed: item.speed) == .moving ? "Yes" : "No", generic: true)
                ImageTitleView(image: ListIcon.speed_0, title: "\(item.speed) kmph", generic: true)
                ImageTitleView(image: ListIcon.ignition_on, title: "\(item.ignition ? "On" : "Off")", generic: true)
                ImageTitleView(image: ListIcon.stopped_24_above, title: "", generic: true)

                ImageTitleView(image: ListIcon.signal_medium, title: "3", generic: true)
                ImageTitleView(image: ListIcon.battery_10_below, title: "\(item.batteryLevel)", generic: true)
                ImageTitleView(image: ListIcon.fuel_10_above, title: "\(item.fuelPoint)", generic: true)
                ImageTitleView(image: ListIcon.temperature, title: "\(item.temp1)", generic: true)

            }



        }
        .background(
            RoundedRectangle(cornerRadius: 5, style: /*@START_MENU_TOKEN@*/.continuous/*@END_MENU_TOKEN@*/)
                .foregroundStyle(.white)
                .shadow(radius: 2)
        )
        .padding(.horizontal, 10)// new vStack

    }

    func getAddress(lat: String, lon: String, completion: @escaping (String) -> Void) {

        if let addr = UserDefaults.standard.string(forKey: item.vehicleNumber) {
            completion(addr)
        } else {

            guard let latitude = lat.toCGFloat(), let longitude = lon.toCGFloat() else {return}
            itemLat = latitude
            itemLon = longitude
            let location = CLLocation(latitude: latitude, longitude: longitude)
            let geocoder = CLGeocoder()

            geocoder.reverseGeocodeLocation(location) { placemarks, error in
                guard let placemark = placemarks?.first else {
                    print("Error: \(error?.localizedDescription ?? "Unknown error")")
                    return
                }

                // Access the address components
                let addressComponents = [placemark.thoroughfare, placemark.locality, placemark.administrativeArea, placemark.country]
                let filteredAddressComponents = addressComponents.compactMap { $0 }

                // Concatenate the address components
                address = filteredAddressComponents.joined(separator: ", ")
                UserDefaults.standard.set(address, forKey: item.vehicleNumber)

                completion(address)
            }
        }
    }

    func extractDate(from timestamp: String) -> String? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        dateFormatter.timeZone = TimeZone(abbreviation: "UTC")

        guard let date = dateFormatter.date(from: timestamp) else {
            return nil // Handle invalid timestamp
        }

        dateFormatter.dateFormat = "dd MMM yyyy"
        return dateFormatter.string(from: date)
    }

    func extractTime(from timestamp: String) -> String? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        dateFormatter.timeZone = TimeZone(abbreviation: "UTC")


        guard let date = dateFormatter.date(from: timestamp) else {
            return nil // Handle invalid timestamp
        }

        dateFormatter.dateFormat = "hh:mm a"
        return dateFormatter.string(from: date)
    }
}

