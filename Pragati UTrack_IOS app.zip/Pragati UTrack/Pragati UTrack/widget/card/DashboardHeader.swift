//
//  DashboardHeader.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2023-12-03.
//

import SwiftUI
import Kingfisher
import RealmSwift

struct DashboardHeader: View {

    @ObservedResults(LoginObject.self) var loginItems

    var body: some View {
        HStack {
            if let li = loginItems.last, let item = li.data.first, let url = item.profileImage, let name = item.firstName {

                if url.elementsEqual("https://pragatiutrack.com/uploads/no-image.png"){
                    Image(.appLogo)
                        .resizable()
                        .frame(width: 50, height: 50)
                        .overlay(
                            Circle()
                                .strokeBorder(.gray, style: StrokeStyle(lineWidth: 0.2))
                                .frame(width: 70, height: 70)
                        ) // Image
                } else {
                    KFImage.url(URL(string: url))
                        .resizable()
                        .frame(width: 50, height: 50)
                        .overlay(
                            Circle()
                                .strokeBorder(.gray, style: StrokeStyle(lineWidth: 0.2))
                                .frame(width: 70, height: 70)
                        ) // Image
                }




            Text("Welcome")
                .padding(.horizontal)
                .foregroundStyle(.gray)

                    Text(item.companyName ?? name)
                        .multilineTextAlignment(.center)
                        .font(.system(size: 20, weight: .bold))

            }
        }.onAppear {
            if let li = loginItems.first, let item = li.data.first, let url = item.profileImage {
                print("URL: \(url)")
            }
        }
    }
}
