//
//  VehicleListCard.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2023-12-09.
//

import SwiftUI
import GoogleMaps
import CoreLocation

struct VehicleListCard: View {

    var item: Device
    @State var address: String = ""
    @State var itemLat = 0.0
    @State var itemLon = 0.0

    var body: some View {

        HStack {

                VStack(alignment: .leading){
                    Text(item.vehicleNumber)
                        .font(.headline)
                        .foregroundStyle(.appPrimaryDark)

                    // Asset name and Image
                    HStack{
                        Text(item.vehicleType)
                            .bold()
                            .foregroundStyle(getDeviceColor(getDeviceStatus(deviceTime: item.devicetime, speed: item.speed)))

                        Image(item.vehicleType.getAssetImage(getDeviceColor(getDeviceStatus(deviceTime: item.devicetime, speed: item.speed))))
                            .resizable()
                            .frame(width: 40, height: 20)
                    }

                    // Address
                    HStack {
                        Image(systemName: "mappin.and.ellipse")
                        Text("\(item.latitude), \(item.longitude)")
                            .font(.caption)
                            .foregroundStyle(.blue)
                            .onTapGesture {
                                let url = "comgooglemaps://?q=\(item.latitude), \(item.longitude)"
                                UIApplication.shared.open(URL(string: url)!)
                            }
                    }

                    Text(address)
                        .underline()
                        .multilineTextAlignment(.leading)
                        .font(.caption)
                        .foregroundStyle(.blue)
                        .onTapGesture {
                            let url = "comgooglemaps://?q=\(itemLat),\(itemLon)"
                            UIApplication.shared.open(URL(string: url)!)
                        }.onAppear {
                            getAddress(lat: item.latitude, lon: item.longitude) { retrievedAddress in
                                DispatchQueue.main.async {
                                    self.address = retrievedAddress
                                }
                            }
                        }


                    // Date time
                    HStack {
                        Image(systemName: "calendar")
                        Text(extractDate(from:item.devicetime) ?? "-")
                            .font(.caption)
                        Image(systemName: "clock")
                        Text(extractTime(from: item.devicetime) ?? "-")
                            .font(.caption)
                    }
                    .padding(.top, 2)

                    // Name
                    HStack {
                        Image(systemName: "person")
                        Text(item.customerName)
                            .font(.caption)
                    }
                    .padding(.top, 2)
                    // Access
                    HStack {
                        Image(systemName: "person.3.fill")
                            .foregroundStyle(.appPrimaryDark)
                        Text("\(item.deviceUserListCount) Users Accessing Data")
                            .underline()
                            .font(.caption)
                    }
                    .padding(.top, 2)


                }
                .padding(.top, 20)
                Spacer()
                LazyVGrid(columns: [GridItem(), GridItem()], spacing: 0){
                    ImageTitleView(image: getListMovingIcon(getDeviceStatus(deviceTime: item.devicetime, speed: item.speed)), title: getDeviceStatus(deviceTime: item.devicetime, speed: item.speed) == .moving ? "Yes" : "No", generic: true)
                    ImageTitleView(image: ListIcon.speed_0, title: "\(item.speed) kmph", generic: true)


                    ImageTitleView(image: ListIcon.ignition_on, title: "\(item.ignition ? "On" : "Off")", generic: true)
                    ImageTitleView(image: ListIcon.stopped_24_above, title: "", generic: true)

                    ImageTitleView(image: ListIcon.signal_medium, title: "", generic: true)
                    ImageTitleView(image: ListIcon.battery_10_below, title: "\(item.batteryLevel)", generic: true)

                    ImageTitleView(image: ListIcon.temperature, title: "\(item.temp1)", generic: true)
                    ImageTitleView(image: ListIcon.temperature, title: "\(item.temp2)", generic: true)

                    ImageTitleView(image: ListIcon.fuel_10_above, title: "\(item.fuelPoint)", generic: true)
                    ImageTitleView(image: ListIcon.door, title: "", generic: true)

                }
                .frame(width: 80)


        }
        .padding(.leading, 10)
        .background(
            RoundedRectangle(cornerRadius: 5, style: /*@START_MENU_TOKEN@*/.continuous/*@END_MENU_TOKEN@*/)
                .foregroundStyle(.white)
                .shadow(radius: 2)
        )
        .padding(.horizontal, 10)

    }

    func getAddress(lat: String, lon: String, completion: @escaping (String) -> Void) {

        if let addr = UserDefaults.standard.string(forKey: item.vehicleNumber) {
            completion(addr)
        } else {

            guard let latitude = lat.toCGFloat(), let longitude = lon.toCGFloat() else {return}
            itemLat = latitude
            itemLon = longitude
            let location = CLLocation(latitude: latitude, longitude: longitude)
            let geocoder = CLGeocoder()

            geocoder.reverseGeocodeLocation(location) { placemarks, error in
                guard let placemark = placemarks?.first else {
                    print("Error: \(error?.localizedDescription ?? "Unknown error")")
                    return
                }

                // Access the address components
                let addressComponents = [placemark.thoroughfare, placemark.locality, placemark.administrativeArea, placemark.country]
                let filteredAddressComponents = addressComponents.compactMap { $0 }

                // Concatenate the address components
                address = filteredAddressComponents.joined(separator: ", ")
                UserDefaults.standard.set(address, forKey: item.vehicleNumber)

                completion(address)
            }
        }
    }

    func extractDate(from timestamp: String) -> String? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        dateFormatter.timeZone = TimeZone(abbreviation: "UTC")

        guard let date = dateFormatter.date(from: timestamp) else {
            return nil // Handle invalid timestamp
        }

        dateFormatter.dateFormat = "dd MMM yyyy"
        return dateFormatter.string(from: date)
    }

    func extractTime(from timestamp: String) -> String? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        dateFormatter.timeZone = TimeZone(abbreviation: "UTC")

        guard let date = dateFormatter.date(from: timestamp) else {
            return nil // Handle invalid timestamp
        }

        dateFormatter.dateFormat = "hh:mm a"
        return dateFormatter.string(from: date)
    }
}


