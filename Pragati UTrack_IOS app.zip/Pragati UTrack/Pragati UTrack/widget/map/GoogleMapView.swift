//
//  GoogleMapView.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2023-12-09.
//

import UIKit
import SwiftUI
import GoogleMaps

struct GoogleMapView: UIViewRepresentable {

    var markers: [MarkerData]

    func makeCoordinator() -> GMCoordinator {
        GMCoordinator(parent: self)
    }

    func makeUIView(context: Context) -> GMSMapView {

        let camera = GMSCameraPosition.camera(withLatitude: 37.7749, longitude: -122.4194, zoom: 12.0)
        let mapView = GMSMapView.map(withFrame: CGRect.zero, camera: camera)
        mapView.isMyLocationEnabled = true
        mapView.delegate = context.coordinator

        // Add markers and path
        addMarkers(to: mapView)

        return mapView
    }

    func updateUIView(_ uiView: GMSMapView, context: Context) {
        guard let marker = markers.last else {return}
        uiView.camera = GMSCameraPosition.camera(withLatitude: marker.latitude, longitude: marker.longitude, zoom: 10.0)
    }

    private func addMarkers(to mapView: GMSMapView) {
        guard !markers.isEmpty else {return}

        mapView.clear()
        for markerData in markers {
            let marker = GMSMarker()
            marker.position = CLLocationCoordinate2D(latitude: markerData.latitude, longitude: markerData.longitude)
            marker.title = markerData.vehicleNumber
            if let type = markerData.vehicleType{
                marker.icon = UIImage(named: type.getMarker(getDeviceColor(getDeviceStatus(deviceTime: markerData.deviceTime, speed: markerData.speed))))?.resized(to: CGSize(width: 25, height: 50))

                if let course = markerData.course {
                    marker.rotation = CLLocationDegrees(course.toDouble())
                }

            }

            marker.map = mapView

        }
    }

    private func drawPath(on mapView: GMSMapView) {
        guard !markers.isEmpty else {return}

        let path = GMSMutablePath()
        for marker in markers {
            path.add(CLLocationCoordinate2D(latitude: marker.latitude, longitude: marker.longitude))
        }

        let polyline = GMSPolyline(path: path)
        polyline.strokeColor = .blue
        polyline.strokeWidth = 2.0
        polyline.map = mapView
    }

}
