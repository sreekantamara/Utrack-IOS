//
//  MapZoomSettingsView.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-02-10.
//

import SwiftUI

struct MapZoomSettingsView: View {

    @Binding var autoZoomSelected: Bool
    @Binding var zoomSelected: Bool
    @Binding var rotateSelected: Bool

    var body: some View {
        VStack(alignment: .leading) {
            
            HStack {
                Image(systemName: autoZoomSelected ? "checkmark.square.fill" : "square")
                    .foregroundStyle(.yellow)
                Text("Auto Zoom")
                    .font(.caption2)
            }.onTapGesture {
                autoZoomSelected.toggle()
            }
            HStack {
                Image(systemName: zoomSelected ? "checkmark.square.fill" : "square")
                    .foregroundStyle(.yellow)
                Text("Zoom")
                    .font(.caption2)
            }.onTapGesture {
                zoomSelected.toggle()
            }
            HStack {
                Image(systemName: rotateSelected ? "checkmark.square.fill" : "square")
                    .foregroundStyle(.yellow)
                Text("Rotate Map")
                    .font(.caption2)
            }.onTapGesture {
                rotateSelected.toggle()
            }
        }
        .padding(5)
        .background {
            Color.white.opacity(0.7)
        }
        .overlay(
            RoundedRectangle(cornerRadius: 0)
                .strokeBorder(.appPrimary, style: /*@START_MENU_TOKEN@*/StrokeStyle()/*@END_MENU_TOKEN@*/)
        )
    }
}
