//
//  LegendView.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2023-12-29.
//

import SwiftUI

struct LegendView: View {
    var body: some View {
        VStack(alignment: .leading) {
            HStack {
                Image(systemName: "square.fill")
                    .foregroundStyle(.green)
                Text("Moving")
                    .font(.caption)
            }
            HStack {
                Image(systemName: "square.fill")
                    .foregroundStyle(.yellow)
                Text("Data Not Received")
                    .font(.caption)
            }
            HStack {
                Image(systemName: "square.fill")
                    .foregroundStyle(.red)
                Text("Stopped")
                    .font(.caption)
            }
        }
        .padding(5)
        .background {
            Color.white.opacity(0.7)
        }
        .overlay(
            RoundedRectangle(cornerRadius: 0)
                .strokeBorder(.appPrimary, style: /*@START_MENU_TOKEN@*/StrokeStyle()/*@END_MENU_TOKEN@*/)
        )
    }
}

struct THLegendView: View {
    var body: some View {
        VStack(alignment: .leading) {
            HStack {
                Image(systemName: "square.fill")
                    .foregroundStyle(.green)
                Text("Start")
                    .font(.caption)
            }
            HStack {
                Image(systemName: "square.fill")
                    .foregroundStyle(.red)
                Text("End")
                    .font(.caption)
            }
            HStack {
                Image(systemName: "square.fill")
                    .foregroundStyle(.appPrimary)
                Text("Speed")
                    .font(.caption)
            }
            HStack {
                Image(systemName: "square.fill")
                    .foregroundStyle(.purple)
                Text("Stop Time")
                    .font(.caption)
            }
        }
        .padding(5)
        .background {
            Color.white.opacity(0.7)
        }
        .overlay(
            RoundedRectangle(cornerRadius: 0)
                .strokeBorder(.appPrimary, style: /*@START_MENU_TOKEN@*/StrokeStyle()/*@END_MENU_TOKEN@*/)
        )
    }
}


struct THLegendData: View {
    var distance: String
    var mSpeed: String
    var avSpeed: String
    
    var body: some View {
        VStack(alignment: .leading) {

                Text("Total Distance")
                    .font(.caption)
                    .foregroundStyle(.gray)

                Text("\(distance) KM")
                    .bold()

            Divider()


                Text("Max Speed")
                    .font(.caption)
                    .foregroundStyle(.gray)

                Text("\(mSpeed) KMPH")
                    .bold()

            Divider()

                Text("Avg Speed")
                    .font(.caption)
                    .foregroundStyle(.gray)

                Text("\(avSpeed) KMPH")
                    .bold()
            
        }
        .frame(width: 80)
        .padding(5)
        .background {
            Color.white.opacity(0.7)
        }
        .overlay(
            RoundedRectangle(cornerRadius: 0)
                .strokeBorder(.appPrimary, style: /*@START_MENU_TOKEN@*/StrokeStyle()/*@END_MENU_TOKEN@*/)
        )
    }
}
