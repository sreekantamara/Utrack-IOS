//
//  LiveTrackText.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-02-10.
//

import SwiftUI

struct LiveTrackText: View {
    var boxname: String = "Title Here"
    var text: String

    var body: some View {
        VStack(alignment: .leading) {
            Text(boxname)
                .foregroundStyle(.gray)
                .padding(.bottom, -5)


            Text(text)
                .bold()



        }.frame(height: 60)


    }
}
