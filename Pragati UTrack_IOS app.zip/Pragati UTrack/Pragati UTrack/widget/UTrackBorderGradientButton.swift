//
//  UTrackBorderGradientButton.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-02-10.
//

import SwiftUI

struct UTrackBorderGradientButton: View {
    var buttonTitle: String

    var height: CGFloat = 50
    var width: CGFloat = 20
    var smallerFont = false
    var selected = false
    var onTapped: (()->())?

    var body: some View {

        if selected {

            Button(buttonTitle){
                if let onTapped = onTapped {
                    onTapped()
                }
            }
            .frame(width: width, height: smallerFont ? 30 : height)
            .foregroundStyle(.white)
            .font(.system(size: smallerFont ? 12 : 22, weight: .bold))
            .background(
                LinearGradient(gradient: Gradient(colors: [Color.red, Color.yellow]), startPoint: /*@START_MENU_TOKEN@*/.leading/*@END_MENU_TOKEN@*/, endPoint: /*@START_MENU_TOKEN@*/.trailing/*@END_MENU_TOKEN@*/)
            )
            .cornerRadius(15)
            .padding(5)

        } else {
            Button(action: {
                if let onTapped = onTapped {
                    onTapped()
                }
            }) {
                Text(buttonTitle)
                    .frame(width: width, height: smallerFont ? 30 : height)
                    .font(.system(size: smallerFont ? 12 : 22, weight: .bold))
                    .foregroundStyle(.pink)
                    .cornerRadius(15)
            }
            .overlay(
                RoundedRectangle(cornerRadius: 15)
                    .stroke(LinearGradient(gradient: Gradient(colors: [Color.red, Color.yellow]), startPoint: .leading, endPoint: .trailing), lineWidth: 2)
            )
        }

    }
}
