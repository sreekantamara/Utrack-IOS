//
//  AvatarView.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2023-12-02.
//

import SwiftUI

struct AvatarView: View {

    @State private var selectedImage: UIImage?
    @State private var showImagePicker = false

    var body: some View {
        ZStack {
            if let image = selectedImage {
                Image(uiImage: image)
                    .resizable()
                    .frame(width: 100, height: 100)
                    .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                    .overlay(
                        Circle()
                            .strokeBorder(.appPrimary, style: StrokeStyle(lineWidth: 2.0))
                            .frame(width: 100, height: 100)
                            .foregroundColor(.clear)
                    )
            } else {

                Image(systemName: "person")
                    .resizable()
                    .frame(width: 70, height: 70)
                    .overlay(
                        Circle()
                            .strokeBorder(.appPrimary, style: StrokeStyle(lineWidth: 2.0))
                            .frame(width: 100, height: 100)
                            .foregroundColor(.clear)
                    )
            }


            Image(systemName: "camera.circle.fill")
                .resizable()
                .frame(width: 40, height: 40)
                .foregroundStyle(.appPrimary)
                .background(Circle()
                    .foregroundStyle(.white)
                    .frame(width: 40, height: 40))
                .offset(x: 30, y: 30)
        }.padding()
            .onTapGesture {
                let picker = UIImagePickerController()
                picker.sourceType = .photoLibrary
                showImagePicker = true
            }
            .sheet(isPresented: $showImagePicker) {
                ImagePicker(image: $selectedImage)
            }
    }
}


#Preview {
    AvatarView()
}
