//
//  ReportDateSelectionCard3.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-01-22.
//

import SwiftUI
import MultiPicker

struct ReportDateSelectionCard3: View {
    @Binding var selectedFromDate: Date
    @Binding var selectedToDate: Date

    var selection1Title: String
    @Binding var selectionItems1: [GeofenceData]
    @Binding var selectedOptions1: Set<String>

    var selection2Title: String
    @Binding var selectionItems2: [Device]
    @Binding var selectedOptions2: Set<String>

    @Binding var segmentSelection: Int
    var isGG = false

    var onTapped: ()->()

    var body: some View {

        VStack {
                     MultiPicker(selection1Title, selection: $selectedOptions1) {
                        ForEach(selectionItems1, id: \.self) { option in

                            Text("\(option.geofenceName)")
                                .mpTag(option.geofenceName)

                        }
                    }
                    .mpPickerStyle(.navigationLink)
                    .padding(.horizontal)
                    .tint(.black)
                    .frame(maxHeight: 80)



                    MultiPicker(selection2Title, selection: $selectedOptions2) {
                        ForEach(selectionItems2, id: \.self) { option in

                                Text("\(option.vehicleName)")
                                .mpTag(option.vehicleNumber)

                        }
                    }
                    .mpPickerStyle(.navigationLink)
                    .padding(.horizontal)
                    .tint(.black)
                    .frame(maxHeight: 80)

                EmptyView()
                    .frame(height: 20)

                HStack {
                    VStack {
                        Text("From Date")
                        DatePicker("From Date", selection: $selectedFromDate, displayedComponents: .date)
                            .labelsHidden()
                            .transformEffect(.init(scaleX: 0.7, y: 0.7))
                            .offset(x: 30)
                    }
                    Spacer()
                    VStack {
                        Text("To Date")
                        DatePicker("To Date", selection: $selectedToDate, displayedComponents: .date)
                            .labelsHidden()
                            .transformEffect(.init(scaleX: 0.7, y: 0.7))
                            .offset(x: -30)
                    }

            }

            HStack {
                UTrackGradientButton(buttonTitle: "View Report", width: 100, smallerFont: true){
                    onTapped()
                }.padding(.horizontal, 20)

                Spacer()

                Picker(selection: $segmentSelection, label: Text("Picker")) {
                    Image(systemName: "list.bullet.rectangle").tag(0)
                    Image(systemName: "list.dash.header.rectangle").tag(1)
                }
                .pickerStyle(SegmentedPickerStyle())
                .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/)

            }.padding(.horizontal, 20)

        }


    }
}

