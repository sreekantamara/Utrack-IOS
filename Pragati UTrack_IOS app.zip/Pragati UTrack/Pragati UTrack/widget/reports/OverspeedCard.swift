//
//  OverspeedCard.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-01-21.
//

import SwiftUI

///Actual Summary Report Card
struct OverspeedCard: View {

    var cardTitle: String
    @Binding var totaldistance: String
    @Binding var travelTime: String
    @Binding var maxSpeed: String
    @Binding var avgSpeed: String

    var body: some View {

        GeometryReader {proxy in
        VStack {

            ZStack {
                Color.black.opacity(0.1)
                Text(cardTitle)
                    .bold()
                    .foregroundStyle(.accent)
            }.frame(height: 35)


            HStack{
                VStack(alignment: .leading) {
                    Text("Total Distance")
                        .font(.caption)
                        .foregroundStyle(.gray)

                    Text("\(totaldistance.isEmpty ? "0" : totaldistance) KM")
                        .font(.callout)
                }.padding(.horizontal, 10)

                Spacer()

                VStack(alignment: .leading) {
                    Text("Travel Time")
                        .font(.caption)
                        .foregroundStyle(.gray)

                    Text("\(travelTime.isEmpty ? "0" : travelTime) (HH:MM:SS)")
                        .font(.callout)
                }.frame(width: proxy.size.width * 0.5)

            }
            Divider()
            HStack{

                VStack(alignment: .leading) {
                    Text("Max Speed")
                        .font(.caption)
                        .foregroundStyle(.gray)

                    Text("\(maxSpeed.isEmpty ? "0" : maxSpeed) (KMPH)")
                        .font(.callout)
                }.padding(.horizontal, 10)

                Spacer()

                VStack(alignment: .leading) {
                    Text("Avg Speed")
                        .font(.caption)
                        .foregroundStyle(.gray)

                    Text("\(avgSpeed.isEmpty ? "0" : avgSpeed) (KMPH)")
                        .font(.callout)
                }.frame(width: proxy.size.width * 0.65)


            }
        }.background(
            RoundedRectangle(cornerRadius: 5, style: /*@START_MENU_TOKEN@*/.continuous/*@END_MENU_TOKEN@*/)
                .foregroundStyle(.white)
                .shadow(radius: 2)
        )
        .padding(.horizontal, 10)


        } //G
    }
}
