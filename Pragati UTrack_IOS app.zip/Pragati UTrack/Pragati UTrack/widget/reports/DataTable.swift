//
//  DataTable.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-01-03.
//

import SwiftUI
import SimpleTable
import RealmSwift
import GoogleMaps

struct DataTable: View {

    var headers: [String]
    var data: [[String]]
    var extended: Bool

    var body: some View {
            VStack {

                SimpleTableView{
                    HStack(alignment: .center) {
                        Spacer()
                        SimpleTableLayout(columnsCount: headers.count){
                            columnHeaders()

                            //right
                            if extended {
                                Group{
                                    ForEach(data, id: \.self){ item in

                                        ForEach(item, id: \.self) { item2 in

                                            if item2 == "Moving" {
                                                Text(item2)
                                                    .foregroundStyle(Color.green)

                                            } else if item2 == "Stopped" {
                                                Text(item2)
                                                    .foregroundStyle(Color.red)
                                            } else {
                                                Text(item2)
                                            }

                                        }

                                    }
                                }
                                .padding(2)
                                .frame(
                                    maxWidth: .infinity,
                                    maxHeight: .infinity
                                )

                                .font(.system(size: 10))
                                .overlay(alignment: .trailing) { HStack { Divider() } }
                                .overlay(alignment: .bottom) { VStack { Divider() } }

                            } else {
                                Group{
                                    ForEach(data, id: \.self){ item in
                                        ForEach(item, id: \.self) { item2 in

                                            if item2 == "Moving" {
                                                Text(item2)
                                                    .foregroundStyle(Color.green)
                                                    .frame(height: 50)
                                                    .multilineTextAlignment(.center)
                                            } else if item2 == "Stopped" {
                                                Text(item2)
                                                    .foregroundStyle(Color.red)
                                                    .frame(height: 50)
                                                    .multilineTextAlignment(.center)
                                            } else {
                                                Text(item2)
                                                    .frame(height: 50)
                                                    .multilineTextAlignment(.center)
                                            }


                                        }
                                    }
                                }
                                .padding(2)
                                .frame(
                                    maxWidth: 60,
                                    maxHeight: .infinity
                                )

                                .font(.system(size: 8))
                                .overlay(alignment: .trailing) { HStack { Divider() } }
                                .overlay(alignment: .bottom) { VStack { Divider() } }
                            }


                        }
                        Spacer()
                    }
                }
                Spacer()
            }
        }



    @ViewBuilder
    func columnHeaders() -> some View {

        Group {
            ForEach(Array(headers.enumerated()), id: \.element){index, text in
                if extended {
                    Text(text)
                        .multilineTextAlignment(.center)
                } else {
                        Text(text)
                            .multilineTextAlignment(.center)
                            .frame(width: 40)
                }
            }
        }
        .frame(
            maxWidth: extended ? .infinity : 60,
            maxHeight: .infinity
        )
        .padding(2)
        .bold()
        .font(.system(size: extended ? 10 : 8))
        .background(.thinMaterial)
        .overlay(alignment: .top) { VStack { Divider() } }
        .overlay(alignment: .bottom) { VStack { Divider() } }
        .overlay(alignment: .trailing) { HStack { Divider() } }
        .simpleTableHeaderRow()
        .zIndex(2)

    }
}

