//
//  ReportDateSelectionCard2.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-01-20.
//

import SwiftUI
import MultiPicker

struct ReportDateSelectionCard2: View {
    @Binding var selectedFromDate: Date
    @Binding var selectedToDate: Date

    @Binding var selectedOptions: Set<String>

    var selection1Title: String
    @Binding var selection1Items: [Device]

    var buttonTitle = "Search"

    @Binding var segmentSelection: Int
    var onTapped: ()->()

    var body: some View {

        VStack {
            VStack(alignment: .leading, spacing: 0) {
                MultiPicker(selection1Title, selection: $selectedOptions) {
                    ForEach(selection1Items, id: \.self) { option in

                            Text("\(option.vehicleName)")
                                .mpTag(option.vehicleName)

                    }
                }
                .mpPickerStyle(.navigationLink)
                .padding()
                .tint(.black)

                        EmptyView()
                            .frame(height: 20)

                        HStack {
                            VStack {
                                Text("From Date")
                                DatePicker("From Date", selection: $selectedFromDate, displayedComponents: .date)
                                    .labelsHidden()
                                    .transformEffect(.init(scaleX: 0.7, y: 0.7))
                                    .offset(x: 30)
                            }
                            Spacer()
                            VStack {
                                Text("To Date")
                                DatePicker("To Date", selection: $selectedToDate, displayedComponents: .date)
                                    .labelsHidden()
                                    .transformEffect(.init(scaleX: 0.7, y: 0.7))
                                    .offset(x: -30)
                            }
                        }
                    }.frame(maxHeight: 100)

            HStack {
                UTrackGradientButton(buttonTitle: buttonTitle, width: 100, smallerFont: true){
                    onTapped()
                }.padding(.horizontal, 20)

                Spacer()

                Picker(selection: $segmentSelection, label: Text("Picker")) {
                    Image(systemName: "list.bullet.rectangle").tag(0)
                    Image(systemName: "list.dash.header.rectangle").tag(1)
                }
                .pickerStyle(SegmentedPickerStyle())
                .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/)

            }.padding(.horizontal, 20)

        }


    }
}

