//
//  ListReportSheet.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-01-03.
//

import SwiftUI

struct ListReportSheet: View {

    var onTapped: (Int)->()

    var body: some View {
        VStack {
            Text("Reports")
            LazyVGrid(columns: [GridItem(), GridItem(), GridItem(), GridItem()]){

                ImageTitleView(image: ReportIcon.liveTracking, title: "Live Tracking")
                    .onTapGesture {
                        onTapped(0)
                    }

                ImageTitleView(image: ReportIcon.trackNearest, title: "Track Nearest")
                    .onTapGesture {
                        onTapped(1)
                    }

                ImageTitleView(image: ReportIcon.trackHistory, title: "Track History")
                    .onTapGesture {
                        onTapped(2)
                    }

                ImageTitleView(image: ReportIcon.summary, title: "Summary")
                    .onTapGesture {
                        onTapped(3)
                    }

                ImageTitleView(image: ReportIcon.stoppage, title: "Stoppage")
                    .onTapGesture {
                        onTapped(4)
                    }
                ImageTitleView(image: ReportIcon.track, title: "Track")
                    .onTapGesture {
                        onTapped(5)
                    }
                ImageTitleView(image: ReportIcon.distance, title: "Distance")
                    .onTapGesture {
                        onTapped(6)
                    }

                ImageTitleView(image: ReportIcon.dailyKm, title: "Daily KM")
                    .onTapGesture {
                        onTapped(7)
                    }
                ImageTitleView(image: ReportIcon.hour_24_analysis, title: "24 Hr Analysis")
                    .onTapGesture {
                        onTapped(8)
                    }
                ImageTitleView(image: ReportIcon.geofence, title: "Geofence")
                    .onTapGesture {
                        onTapped(9)
                    }

                ImageTitleView(image: ReportIcon.geo_to_geo, title: "Geofence to Geofence")
                    .onTapGesture {
                        onTapped(10)
                    }
                ImageTitleView(image: ReportIcon.over_speed, title: "Overspeed")
                    .onTapGesture {
                        onTapped(11)
                    }
                ImageTitleView(image: ReportIcon.km_monthly, title: "KM Monthly View")
                    .onTapGesture {
                        onTapped(12)
                    }
                
            }

        }

    }
}
