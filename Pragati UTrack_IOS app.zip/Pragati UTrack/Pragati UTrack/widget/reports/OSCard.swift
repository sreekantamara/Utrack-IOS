//
//  OSCard.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-02-24.
//

import SwiftUI
import Kingfisher

// Overspeed Card
struct OSCard: View {

    var item: OSData

    var body: some View {
        VStack {
            HStack{
                VStack(alignment: .leading) {
                    Text("From Date Time")
                        .font(.caption)
                        .foregroundStyle(.gray)

                    Text("\(item.fdt)")
                        .font(.callout)
                }.padding(.horizontal, 10)

                Spacer()

                VStack(alignment: .leading) {
                    Text("Max Speed(KMPH)")
                        .font(.caption)
                        .foregroundStyle(.gray)

                    Text("\(item.ms)")
                        .font(.callout)
                }

            }
            Divider()

            HStack{
                VStack(alignment: .leading) {
                    Text("To Date Time")
                        .font(.caption)
                        .foregroundStyle(.gray)

                    Text("\(item.tdt)")
                        .font(.callout)
                }.padding(.horizontal, 10)

                Spacer()

                VStack(alignment: .leading) {
                    Text("Avg. Speed(KMPH)")
                        .font(.caption)
                        .foregroundStyle(.gray)

                    Text("\(item.datumAs)")
                        .font(.callout)
                }

            }

            Divider()

            HStack{
                VStack(alignment: .leading) {
                    Text("Duration(HH:MM:SS)")
                        .font(.caption)
                        .foregroundStyle(.gray)

                    Text("\(item.d)")
                        .font(.callout)
                }.padding(.horizontal, 10)

                Spacer()

                VStack(alignment: .leading) {
                    Text("Distance (Meters)")
                        .font(.caption)
                        .foregroundStyle(.gray)

                    Text("\(item.td)")
                        .font(.callout)
                }

            }
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 5, style: /*@START_MENU_TOKEN@*/.continuous/*@END_MENU_TOKEN@*/)
                .foregroundStyle(.white)
                .shadow(radius: 2)
        )
    }
}
