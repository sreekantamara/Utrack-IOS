//
//  ReportDateSelectionCard.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2024-01-05.
//

import SwiftUI

struct ReportDateSelectionCard: View {

    @Binding var selectedFromDate: Date
    @Binding var selectedToDate: Date
    @Binding var selection1Data: String
    @Binding var selectedInterval: String

    var intervals = [String]()

    var selection1Title: String
    var selection1Items: [Device]

    var buttonTitle = "Search"

    @State var selectedItems1 = ""

    @Binding var segmentSelection: Int
    var onTapped: ()->()

    var body: some View {

        VStack {
            HStack {
                if selectedInterval.isEmpty {
                    VStack(spacing: 0) {
                        Text(selection1Title)
                            .font(.caption)
                            .bold()
                        Picker("", selection: $selection1Data) {
                            ForEach(selection1Items, id: \.vehicleNumber){
                                    var str = "\($0.vehicleName) (\($0.vehicleType))"
                                    Text(str)
                                        .tag($0.deviceLinkId)

                            }
                        }.tint(.black)

                        EmptyView()
                            .frame(height: 20)
                        HStack {
                            VStack {
                                Text("From Date")
                                DatePicker("From Date", selection: $selectedFromDate)
                                    .labelsHidden()
                                    .transformEffect(.init(scaleX: 0.7, y: 0.7))
                                    .offset(x: 30)
                            }
                            VStack {
                                Text("To Date")
                                DatePicker("To Date", selection: $selectedToDate)
                                    .labelsHidden()
                                    .transformEffect(.init(scaleX: 0.7, y: 0.7))
                                    .offset(x: 30)
                            }
                        }
                    }

                } else {
                    VStack(spacing: 0) {
                        Text(selection1Title)
                            .font(.caption)
                            .bold()
                        Picker("", selection: $selection1Data) {
                            ForEach(selection1Items, id: \.self){
                                    var str = "\($0.vehicleName) (\($0.vehicleType))"
                                    Text(str)
                                        .tag($0.deviceLinkId)
                            }
                        }.tint(.black)

                        EmptyView()
                            .frame(height: 20)

                        Text("From Date")
                        DatePicker("From Date", selection: $selectedFromDate)
                            .labelsHidden()
                            .transformEffect(.init(scaleX: 0.7, y: 0.7))
                            .offset(x: 30)
                    }
                    Spacer()
                    VStack(spacing: 0) {
                        Text("Speed Limit")
                            .font(.caption)
                            .bold()
                        Picker("Speed Limit", selection: $selectedInterval) {
                            ForEach(intervals, id: \.self){
                                Text($0)
                                    .tag($0)
                            }
                        }.tint(.black)

                        EmptyView()
                            .frame(height: 20)

                        Text("To Date")
                        DatePicker("To Date", selection: $selectedToDate)
                            .labelsHidden()
                            .transformEffect(.init(scaleX: 0.7, y: 0.7))
                            .offset(x: 30)
                    }
                }

            }

            HStack {
                UTrackGradientButton(buttonTitle: buttonTitle, width: 100, smallerFont: true){
                        onTapped()
                }.padding(.horizontal, 20)

                Spacer()

                Picker(selection: $segmentSelection, label: Text("Picker")) {
                    Image(systemName: "list.bullet.rectangle").tag(0)
                    Image(systemName: "list.dash.header.rectangle").tag(1)
                }
                .pickerStyle(SegmentedPickerStyle())
                .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/)

            }.padding(.horizontal, 20)

        }


    }
}
