//
//  UTrackGradientButton.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2023-12-02.
//

import SwiftUI

struct UTrackGradientButton: View {
    var buttonTitle: String

    var height: CGFloat = 50
    var width: CGFloat = 20
    var smallerFont = false
    var onTapped: (()->())?

    var body: some View {

            Button(buttonTitle){
                if let onTapped = onTapped {
                    onTapped()
                }
            }
            .frame(width: width, height: smallerFont ? 30 : height)
            .foregroundStyle(.white)
            .font(.system(size: smallerFont ? 12 : 22, weight: .bold))
                .background(
                    LinearGradient(gradient: Gradient(colors: [Color.red, Color.yellow]), startPoint: /*@START_MENU_TOKEN@*/.leading/*@END_MENU_TOKEN@*/, endPoint: /*@START_MENU_TOKEN@*/.trailing/*@END_MENU_TOKEN@*/)
                )
                .cornerRadius(5)
                .padding(5)

    }
}

