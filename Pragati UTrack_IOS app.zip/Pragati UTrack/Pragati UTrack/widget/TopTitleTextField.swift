//
//  InputBoxes.swift
//  Pragati UTrack
//
//  Created by Mahmudul Hasan on 2023-12-02.
//

import SwiftUI

struct TopTitleTextField: View {
    var boxname: String = "Title Here"
    @State var text: String = ""

    var body: some View {
        VStack(alignment: .leading) {
            Text(boxname)
                .padding(.bottom, -5)


            TextField("", text: $text)
                .padding(10)
                .background {
                    RoundedRectangle(cornerRadius: 5, style: .continuous)
                        .foregroundStyle(.clear)
                        .frame(width: 60)

                }
                .overlay(
                    RoundedRectangle(cornerRadius: 5)
                        .strokeBorder(.appPrimary, style: /*@START_MENU_TOKEN@*/StrokeStyle()/*@END_MENU_TOKEN@*/)
                )
                

        }.frame(height: 60)


    }
}

#Preview {
    TopTitleTextField()
}
